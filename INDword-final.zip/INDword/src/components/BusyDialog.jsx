import { Loader2 } from 'lucide-react';
import Spider from './Spider.jsx';

/** Shown while a file is being imported or exported: what is happening, how far it is, and a Cancel button. */
export default function BusyDialog({ busy, onCancel }) {
  if (!busy) return null;
  const pct = busy.pct;
  return (
    <div className="no-print fixed inset-0 z-[95] flex items-center justify-center bg-black/40 p-4 backdrop-blur-sm" role="alertdialog" aria-modal="true" aria-label={busy.title}>
      <div className="glass glass-menu animate-pop relative w-full max-w-sm rounded-3xl p-6 text-center">
        <Spider pose="hang" size={56} anim="sway" className="absolute right-6 top-full -mt-1" />
        <Loader2 size={34} className="mx-auto mb-3 animate-spin text-blue-500" />
        <h2 className="text-lg font-semibold">{busy.title}</h2>
        <p className="mt-1 min-h-[1.25rem] text-sm opacity-70">{busy.detail}</p>
        <div className="mt-4 h-2 overflow-hidden rounded-full bg-black/10 dark:bg-white/15">
          {pct == null
            ? <div className="h-full w-1/3 animate-[busyslide_1.2s_ease-in-out_infinite] rounded-full bg-blue-500" />
            : <div className="h-full rounded-full bg-blue-500 transition-[width] duration-200" style={{ width: `${Math.max(3, Math.min(100, pct))}%` }} />}
        </div>
        {pct != null && <p className="mt-1 text-xs tabular-nums opacity-60">{Math.round(pct)}%</p>}
        <button type="button" onClick={onCancel} className="secondary mt-5 w-full">Cancel</button>
      </div>
    </div>
  );
}
