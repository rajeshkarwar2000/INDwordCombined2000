import { WALLPAPERS, ACCENT_CHOICES, GLASS_PRESETS, SPIDERMAN_THEME } from '../services/appearance.js';
import { DEFAULT_SETTINGS } from '../services/store.js';
import { PAGE_SIZES, MARGIN_PRESETS, FONT_SET_LABELS } from '../constants.js';
import { useState } from 'react';
import Spider from './Spider.jsx';
import { VERSIONS, POSES, POSE_IDS, MIX } from '../services/spider.js';
import { DockPosPicker } from '../ink/DrawUI.jsx';

const Section = ({ title, children }) => (
  <section className="glass glass-card mb-4 rounded-3xl p-4">
    <h3 className="mb-3 text-base font-semibold tracking-tight">{title}</h3>
    <div className="grid gap-1">{children}</div>
  </section>
);
const Sub = ({ children }) => <div className="mb-1 mt-3 text-xs font-semibold uppercase tracking-wide opacity-50">{children}</div>;
const Row = ({ label, hint, children }) => (
  <div className="flex min-h-[52px] flex-wrap items-center justify-between gap-3 px-1 py-1">
    <div className="min-w-[160px] flex-1"><div className="text-sm font-medium">{label}</div>{hint && <div className="text-xs opacity-60">{hint}</div>}</div>
    <div className="flex items-center gap-2">{children}</div>
  </div>
);
/** Full-width slider row with the value on the right, like the reference design. */
const Slide = ({ label, value, min, max, step, onChange, fmt = (v) => v }) => (
  <div className="px-1 py-1">
    <div className="flex items-baseline justify-between"><span className="text-sm font-semibold">{label}</span><span className="text-sm font-semibold opacity-60 tabular-nums">{fmt(value)}</span></div>
    <input type="range" className="grange w-full" min={min} max={max} step={step} value={value} style={{ '--p': `${((value - min) / (max - min)) * 100}%` }} onChange={(e) => onChange(Number(e.target.value))} />
  </div>
);
const Toggle = ({ value, onChange }) => <button type="button" role="switch" aria-checked={value} onClick={() => onChange(!value)} className="gswitch" />;
const Seg = ({ value, options, onChange }) => (
  <div className="flex gap-1 rounded-2xl bg-black/5 p-1 dark:bg-white/10">
    {options.map(([v, l]) => <button key={String(v)} type="button" onClick={() => onChange(v)} className={`min-h-[40px] rounded-xl px-3 text-sm font-medium ${value === v ? 'rbtn-on bg-white shadow dark:bg-zinc-700' : ''}`}>{l}</button>)}
  </div>
);

const PRESET_MS = [1000, 3000, 8000, 120000];
/** Auto-save: Off, three presets, or any delay you type in seconds or minutes. */
function AutosaveRows({ s, set, Row, Seg }) {
  const custom = s.autosave && (s.autosaveCustom || !PRESET_MS.includes(s.autosaveMs));
  const mode = !s.autosave ? 0 : custom ? 'custom' : s.autosaveMs;
  const ms = s.autosaveMs || 120000;
  const [unit, setUnit] = useState(ms >= 120000 && ms % 60000 === 0 ? 60000 : 1000);
  const [txt, setTxt] = useState(String(+(ms / unit).toFixed(2)));
  const apply = (t, u) => { const v = parseFloat(t); if (Number.isFinite(v) && v > 0) set({ autosave: true, autosaveCustom: true, autosaveMs: Math.round(Math.min(3600000, Math.max(500, v * u))) }); };
  const pick = (v) => {
    if (v === 0) set({ autosave: false });
    else if (v === 'custom') { set({ autosave: true, autosaveCustom: true }); setTxt(String(+(ms / unit).toFixed(2))); }
    else set({ autosave: true, autosaveCustom: false, autosaveMs: v });
  };
  return (<>
    <Row label="Auto-save" hint={s.autosave ? `Saves ${ms >= 60000 ? `${+(ms / 60000).toFixed(1)} min` : `${+(ms / 1000).toFixed(1)} s`} after you stop changing the document` : 'Off: save yourself with the Save button'}>
      <Seg value={mode} onChange={pick} options={[[0, 'Off'], [1000, '1 s'], [3000, '3 s'], [8000, '8 s'], [120000, '2 min'], ['custom', 'Custom']]} />
    </Row>
    {custom && (
      <Row label="Custom delay" hint="Between 0.5 seconds and 60 minutes">
        <input type="number" inputMode="decimal" min="0.5" step="0.5" className="ginput !w-24 text-center" value={txt} aria-label="Auto-save delay"
          onChange={(e) => { setTxt(e.target.value); apply(e.target.value, unit); }}
          onBlur={() => setTxt(String(+(((s.autosaveMs || 120000) / unit)).toFixed(2)))} />
        <Seg value={unit} onChange={(u) => { setUnit(u); setTxt(String(+((s.autosaveMs || 120000) / u).toFixed(2))); }} options={[[1000, 'sec'], [60000, 'min']]} />
      </Row>
    )}
  </>);
}

const TILE_BG = 'linear-gradient(135deg,#f9a8d4,#a5b4fc 50%,#67e8f9)';
function GlassTile({ id, p, active, onPick }) {
  return (
    <button type="button" onClick={() => onPick(id)} className={`flex flex-col items-center gap-1.5 rounded-2xl bg-black/5 p-2 dark:bg-white/10 ${active ? 'ring-2 ring-blue-500' : ''}`}>
      <span className="grid h-16 w-full place-items-center overflow-hidden rounded-xl p-2" style={{ background: TILE_BG }}>
        <span className="h-full w-full rounded-lg" style={{
          background: `linear-gradient(135deg, rgba(255,255,255,${0.55 * p.glassSheen}), rgba(255,255,255,0) 45%), rgba(255,255,255,${p.glassOpacity})`,
          backdropFilter: `blur(${Math.min(p.glassBlur, 12)}px) saturate(${p.glassSat})`, WebkitBackdropFilter: `blur(${Math.min(p.glassBlur, 12)}px) saturate(${p.glassSat})`,
          border: `1px solid rgba(255,255,255,${Math.min(1, p.glassBorder + 0.25)})`,
          boxShadow: `inset 2px 2px 4px -2px rgba(255,255,255,${0.95 * p.glassRim}), inset -1px -2px 4px -2px rgba(255,255,255,${0.7 * p.glassRim}), 0 4px 10px rgba(0,0,0,.12)`,
        }} />
      </span>
      <span className="text-sm font-semibold">{p.label}</span>
    </button>
  );
}

export default function SettingsPanel({ settings: s, setSettings, ink }) {
  const set = (patch) => setSettings({ ...s, ...patch });
  const custom = (patch) => set({ ...patch, glassStyle: 'custom' });
  const pick = (id) => { const { label, ...vals } = GLASS_PRESETS[id]; set({ ...vals, glassStyle: id }); };
  const base = GLASS_PRESETS[s.glassStyle] || GLASS_PRESETS.frosted;
  const pct = (v) => `${Math.round(v * 100)}%`;
  return (
    <div className="max-w-3xl">
      <Section title="Appearance">
        <Seg value={s.theme} onChange={(v) => set({ theme: v })} options={[['system', 'Auto'], ['light', 'Light'], ['dark', 'Dark']]} />
        <Row label="Spider-Man theme" hint="Red and blue look with web wallpaper. Turn off to return to your previous look.">
          <Toggle value={s.wallpaper === 'spiderman'} onChange={(on) => {
            if (on) set({ ...SPIDERMAN_THEME, spiderPrev: Object.fromEntries(Object.keys(SPIDERMAN_THEME).map((k) => [k, s[k]])) });
            else set({ ...(s.spiderPrev && s.spiderPrev.wallpaper !== 'spiderman' ? s.spiderPrev : { wallpaper: 'aurora', accent: '#3b82f6' }), spiderPrev: null });
          }} />
        </Row>
        {s.wallpaper === 'spiderman' && (
          <Row label="Show Spider-Man characters" hint="Figures near buttons, on the slider and in lists. They never block the tools.">
            <Toggle value={s.spiderChars !== false} onChange={(v) => set({ spiderChars: v })} />
          </Row>
        )}
        {s.wallpaper === 'spiderman' && (
          <>
            <Sub>Spider-Man version</Sub>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
              {[[MIX, { label: 'Mix of all' }], ...Object.entries(VERSIONS)].map(([k, v]) => (
                <button key={k} type="button" onClick={() => set({ spiderVersion: k })} className={`flex flex-col items-center gap-1 rounded-2xl border-2 p-1 ${(s.spiderVersion || 'classic') === k ? 'border-red-500' : 'border-transparent'}`} style={{ background: 'linear-gradient(135deg,#05070f,#0a0f2c)' }}>
                  <Spider pose="thwip" version={k === MIX ? 'classic' : k} size={64} force plain />
                  <span className="text-xs font-semibold text-white">{v.label}</span>
                </button>
              ))}
            </div>
            <Sub>Poses (tap Use my picture to replace one with your own artwork)</Sub>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {POSE_IDS.map((id) => (
                <div key={id} className="flex flex-col items-center gap-1 rounded-2xl p-2" style={{ background: 'linear-gradient(135deg,#05070f,#0a0f2c)' }}>
                  <Spider pose={id} version={s.spiderVersion || 'classic'} size={64} force />
                  <span className="text-xs font-semibold text-white">{POSES[id].label}</span>
                  <label className="cursor-pointer rounded-lg bg-white/15 px-2 py-1 text-[11px] text-white">Use my picture
                    <input type="file" accept="image/*" hidden onChange={(e) => {
                      const f = e.target.files?.[0]; e.target.value = ''; if (!f) return;
                      const r = new FileReader(); r.onload = () => set({ spiderArt: { ...(s.spiderArt || {}), [id]: String(r.result) } }); r.readAsDataURL(f);
                    }} />
                  </label>
                  {s.spiderArt && s.spiderArt[id] && <button type="button" className="text-[11px] text-white/80 underline" onClick={() => { const a = { ...s.spiderArt }; delete a[id]; set({ spiderArt: a }); }}>Remove my picture</button>}
                </div>
              ))}
            </div>
          </>
        )}
        <Row label="Accent colour">
          <div className="flex flex-wrap justify-end gap-2">
            {ACCENT_CHOICES.map((c) => <button key={c} type="button" aria-label={c} onClick={() => set({ accent: c })} className={`h-9 w-9 rounded-full border-2 ${s.accent === c ? 'border-black dark:border-white' : 'border-transparent'}`} style={{ background: c }} />)}
            <input type="color" aria-label="Custom accent" value={s.accent} onChange={(e) => set({ accent: e.target.value })} className="h-9 w-12 rounded-lg border-0 bg-transparent" />
          </div>
        </Row>
        <Row label="Wallpaper">
          <div className="flex flex-wrap justify-end gap-2">
            {Object.entries(WALLPAPERS).map(([k, w]) => (
              <button key={k} type="button" onClick={() => set({ wallpaper: k })} className={`flex h-12 w-20 items-end rounded-xl border-2 p-1 text-[10px] font-medium text-black/70 ${s.wallpaper === k ? 'border-blue-500' : 'border-transparent'}`} style={{ background: w.light }}>{w.label}</button>
            ))}
          </div>
        </Row>
        <Sub>Glass style</Sub>
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          {Object.entries(GLASS_PRESETS).map(([id, p]) => <GlassTile key={id} id={id} p={p} active={s.glassStyle === id} onPick={pick} />)}
        </div>
        <Slide label="Interface size" min={0.9} max={1.3} step={0.05} value={s.uiScale} onChange={(v) => set({ uiScale: v })} fmt={pct} />
      </Section>

      {ink && (
        <Section title="Drawing">
          <Row label="Finger draws too" hint="Off: the stylus draws and a finger scrolls"><Toggle value={ink.fingerDraw} onChange={(v) => ink.setPref({ fingerDraw: v })} /></Row>
          <Sub>Toolbar position</Sub>
          <DockPosPicker value={ink.dock} onPick={(k) => ink.setPref({ dock: k })} />
        </Section>
      )}

      <Section title="Documents">
        <Row label="Page size"><select className="ginput !w-40" value={s.pageSize} onChange={(e) => set({ pageSize: e.target.value })}>{Object.keys(PAGE_SIZES).map((p) => <option key={p}>{p}</option>)}</select></Row>
        <Row label="Margins"><select className="ginput !w-56" value={s.marginPreset} onChange={(e) => set({ marginPreset: e.target.value })}>{Object.entries(MARGIN_PRESETS).map(([k, p]) => <option key={k} value={k}>{p.label}</option>)}</select></Row>
        <Row label="Font style"><select className="ginput !w-40" value={s.fontSet} onChange={(e) => set({ fontSet: e.target.value })}>{Object.entries(FONT_SET_LABELS).map(([k, n]) => <option key={k} value={k}>{n}</option>)}</select></Row>
        <Slide label="Default zoom" min={0.5} max={2} step={0.05} value={s.defaultZoom} onChange={(v) => set({ defaultZoom: v })} fmt={pct} />
        <AutosaveRows s={s} set={set} Row={Row} Seg={Seg} />
      </Section>

      <details className="glass glass-card mb-4 rounded-3xl p-4">
        <summary className="cursor-pointer select-none text-base font-semibold tracking-tight">Advanced</summary>
        <div className="mt-3 grid gap-1">
          <Row label="Performance mode" hint="Turns blur off for smoother scrolling on slow devices"><Toggle value={s.reduceEffects} onChange={(v) => set({ reduceEffects: v })} /></Row>
          <Row label="Reduce motion" hint="Disables animations"><Toggle value={s.reduceMotion} onChange={(v) => set({ reduceMotion: v })} /></Row>
          <Sub>Glass fine-tuning</Sub>
          <Slide label="Blur" min={0} max={60} step={1} value={s.glassBlur} onChange={(v) => custom({ glassBlur: v })} fmt={(v) => `${v} px`} />
          <Slide label="Transparency" min={0.2} max={1} step={0.01} value={s.glassOpacity} onChange={(v) => custom({ glassOpacity: v })} fmt={(v) => `${Math.round(v * 100)}% opaque`} />
          <Slide label="Edge light" min={0} max={1} step={0.05} value={s.glassRim} onChange={(v) => custom({ glassRim: v })} fmt={pct} />
          <Slide label="Liquid shine" min={0} max={1} step={0.05} value={s.glassSheen} onChange={(v) => custom({ glassSheen: v })} fmt={pct} />
          <Slide label="Glass paper" min={0.6} max={1} step={0.02} value={s.pageOpacity} onChange={(v) => set({ pageOpacity: v })} fmt={pct} />
          <p className="px-1 text-xs opacity-60">Glass paper lets the wallpaper show faintly through the page. Exports stay solid.</p>
          <button type="button" className="secondary mt-1 w-full" onClick={() => set({ glassBlur: base.glassBlur, glassOpacity: base.glassOpacity, glassRim: base.glassRim, glassSheen: base.glassSheen })}>Reset glass to the chosen style</button>
          <Sub>Layout</Sub>
          <Row label="Corner style"><Seg value={s.radius} onChange={(v) => set({ radius: v })} options={[[0.25, 'Square'], [1, 'Rounded'], [1.5, 'Soft'], [2.4, 'Capsule']]} /></Row>
          <Slide label="Scrollbar thickness" min={8} max={28} step={2} value={s.scrollSize} onChange={(v) => set({ scrollSize: v })} fmt={(v) => `${v} px`} />
        </div>
      </details>

      <button type="button" className="secondary" onClick={() => setSettings({ ...DEFAULT_SETTINGS, sidebarOpen: s.sidebarOpen })}>Reset settings to defaults</button>
    </div>
  );
}
