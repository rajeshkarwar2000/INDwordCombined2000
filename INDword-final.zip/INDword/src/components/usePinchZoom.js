import { useEffect, useRef } from 'react';
import { flushSync } from 'react-dom';

const clamp = (z, min, max) => Math.min(max, Math.max(min, z));

/**
 * Fast two-finger pinch zoom (and Ctrl + mouse wheel) for a scrolling container.
 * While the fingers move, the page is scaled with a GPU transform: no re-layout, so it follows the fingers at full speed.
 * Moving both fingers together pans the page (the scroll position follows the centre of the fingers while you pinch).
 * When the fingers lift, the real zoom is applied once and the scroll position is corrected so the pinched spot stays put.
 */
export default function usePinchZoom(ref, { zoom, setZoom, enabled = true, min = 0.25, max = 6, onLabel }) {
  const zoomRef = useRef(zoom);
  zoomRef.current = zoom;

  useEffect(() => {
    const el = ref.current;
    if (!el || !enabled) return undefined;
    let g = null;
    const target = () => el.firstElementChild;
    const dist = (t) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);

    const begin = (cx, cy, d) => {
      const r = el.getBoundingClientRect();
      const t = target(); if (!t) return;
      const w = el.querySelector('.zoomwrap'), wr = w ? w.getBoundingClientRect() : null;
      g = { d, z: zoomRef.current, cx: cx - r.left, cy: cy - r.top, lx: cx, ly: cy, ox: el.scrollLeft + cx - r.left, oy: el.scrollTop + cy - r.top, cur: zoomRef.current, raf: 0,
        w, px: cx, py: cy, fx: wr ? (cx - wr.left) / Math.max(1, wr.width) : 0.5, fy: wr ? (cy - wr.top) / Math.max(1, wr.height) : 0.5 };
      t.style.transformOrigin = `${g.ox}px ${g.oy}px`;
      t.style.willChange = 'transform';
      el.dataset.pinching = '1'; // the ink layer waits until the gesture is over before it redraws
    };
    const paint = () => {
      if (!g) return;
      g.raf = 0;
      target().style.transform = `scale(${g.cur / g.z})`;
      onLabel?.(Math.round(g.cur * 100));
    };
    const setCur = (z) => { if (!g) return; g.cur = z; if (!g.raf) g.raf = requestAnimationFrame(paint); };
    // two fingers moving together: scroll the page with them
    const pan = (cx, cy) => {
      if (!g) return;
      const dx = cx - g.lx, dy = cy - g.ly; g.lx = cx; g.ly = cy;
      el.scrollLeft -= dx; el.scrollTop -= dy;
      const r = el.getBoundingClientRect(); g.cx = cx - r.left; g.cy = cy - r.top;
    };
    const finish = () => {
      if (!g) return;
      cancelAnimationFrame(g.raf);
      const { cx, cy, ox, z: z0 } = g, oy = g.oy;
      const gw = g.w, gfx = g.fx, gfy = g.fy;
      const z = Math.round(g.cur * 100) / 100;
      const wr = gw ? gw.getBoundingClientRect() : null; // where the pinched spot is on screen right now (with the preview scale and the pan)
      const ax = wr ? wr.left + gfx * wr.width : 0, ay = wr ? wr.top + gfy * wr.height : 0;
      g = null;
      const t = target();
      if (Math.abs(z - z0) >= 0.005) flushSync(() => setZoom(z)); // apply the real zoom immediately...
      if (t) { t.style.transform = ''; t.style.transformOrigin = ''; t.style.willChange = ''; }  // ...and drop the preview in the same frame
      if (Math.abs(z - z0) >= 0.005) {
        const k = z / z0;
        if (gw) { // the page may be centred (narrower than the screen) so scroll maths from the corner drifts sideways: anchor on the page itself
          const nr = gw.getBoundingClientRect();
          el.scrollLeft += nr.left + gfx * nr.width - ax;
          el.scrollTop += nr.top + gfy * nr.height - ay;
        } else { el.scrollLeft = ox * k - cx; el.scrollTop = oy * k - cy; }
      }
      delete el.dataset.pinching;
      el.dispatchEvent(new Event('ink-sync')); // the ink redraws at the new zoom before the next frame
      onLabel?.(null);
    };

    const onStart = (e) => {
      if (e.touches.length === 2) begin((e.touches[0].clientX + e.touches[1].clientX) / 2, (e.touches[0].clientY + e.touches[1].clientY) / 2, dist(e.touches));
    };
    const onMove = (e) => {
      if (!g || e.touches.length !== 2) return;
      e.preventDefault();
      pan((e.touches[0].clientX + e.touches[1].clientX) / 2, (e.touches[0].clientY + e.touches[1].clientY) / 2);
      setCur(clamp((g.z * dist(e.touches)) / g.d, min, max));
    };
    const onEnd = (e) => { if (g && e.touches.length < 2) finish(); };

    let wheelTimer;
    const onWheel = (e) => {
      if (!e.ctrlKey) return;
      e.preventDefault();
      if (!g) begin(e.clientX, e.clientY, 1);
      setCur(clamp(g.cur * (e.deltaY < 0 ? 1.1 : 0.9), min, max));
      clearTimeout(wheelTimer);
      wheelTimer = setTimeout(finish, 220);
    };

    el.addEventListener('touchstart', onStart, { passive: true });
    el.addEventListener('touchmove', onMove, { passive: false });
    el.addEventListener('touchend', onEnd);
    el.addEventListener('touchcancel', onEnd);
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => {
      el.removeEventListener('touchstart', onStart);
      el.removeEventListener('touchmove', onMove);
      el.removeEventListener('touchend', onEnd);
      el.removeEventListener('touchcancel', onEnd);
      el.removeEventListener('wheel', onWheel);
      clearTimeout(wheelTimer);
      if (g) { cancelAnimationFrame(g.raf); const t = target(); if (t) { t.style.transform = ''; t.style.willChange = ''; } g = null; }
    };
  }, [ref, enabled, setZoom, min, max, onLabel]);
}
