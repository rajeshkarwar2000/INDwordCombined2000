import logo from '../assets/indword-logo.png';

/** INDword brand mark (the glass tile logo). `tile` is kept for compatibility. */
export default function Logo({ size = 32, className = '' }) {
  return <img src={logo} width={size} height={size} className={className} alt="INDword logo" draggable={false} style={{ width: size, height: size, objectFit: 'contain' }} />;
}
