import { useEffect, useState } from 'react';

/**
 * A blinking text cursor drawn by the app itself.
 * Some Android WebViews do not draw the native cursor when the on-screen keyboard is switched off (inputmode="none"),
 * so after a tap you could not see where you were typing. This one is always visible, follows the selection and the zoom.
 */
export default function CaretOverlay({ editor, pageRef, zoom, hidden }) {
  const [pos, setPos] = useState(null);
  const [k, setK] = useState(0);

  useEffect(() => {
    if (!editor) return undefined;
    let raf = 0;
    const clear = () => { setPos(null); pageRef.current?.classList.remove('fake-caret'); };
    const upd = () => {
      const page = pageRef.current;
      if (!page || hidden || editor.isDestroyed || !editor.isEditable || !editor.view.hasFocus() || !editor.state.selection.empty) { clear(); return; }
      try {
        const c = editor.view.coordsAtPos(editor.state.selection.head), pr = page.getBoundingClientRect(), sc = pr.width / page.offsetWidth || 1;
        const h = (c.bottom - c.top) / sc;
        if (!(h > 0) || !Number.isFinite(c.left)) { clear(); return; }
        setPos({ x: (c.left - pr.left) / sc, y: (c.top - pr.top) / sc, h });
        setK((n) => n + 1); // restart the blink so the cursor is solid while you type or move it
        page.classList.add('fake-caret');
      } catch { clear(); }
    };
    const later = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(upd); };
    editor.on('transaction', later); editor.on('focus', later); editor.on('blur', later);
    window.addEventListener('resize', later);
    later();
    return () => {
      cancelAnimationFrame(raf); editor.off('transaction', later); editor.off('focus', later); editor.off('blur', later); window.removeEventListener('resize', later);
      pageRef.current?.classList.remove('fake-caret');
    };
  }, [editor, pageRef, zoom, hidden]);

  if (!pos) return null;
  return <i key={k} className="fcaret" style={{ left: pos.x - 1, top: pos.y, height: pos.h }} />;
}
