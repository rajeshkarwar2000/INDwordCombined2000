import { Component } from 'react';
import { SPIDER, VERSIONS, POSES } from '../services/spider.js';

/** If a mascot ever fails to draw, show nothing instead of breaking the whole app. */
class Safe extends Component {
  constructor(p) { super(p); this.state = { bad: false }; }
  static getDerivedStateFromError() { return { bad: true }; }
  componentDidCatch(e) { console.error('Spider', e); }
  render() { return this.state.bad ? null : this.props.children; }
}

const path = (pts) => `M${pts.map((p) => p.join(' ')).join('L')}`;

/** A web-slinger mascot in one of several poses and suit colours. Shows only while the Spider-Man theme is on
 *  (or when `force` is set, as in the Settings previews). A picture you chose for that pose in Settings replaces the drawing. */
function SpiderArt({ pose = 'swing', size = 56, version, force = false, plain = false, anim = '', className = '', style }) {
  if (!force && !SPIDER.on) return null;
  const P = POSES[pose] || POSES.swing; const C = VERSIONS[version || SPIDER.version] || VERSIONS.classic;
  const art = !plain && SPIDER.art && SPIDER.art[pose];
  const cls = `spider no-print pointer-events-none select-none ${anim ? `spider-${anim}` : ''} ${className}`;
  if (art) return <img src={art} alt="" width={size} height={size} className={cls} style={{ objectFit: 'contain', ...style }} draggable={false} />;
  const limb = (pts, color, w, k) => (
    <g key={k} fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d={path(pts)} stroke={C.rim} strokeWidth={w + 3} strokeOpacity=".9" />
      <path d={path(pts)} stroke={color} strokeWidth={w} />
    </g>
  );
  const [hx, hy] = P.head; const [nx, ny] = P.neck; const [px, py] = P.hip;
  const arm = (i) => limb([P.neck, ...P.arms[i]], C.arms, 6.5, `a${i}`);
  const leg = (i) => limb([P.hip, ...P.legs[i]], C.legs, 7.5, `l${i}`);
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={cls} style={{ filter: 'drop-shadow(0 2px 3px rgba(0,0,0,.45))', overflow: 'visible', ...style }} aria-hidden="true">
      {(P.decor || []).map((d, i) => <line key={`d${i}`} x1={d[0]} y1={d[1]} x2={d[2]} y2={d[3]} stroke="currentColor" strokeOpacity=".45" strokeWidth="1.6" strokeLinecap="round" />)}
      {(P.thread || []).map((t, i) => <line key={`t${i}`} x1={t[0]} y1={t[1]} x2={t[2]} y2={t[3]} stroke="#ffffff" strokeOpacity=".9" strokeWidth="1.2" strokeLinecap="round" />)}
      {arm(1)}{leg(1)}
      {limb([P.neck, P.hip], C.torso, 11, 'torso')}
      {leg(0)}{arm(0)}
      <g transform={`rotate(${P.tilt || 0} ${hx} ${hy})`}>
        <circle cx={hx} cy={hy} r="9.5" fill={C.rim} fillOpacity=".9" />
        <circle cx={hx} cy={hy} r="8" fill={C.head} />
        <path d={`M${hx - 8} ${hy}L${hx + 8} ${hy}M${hx} ${hy - 8}L${hx} ${hy + 8}M${hx - 5.6} ${hy - 5.6}L${hx + 5.6} ${hy + 5.6}M${hx + 5.6} ${hy - 5.6}L${hx - 5.6} ${hy + 5.6}`} stroke={C.line} strokeWidth=".7" fill="none" strokeOpacity=".8" />
        <circle cx={hx} cy={hy} r="4.6" fill="none" stroke={C.line} strokeWidth=".7" strokeOpacity=".8" />
        <ellipse cx={hx - 3.4} cy={hy + 0.6} rx="3.3" ry="1.7" transform={`rotate(18 ${hx - 3.4} ${hy + 0.6})`} fill={C.eye} stroke="#0b1220" strokeWidth=".6" />
        <ellipse cx={hx + 3.4} cy={hy + 0.6} rx="3.3" ry="1.7" transform={`rotate(-18 ${hx + 3.4} ${hy + 0.6})`} fill={C.eye} stroke="#0b1220" strokeWidth=".6" />
      </g>
    </svg>
  );
}
void nx; void ny; void px; void py;

export default function Spider(props) { return <Safe><SpiderArt {...props} /></Safe>; }
