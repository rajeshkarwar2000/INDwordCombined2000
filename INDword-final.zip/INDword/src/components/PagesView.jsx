import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { X, Check, GripVertical, Trash2, Copy, FilePlus, ArrowLeft, ArrowRight, Undo2, RotateCcw, CheckSquare, ExternalLink } from 'lucide-react';
import { pageGroups } from '../pagedLayout.js';
import { stageToJpegs } from '../services/svgExport.js';
import Spider from './Spider.jsx';

const GAP = 28;
let keySeed = 0;
const nk = () => { keySeed += 1; return `pg${keySeed}`; };

/**
 * Page view: every page as a picture. Select pages, drag them (hold the grip) or use the arrows to rearrange,
 * duplicate, delete or add blank pages, then press Apply. The text, boxes, pictures and the pen / highlighter drawings
 * of each page move together with the page.
 */
export default function PagesView({ editor, meta, setMeta, ink, W, H, onClose, flash, goPage }) {
  const [thumbs, setThumbs] = useState(null); // array of data URLs, one per current page
  const [busy, setBusy] = useState(true);
  const [items, setItems] = useState([]); // { key, src } src = current page index, -1 = new blank page
  const [sel, setSel] = useState(() => new Set());
  const [drag, setDrag] = useState(null); // { keys, x, y, gap }
  const [hist, setHist] = useState([]); // snapshots to undo an Apply
  const [total, setTotal] = useState(0);
  const tileRefs = useRef(new Map());
  const scrollRef = useRef(null);
  const itemsRef = useRef(items); itemsRef.current = items;
  const engine = ink?.engine;

  const render = useCallback(async () => {
    setBusy(true);
    try {
      const stage = document.querySelector('.page.paged-stage');
      const groups = pageGroups(editor);
      if (!stage || !groups) { setThumbs([]); setItems([]); setTotal(0); return; }
      const n = Math.max(1, stage.querySelectorAll('.pcard').length);
      const root = document.documentElement; const wasDark = root.classList.contains('dark');
      const wrap = stage.closest('.zoomwrap'); const z = wrap?.style.zoom;
      const sc = 0.32;
      root.classList.remove('dark'); stage.classList.add('exporting'); if (wrap) wrap.style.zoom = '1';
      let jp;
      try {
        await new Promise((r) => setTimeout(r, 80));
        if (engine) await engine.preload();
        const overlay = engine && !engine.empty ? (x, i) => engine.drawPageInto(x, i, W, H, H + GAP, sc) : null;
        jp = await stageToJpegs(stage, { W, H, GAP, n, scale: sc, overlay });
      } finally {
        stage.classList.remove('exporting'); if (wasDark) root.classList.add('dark'); if (wrap) wrap.style.zoom = z;
      }
      setThumbs(jp); setTotal(n);
      setItems(Array.from({ length: n }, (_, i) => ({ key: nk(), src: i })));
      setSel(new Set());
    } catch (e) { flash?.(`Could not draw the pages: ${e.message || e}`); setThumbs([]); setItems([]); } finally { setBusy(false); }
  }, [editor, engine, W, H, flash]);

  useEffect(() => { if (meta.paged) render(); else setBusy(false); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const changed = useMemo(() => items.length !== total || items.some((it, i) => it.src !== i), [items, total]);
  const selCount = sel.size;
  const toggle = (key) => setSel((s) => { const n = new Set(s); if (n.has(key)) n.delete(key); else n.add(key); return n; });

  /* ---------- changes to the arrangement (nothing touches the document until Apply) ---------- */
  const moveSel = (dir) => setItems((list) => {
    const a = [...list];
    if (dir < 0) { for (let i = 1; i < a.length; i += 1) if (sel.has(a[i].key) && !sel.has(a[i - 1].key)) [a[i - 1], a[i]] = [a[i], a[i - 1]]; }
    else { for (let i = a.length - 2; i >= 0; i -= 1) if (sel.has(a[i].key) && !sel.has(a[i + 1].key)) [a[i + 1], a[i]] = [a[i], a[i + 1]]; }
    return a;
  });
  const delSel = () => {
    if (!selCount) return;
    if (selCount >= items.length) { flash?.('A document needs at least one page'); return; }
    setItems((l) => l.filter((it) => !sel.has(it.key))); setSel(new Set());
  };
  const dupSel = () => setItems((l) => { const out = []; l.forEach((it) => { out.push(it); if (sel.has(it.key)) out.push({ key: nk(), src: it.src }); }); return out; });
  const addBlank = () => setItems((l) => {
    const at = l.reduce((m, it, i) => (sel.has(it.key) ? i : m), -1);
    const a = [...l]; a.splice(at < 0 ? a.length : at + 1, 0, { key: nk(), src: -1 }); return a;
  });
  const selectAll = () => setSel((s) => (s.size === items.length ? new Set() : new Set(items.map((i) => i.key))));
  const reset = () => { setItems(Array.from({ length: total }, (_, i) => ({ key: nk(), src: i }))); setSel(new Set()); };

  /* ---------- drag with the grip ---------- */
  const gapAt = (x, y, dragKeys) => {
    const rest = itemsRef.current.filter((it) => !dragKeys.includes(it.key));
    let gap = rest.length; let hit = false;
    for (let i = 0; i < rest.length; i += 1) {
      const el = tileRefs.current.get(rest[i].key); if (!el) continue;
      const r = el.getBoundingClientRect();
      if (y >= r.top && y <= r.bottom && x >= r.left && x <= r.right) { gap = x > r.left + r.width / 2 ? i + 1 : i; hit = true; break; }
    }
    if (!hit) {
      for (let i = 0; i < rest.length; i += 1) {
        const el = tileRefs.current.get(rest[i].key); if (!el) continue;
        const r = el.getBoundingClientRect();
        if (y < r.top) { gap = i; hit = true; break; }
        if (y <= r.bottom && x < r.left) { gap = i; hit = true; break; }
      }
    }
    return gap;
  };
  const startDrag = (e, key) => {
    e.preventDefault(); e.stopPropagation();
    const keys = sel.has(key) ? itemsRef.current.filter((it) => sel.has(it.key)).map((it) => it.key) : [key];
    if (!sel.has(key)) setSel(new Set([key]));
    const t = e.currentTarget; try { t.setPointerCapture(e.pointerId); } catch { /* ignore */ }
    let st = { keys, x: e.clientX, y: e.clientY, gap: gapAt(e.clientX, e.clientY, keys) };
    setDrag(st);
    const sc = scrollRef.current; let raf = 0;
    const auto = () => {
      if (!sc || !st) return;
      const r = sc.getBoundingClientRect();
      if (st.y < r.top + 70) sc.scrollTop -= 14; else if (st.y > r.bottom - 70) sc.scrollTop += 14;
      raf = requestAnimationFrame(auto);
    };
    raf = requestAnimationFrame(auto);
    const move = (ev) => { st = { ...st, x: ev.clientX, y: ev.clientY, gap: gapAt(ev.clientX, ev.clientY, keys) }; setDrag(st); };
    const up = () => {
      cancelAnimationFrame(raf);
      t.removeEventListener('pointermove', move); t.removeEventListener('pointerup', up); t.removeEventListener('pointercancel', up);
      const g = st.gap;
      setItems((list) => {
        const moving = list.filter((it) => keys.includes(it.key)); const rest = list.filter((it) => !keys.includes(it.key));
        const a = [...rest]; a.splice(Math.min(g, a.length), 0, ...moving); return a;
      });
      setDrag(null); st = null;
    };
    t.addEventListener('pointermove', move); t.addEventListener('pointerup', up); t.addEventListener('pointercancel', up);
  };

  /* ---------- Apply: rewrite the document and move the drawings ---------- */
  const apply = async () => {
    const groups = pageGroups(editor); if (!groups) return;
    const list = items; if (!list.length) return;
    const snap = { doc: editor.getJSON(), ink: engine ? engine.objs : [], total };
    const used = new Set(); const flat = [];
    list.forEach((it, idx) => {
      let nodes = it.src < 0 ? [{ type: 'paragraph' }] : (groups[it.src]?.nodes || []).map((n) => n.toJSON());
      const again = it.src >= 0 && used.has(it.src); if (it.src >= 0) used.add(it.src);
      if (again) nodes = nodes.map((n) => (n.type === 'pageBreak' ? { type: 'pageBreak' } : n)); // copies get their own break ids
      const last = idx === list.length - 1;
      const ends = nodes.length > 0 && nodes[nodes.length - 1].type === 'pageBreak';
      if (last && ends) nodes = nodes.slice(0, -1);
      if (!last && !ends) nodes = [...nodes, { type: 'pageBreak' }];
      flat.push(...nodes);
    });
    setBusy(true);
    try {
      engine?.reorderPages(list.map((it) => it.src), total, H + GAP);
      editor.commands.setContent({ type: 'doc', content: flat.length ? flat : [{ type: 'paragraph' }] }, true);
      setHist((h) => [...h, snap]);
      flash?.('Pages rearranged');
      await new Promise((r) => setTimeout(r, 450));
      await render();
    } catch (e) { flash?.(`Could not rearrange: ${e.message || e}`); setBusy(false); }
  };
  const undo = async () => {
    const snap = hist[hist.length - 1]; if (!snap) return;
    setBusy(true);
    editor.commands.setContent(snap.doc, true);
    engine?.restore(snap.ink);
    setHist((h) => h.slice(0, -1));
    await new Promise((r) => setTimeout(r, 450));
    await render();
  };

  const [pw, ph] = [W, H];
  const remaining = drag ? items.filter((it) => !drag.keys.includes(it.key)) : items;
  const dragFirst = drag ? items.find((it) => it.key === drag.keys[0]) : null;

  return (
    <div className="no-print fixed inset-0 z-[90] flex flex-col bg-black/50 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Page view">
      <div className="glass glass-menu m-2 flex min-h-0 flex-1 flex-col rounded-3xl">
        <div className="flex flex-wrap items-center gap-1 border-b border-black/10 px-3 py-2 dark:border-white/10">
          <h2 className="mr-auto flex items-center gap-2 text-lg font-semibold">Page view <span className="text-xs font-normal opacity-60">{items.length} pages{selCount ? ` · ${selCount} selected` : ''}</span><Spider pose="perch" size={34} /></h2>
          <button type="button" className="rbtn !min-h-[40px]" onClick={selectAll} title="Select all"><CheckSquare size={18} /><span className="ml-1 text-xs">{selCount === items.length && items.length ? 'None' : 'All'}</span></button>
          <button type="button" className="rbtn !min-h-[40px]" disabled={!selCount} onClick={() => moveSel(-1)} title="Move earlier"><ArrowLeft size={18} /></button>
          <button type="button" className="rbtn !min-h-[40px]" disabled={!selCount} onClick={() => moveSel(1)} title="Move later"><ArrowRight size={18} /></button>
          <button type="button" className="rbtn !min-h-[40px]" disabled={!selCount} onClick={dupSel} title="Duplicate selected pages"><Copy size={18} /></button>
          <button type="button" className="rbtn !min-h-[40px]" onClick={addBlank} title="Insert a blank page after the selected page"><FilePlus size={18} /></button>
          <button type="button" className="rbtn !min-h-[40px]" disabled={!selCount} onClick={delSel} title="Delete selected pages"><Trash2 size={18} /></button>
          <button type="button" className="rbtn !min-h-[40px]" disabled={selCount !== 1 || items.find((i) => sel.has(i.key))?.src < 0 || changed} onClick={() => { const it = items.find((i) => sel.has(i.key)); onClose(); goPage?.(it.src + 1); }} title="Go to this page"><ExternalLink size={18} /></button>
        </div>

        <div ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto p-3" style={{ touchAction: drag ? 'none' : 'pan-y' }}>
          {!meta.paged && (
            <div className="mx-auto max-w-sm rounded-2xl p-6 text-center">
              <p className="mb-3 text-sm">Page view needs the page layout, where every page is drawn as a sheet.</p>
              <button type="button" className="primary" onClick={() => { setMeta({ paged: true }); onClose(); flash?.('Page layout on. Open Page view again.'); }}>Turn on page layout</button>
            </div>
          )}
          {meta.paged && busy && <div className="grid place-items-center py-16 text-sm opacity-70"><Spider pose="hang" size={64} anim="sway" force /><span className="mt-2">Drawing the pages…</span></div>}
          {meta.paged && !busy && (
            <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(132px, 1fr))' }}>
              {items.map((it, idx) => {
                const isSel = sel.has(it.key); const dragged = drag?.keys.includes(it.key);
                const restIdx = drag ? remaining.findIndex((r) => r.key === it.key) : -1;
                const barL = drag && !dragged && drag.gap === restIdx;
                const barR = drag && !dragged && restIdx === remaining.length - 1 && drag.gap >= remaining.length;
                return (
                  <div key={it.key} ref={(el) => { if (el) tileRefs.current.set(it.key, el); else tileRefs.current.delete(it.key); }} className={`relative flex flex-col items-center gap-1 rounded-2xl p-1.5 ${isSel ? 'bg-blue-500/20 ring-2 ring-blue-500' : ''} ${dragged ? 'opacity-30' : ''}`}>
                    {barL && <span className="absolute -left-2 bottom-1 top-1 w-1 rounded bg-blue-500" />}
                    {barR && <span className="absolute -right-2 bottom-1 top-1 w-1 rounded bg-blue-500" />}
                    <div className="relative w-full cursor-pointer overflow-hidden rounded bg-white shadow" style={{ aspectRatio: `${pw} / ${ph}` }} onClick={() => toggle(it.key)}>
                      {it.src >= 0 && thumbs?.[it.src] ? <img src={thumbs[it.src]} alt="" className="pointer-events-none h-full w-full select-none object-contain" draggable={false} /> : <span className="grid h-full w-full place-items-center text-[11px] text-black/40">{it.src < 0 ? 'Blank page' : '…'}</span>}
                      <span className={`absolute left-1 top-1 grid h-6 w-6 place-items-center rounded-full border-2 ${isSel ? 'border-blue-600 bg-blue-600 text-white' : 'border-black/30 bg-white/80 text-transparent'}`}><Check size={14} /></span>
                      <button type="button" aria-label="Drag to move" title="Hold and drag to move" onPointerDown={(e) => startDrag(e, it.key)} className="absolute right-1 top-1 grid h-8 w-8 touch-none place-items-center rounded-lg bg-black/60 text-white" style={{ touchAction: 'none' }}><GripVertical size={16} /></button>
                    </div>
                    <span className="text-xs tabular-nums opacity-80">{idx + 1}{it.src >= 0 && it.src !== idx ? <span className="opacity-50"> (was {it.src + 1})</span> : ''}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 border-t border-black/10 px-3 py-2 dark:border-white/10">
          <button type="button" className="secondary" disabled={!hist.length} onClick={undo}><Undo2 size={16} className="mr-1 inline" />Undo last change</button>
          <button type="button" className="secondary" disabled={!changed} onClick={reset}><RotateCcw size={16} className="mr-1 inline" />Reset</button>
          <span className="mr-auto" />
          <button type="button" className="secondary" onClick={onClose}><X size={16} className="mr-1 inline" />Close</button>
          <button type="button" className="primary" disabled={!changed || busy} onClick={apply}><Check size={16} className="mr-1 inline" />Apply</button>
        </div>
      </div>

      {drag && dragFirst && thumbs?.[dragFirst.src] && (
        <div className="pointer-events-none fixed z-[100]" style={{ left: drag.x - 40, top: drag.y - 52, width: 80 }}>
          <img src={thumbs[dragFirst.src]} alt="" className="w-full rounded shadow-xl ring-2 ring-blue-500" />
          {drag.keys.length > 1 && <span className="absolute -right-2 -top-2 grid h-6 min-w-[24px] place-items-center rounded-full bg-blue-600 px-1 text-xs font-bold text-white">{drag.keys.length}</span>}
        </div>
      )}
    </div>
  );
}
