import mammoth from 'mammoth/mammoth.browser.js';
import { docxToDoc } from './docxImport.js';
import { markdownToHtml, bodyOf } from './exporters.js';

const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

export const readAsDataUrl = (file) => new Promise((res, rej) => {
  const r = new FileReader();
  r.onload = () => res(String(r.result));
  r.onerror = () => rej(new Error('Could not read the file'));
  r.readAsDataURL(file);
});

/** Word crops pictures with a:srcRect; the editor has no crop attribute, so the cropped bitmap is baked here. */
async function bakeCrops(html) {
  if (!/data-crop=/.test(html)) return html;
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const imgs = [...doc.querySelectorAll('img[data-crop]')];
  await Promise.all(imgs.map((el) => new Promise((resolve) => {
    const [l, t, r, b] = el.getAttribute('data-crop').split(',').map(Number);
    const im = new Image();
    im.onload = () => {
      try {
        const sw = Math.max(1, Math.round(im.naturalWidth * (1 - l - r))), sh = Math.max(1, Math.round(im.naturalHeight * (1 - t - b)));
        const c = document.createElement('canvas'); c.width = sw; c.height = sh;
        c.getContext('2d').drawImage(im, Math.round(im.naturalWidth * l), Math.round(im.naturalHeight * t), sw, sh, 0, 0, sw, sh);
        el.setAttribute('src', c.toDataURL(/jpe?g/.test(el.getAttribute('src').slice(0, 20)) ? 'image/jpeg' : 'image/png', 0.95));
        el.style.height = 'auto';
      } catch { /* keep the uncropped picture */ }
      el.removeAttribute('data-crop'); resolve();
    };
    im.onerror = () => { el.removeAttribute('data-crop'); resolve(); };
    im.src = el.getAttribute('src');
  })));
  return doc.body.innerHTML;
}

/** Opens DOCX / TXT / Markdown / HTML. Returns { name, ext, html, notes[] }. */
export async function importFile(file, opts = {}) {
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  const name = file.name.replace(/\.[^.]+$/, '') || 'Imported Document';
  const notes = [];
  let html;
  let meta;
  if (ext === 'docx') {
    const buffer = await file.arrayBuffer();
    try {
      const r = await docxToDoc(buffer);                       // keeps colours, shaded tables, borders, columns, images, page setup
      html = await bakeCrops(r.html || '<p></p>'); meta = r.meta;
      r.notes.forEach((m) => notes.push(m));
    } catch {
      const r = await mammoth.convertToHtml({ arrayBuffer: buffer });   // plain fallback
      html = r.value || '<p></p>';
      notes.push('This file used features INDword could not read, so it was opened in simple mode (text, tables and images only).');
    }
  } else if (ext === 'pdf') {
    const { pdfToHtml, pdfToPages } = await import('./pdfImport.js'); // loaded only when a PDF is opened
    const r = opts.pdfText ? await pdfToHtml(await file.arrayBuffer(), opts.onProgress) : await pdfToPages(await file.arrayBuffer(), opts.onProgress, opts.signal);
    html = r.html; meta = r.meta; r.notes.forEach((m) => notes.push(m));
  } else if (ext === 'txt') {
    html = (await file.text()).split(/\r?\n/).map((l) => `<p>${esc(l)}</p>`).join('');
  } else if (ext === 'md' || ext === 'markdown') {
    html = markdownToHtml(await file.text());
  } else if (ext === 'html' || ext === 'htm') {
    html = bodyOf(await file.text());
  } else throw new Error(`.${ext || 'unknown'} files are not supported. Use DOCX, PDF, TXT, MD or HTML.`);
  return { name, ext, html, notes, meta };
}
