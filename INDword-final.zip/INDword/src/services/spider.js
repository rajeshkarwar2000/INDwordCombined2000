/* Original "web-slinger" mascot art: simple figures drawn from joints, in different poses and suit colours.
   (Drawn in code, so no picture files are needed. Your own pictures can replace any pose in Settings.) */

/** state read by the Spider component; filled by applyAppearance() */
export const SPIDER = { on: false, version: 'classic', art: {} };

export const VERSIONS = {
  classic: { label: 'Classic', head: '#d9202f', torso: '#d9202f', arms: '#d9202f', legs: '#1d4ed8', line: '#7f1d1d', eye: '#ffffff', rim: '#ffffff' },
  midnight: { label: 'Midnight', head: '#111827', torso: '#111827', arms: '#111827', legs: '#1f2937', line: '#e11d2e', eye: '#ffffff', rim: '#e11d2e' },
  neon: { label: 'Neon', head: '#0f172a', torso: '#0f172a', arms: '#06b6d4', legs: '#ec4899', line: '#67e8f9', eye: '#f0abfc', rim: '#22d3ee' },
  street: { label: 'Street', head: '#dc2626', torso: '#18181b', arms: '#dc2626', legs: '#18181b', line: '#fbbf24', eye: '#fde68a', rim: '#fbbf24' },
  frost: { label: 'Frost', head: '#f8fafc', torso: '#e2e8f0', arms: '#38bdf8', legs: '#f1f5f9', line: '#1d4ed8', eye: '#1d4ed8', rim: '#1d4ed8' },
};

/* Each pose: head, neck, hip, arms[2] = [elbow, hand], legs[2] = [knee, foot]; arms[0]/legs[0] are in front.
   thread = web lines [x1,y1,x2,y2]; decor = extra lines. Coordinates are in a 100 x 100 box. */
export const POSES = {
  swing: { label: 'Swinging', head: [60, 30], neck: [56, 40], hip: [46, 60], tilt: 20,
    arms: [[[66, 30], [72, 19]], [[44, 46], [34, 42]]], legs: [[[52, 76], [40, 88]], [[34, 68], [22, 78]]],
    thread: [[72, 19, 97, 0]] },
  crouch: { label: 'Crouching', head: [52, 44], neck: [46, 52], hip: [34, 68], tilt: 15,
    arms: [[[54, 66], [60, 84]], [[46, 68], [46, 85]]], legs: [[[52, 74], [42, 88]], [[58, 72], [56, 88]]],
    decor: [[20, 90, 90, 90]] },
  crawl: { label: 'Wall crawl', head: [50, 20], neck: [50, 30], hip: [50, 58], tilt: 0,
    arms: [[[66, 36], [78, 28]], [[34, 26], [24, 12]]], legs: [[[66, 66], [72, 82]], [[36, 66], [28, 80]]],
    decor: [[88, 4, 88, 96], [92, 4, 92, 96]] },
  punch: { label: 'Punch', head: [44, 24], neck: [44, 34], hip: [40, 60], tilt: 8,
    arms: [[[60, 34], [80, 32]], [[34, 46], [46, 46]]], legs: [[[54, 72], [60, 88]], [[28, 74], [20, 88]]],
    decor: [[86, 24, 94, 20], [88, 32, 97, 32], [86, 40, 94, 44]] },
  hang: { label: 'Hanging', head: [50, 72], neck: [50, 62], hip: [50, 40], tilt: 180,
    arms: [[[62, 70], [72, 60]], [[38, 70], [34, 84]]], legs: [[[44, 30], [50, 17]], [[56, 30], [52, 17]]],
    thread: [[51, 0, 51, 17]] },
  thwip: { label: 'Web shot', head: [40, 18], neck: [40, 28], hip: [40, 56], tilt: -8,
    arms: [[[56, 30], [70, 22]], [[28, 40], [24, 52]]], legs: [[[34, 70], [28, 88]], [[48, 70], [54, 88]]],
    thread: [[70, 22, 98, 4], [70, 22, 98, 16], [70, 22, 98, 28]] },
  perch: { label: 'Perched', head: [50, 30], neck: [54, 40], hip: [60, 62], tilt: -10,
    arms: [[[62, 48], [72, 46]], [[56, 52], [66, 52]]], legs: [[[72, 46], [66, 62]], [[82, 48], [78, 62]]],
    decor: [[30, 64, 92, 64]] },
};
export const POSE_IDS = Object.keys(POSES);
