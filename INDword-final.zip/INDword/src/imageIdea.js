import { Extension } from '@tiptap/core';
import { Plugin } from '@tiptap/pm/state';
import { Decoration, DecorationSet } from '@tiptap/pm/view';
import { fileToJpeg } from './services/aiNotes.js';

const isIdea = (n) => n.type.name === 'callout' && n.attrs.type === 'imgidea';
// the picture prompt is the third paragraph of the box (title, caption, prompt)
const promptOf = (n) => (n.childCount > 2 ? n.child(2).textContent : n.childCount ? n.child(n.childCount - 1).textContent : '').trim();
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch { /* fall back below */ }
  try {
    const ta = document.createElement('textarea'); ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-999px;top:0;opacity:0';
    document.body.appendChild(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); return ok;
  } catch { return false; }
}

/** Tap an "image idea" box, choose a picture: the box (and its prompt) is replaced by the picture and its caption. */
function pickImage(view, nodePos) {
  const input = document.createElement('input');
  input.type = 'file'; input.accept = 'image/*';
  input.onchange = async () => {
    const f = input.files && input.files[0]; if (!f) return;
    try {
      const img = await fileToJpeg(f);
      const { state } = view; const cur = state.doc.nodeAt(nodePos);
      if (!cur || !isIdea(cur)) return;
      const w = view.dom.closest('.paged-stage') ? 339 : 460;
      const sch = state.schema; const caption = cur.childCount > 1 ? cur.child(1).textContent : '';
      const para = sch.nodes.paragraph.create({ borders: 'border:1.5px solid #000000;line-height:0' }, sch.nodes.image.create({ src: img.url, width: `${w}px` }));
      const out = [para];
      if (caption) out.push(sch.nodes.paragraph.create(null, sch.text(caption, sch.marks.italic ? [sch.marks.italic.create()] : [])));
      view.dispatch(state.tr.replaceWith(nodePos, nodePos + cur.nodeSize, out));
    } catch (e) { /* ignore */ }
  };
  input.click();
}

export const ImageIdea = Extension.create({
  name: 'imageIdea',
  addProseMirrorPlugins() {
    return [new Plugin({
      props: {
        decorations(state) {
          const decos = [];
          state.doc.descendants((node, pos) => {
            if (!isIdea(node)) return true;
            const text = promptOf(node);
            decos.push(Decoration.widget(pos + 1, (view, getPos) => {
              const bar = document.createElement('div'); bar.className = 'imgidea-bar'; bar.contentEditable = 'false';
              const add = document.createElement('button'); add.type = 'button'; add.className = 'imgidea-add'; add.textContent = '＋ Tap here to add the image';
              const copy = document.createElement('button'); copy.type = 'button'; copy.className = 'imgidea-copy'; copy.textContent = '⧉ Copy prompt';
              add.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); pickImage(view, getPos() - 1); });
              copy.addEventListener('click', async (e) => {
                e.preventDefault(); e.stopPropagation();
                const p = getPos() - 1, cur = view.state.doc.nodeAt(p), t = cur && isIdea(cur) ? promptOf(cur) : text;
                const ok = await copyText(t);
                copy.textContent = ok ? '✓ Copied' : 'Could not copy'; setTimeout(() => { copy.textContent = '⧉ Copy prompt'; }, 1600);
              });
              bar.append(add, copy); return bar;
            }, { side: -1, ignoreSelection: true, stopEvent: () => true, key: `idea-${pos}-${text.length}` }));
            return false;
          });
          return DecorationSet.create(state.doc, decos);
        },
        handleClickOn(view, pos, node, nodePos) {
          if (!isIdea(node)) return false;
          pickImage(view, nodePos);
          return true;
        },
      },
    })];
  },
});
