// Ink engine: the list of drawn objects of one document, undo / redo, saving, and the tool settings.
import R, { UNIT } from './render.js';

export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

/* ----- tool settings (kept on the device, shared by all documents) ----- */
export const DEFAULT_CFG = {
  pen: { color: '#111827', size: 4, pen: 'ball', line: 'solid', space: 10, nib: 'chisel', angle: 40, hold: true },
  brush: { color: '#e11d48', size: 18, brush: 'pencil', hold: true },
  highlighter: { color: '#facc15', size: 26, alpha: 0.45, tip: 'round', straight: false },
  laser: { color: '#ff0000', size: 10, mode: 'line', delay: 3, trail: 650 },
  eraser: { size: 28, mode: 'stroke' },
  shapes: { kind: 'rect', color: '#0a84ff', bw: 4, fill: false, fillColor: null, dash: 'solid', op: 1 },
};
export const PALETTE = ['#111827', '#e11d48', '#f97316', '#eab308', '#16a34a', '#0a84ff', '#7c3aed'];
export const HL_PALETTE = ['#facc15', '#fb7185', '#4ade80', '#38bdf8', '#c084fc', '#fb923c'];
export const LASER_COLORS = ['#ff0000', '#0a84ff', '#00e676', '#ffd600', '#ff9100', '#d500f9', '#111111'];

const KEY = 'indword.ink.v1';
export function loadInkPrefs() {
  const cfg = JSON.parse(JSON.stringify(DEFAULT_CFG));
  let extra = { fingerDraw: false, palette: null, hlPalette: null, tool: 'pen', dock: 'bottom' };
  try {
    const s = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (s) {
      for (const k in s.cfg || {}) if (cfg[k]) Object.assign(cfg[k], s.cfg[k]);
      extra = { ...extra, ...(s.extra || {}) };
    }
  } catch { /* ignore */ }
  return { cfg, ...extra };
}
export function saveInkPrefs(prefs) {
  try { localStorage.setItem(KEY, JSON.stringify({ cfg: prefs.cfg, extra: { fingerDraw: prefs.fingerDraw, palette: prefs.palette, hlPalette: prefs.hlPalette, tool: prefs.tool, dock: prefs.dock } })); } catch { /* ignore */ }
}

/* ----- the drawing of one document ----- */
export class InkEngine {
  constructor() {
    this.objs = [];      // every object, in drawing order. Coordinates are ink units on the page stage (see render.js)
    this.pitch = 0;      // distance between the tops of two pages at the time the objects were drawn (css px)
    this.undoS = []; this.redoS = [];
    this.subs = new Set();
    this.preview = null; // { id, o } object being moved or resized (drawn instead of the stored one)
    this.version = 0;
    this.forceAll = false; // true while exporting: every page keeps its canvas
    this.pendingSelect = null; // id of a freshly inserted picture that the Select tool should pick up
    R.onImage = () => this.emit('img'); // a picture finished loading: redraw
  }

  /* subscribe(fn(pagesOrNull)) : fn runs when objects change. Returns an unsubscribe function. */
  subscribe(fn) { this.subs.add(fn); return () => this.subs.delete(fn); }
  emit(kind = 'draw') { this.version += 1; this.subs.forEach((f) => f(kind)); }

  load(json) {
    const d = json && typeof json === 'object' ? json : {};
    this.objs = Array.isArray(d.objs) ? d.objs : [];
    this.pitch = d.pitch || 0;
    this.undoS = []; this.redoS = []; this.preview = null; this._bmap = null; this._bk = '';
    this.emit('load');
  }
  toJSON() { return { v: 1, pitch: this.pitch, objs: this.objs }; }
  get empty() { return this.objs.length === 0; }

  /* run fn while every page has its canvas (PDF export of ink that is off screen) */
  async withAll(fn) {
    await this.preload();
    this.forceAll = true; this.emit('force');
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(r, 160))));
    try { return await fn(); } finally { this.forceAll = false; this.emit('force'); }
  }

  /* wait until every picture of the drawing is loaded (needed before the ink is drawn into an export) */
  preload() { return Promise.all(this.objs.filter((o) => o.t === 'img').map((o) => R.loadImg(o))); }

  /* draw this document's ink for page i onto a 2d canvas context of a page bitmap (used by the PDF export) */
  pageHasInk(i, H, pitch) {
    const y0 = i * pitch, lo = y0 / UNIT - 20, hi = (y0 + H) / UNIT + 20;
    return this.objs.some((o) => { const b = R.bbox(o), m = (o.size || 0) * 1.2; return !(b.y - m > hi || b.y + b.h + m < lo); });
  }

  drawPageInto(ctx, i, W, H, pitch, scale) {
    const y0 = i * pitch, k = scale * UNIT, lo = y0 / UNIT - 40, hi = (y0 + H) / UNIT + 40;
    const list = this.objs.filter((o) => { const b = R.bbox(o), m = (o.size || 0) * 1.2; return !(b.y - m > hi || b.y + b.h + m < lo); });
    ctx.save();
    ctx.setTransform(k, 0, 0, k, 0, -y0 * scale); ctx.imageSmoothingQuality = 'high';
    for (const o of list) if (R.isHl(o)) { ctx.save(); ctx.globalCompositeOperation = 'multiply'; R.drawStroke(ctx, o, 0, null, false); ctx.restore(); }
    for (const o of list) if (!R.isHl(o)) R.drawObj(ctx, o);
    ctx.restore();
  }

  /* when the page height or paged layout changes, ink keeps its place on its page */
  relayout(pitch) {
    if (!pitch) return false;
    if (!this.pitch) { this.pitch = pitch; return false; }
    if (this.pitch === pitch) return false;
    const old = this.pitch;
    this.objs = this.objs.map((o) => {
      const b = R.bbox(o), pi = Math.max(0, Math.floor((b.y + b.h / 2) * UNIT / old));
      const dy = (pi * (pitch - old)) / UNIT;
      return dy ? R.transform(o, 0, 0, 1, 1, 0, dy) : o;
    });
    this.pitch = pitch;
    this.emit('layout');
    return true;
  }


  /* ----- drawings stay on their page when pages are added or removed before them -----
     Every page break has an id. After each layout the page where each break's following section starts is reported here;
     a drawing moves with the section it was drawn in. */
  pageOf(o, pitch) { const b = R.bbox(o); return Math.max(0, Math.floor(((b.y + b.h / 2) * UNIT) / pitch)); }
  resetBreaks() { this._bmap = null; this._bk = ''; }
  _shiftAll(fn, pitch) {
    const mv = (list) => list.map((o) => { const dp = fn(this.pageOf(o, pitch)); return dp ? R.transform(o, 0, 0, 1, 1, 0, (dp * pitch) / UNIT) : o; });
    this.objs = mv(this.objs); this.undoS = this.undoS.map(mv); this.redoS = this.redoS.map(mv);
  }
  followBreaks(map) {
    const key = JSON.stringify(map);
    if (key === this._bk) return;
    const old = this._bmap; this._bk = key; this._bmap = map;
    const pitch = this.pitch;
    if (!old || !pitch || (!this.objs.length && !this.undoS.length && !this.redoS.length)) return;
    const nb = new Map(map.map((b) => [b.id, b]));
    // delta (in pages) of every old section: section 0 is before the first break, section k follows old[k-1]
    const delta = [0]; const survives = [true];
    old.forEach((b, i) => {
      const n = nb.get(b.id);
      if (n) { delta.push(n.start - b.start); survives.push(true); } else { delta.push(delta[i] - 1); survives.push(false); }
    });
    // breaks that are new: which old section do they fall in?
    const added = old.map(() => []); added.unshift([]);
    let sec = 0; const oldIdx = new Map(old.map((b, i) => [b.id, i]));
    map.forEach((b) => { if (oldIdx.has(b.id)) sec = oldIdx.get(b.id) + 1; else added[sec].push(b.start); });
    added.forEach((a) => a.sort((x, y) => x - y));
    if (delta.every((d) => d === 0) && added.every((a) => !a.length)) return;
    const fn = (y) => {
      let k = 0; for (let i = 0; i < old.length; i += 1) if (old[i].start <= y) k = i + 1;
      let cur = y + delta[k];
      added[k].forEach((st) => { if (st <= cur) cur += 1; });
      return Math.max(0, cur) - y;
    };
    this._shiftAll(fn, pitch);
    this.emit('layout');
  }

  /* Page view: rearrange pages. order[i] = which old page goes to new position i (-1 = a new blank page).
     Pages left out lose their drawings, a page used twice gets copies. total = number of pages before the change. */
  reorderPages(order, total, pitch) {
    const P = pitch || this.pitch; if (!P) return;
    const where = new Map();
    order.forEach((old, ni) => { if (old < 0) return; if (!where.has(old)) where.set(old, []); where.get(old).push(ni); });
    const out = [];
    for (const o of this.objs) {
      const pi = this.pageOf(o, P);
      if (pi >= total) { out.push(o); continue; }
      const tg = where.get(pi); if (!tg) continue;
      tg.forEach((ni, k) => {
        const dy = ((ni - pi) * P) / UNIT; const base = dy ? R.transform(o, 0, 0, 1, 1, 0, dy) : o;
        out.push(k === 0 ? base : { ...base, id: uid(), seed: (Math.random() * 1e9) | 0 });
      });
    }
    this.undoS = []; this.redoS = []; this.preview = null; this._bmap = null; this._bk = '';
    this.set(out, 'layout');
  }
  /* put back a drawing saved before a page-view change */
  restore(objs) { this.undoS = []; this.redoS = []; this.preview = null; this._bmap = null; this._bk = ''; this.set(objs, 'layout'); }

  /* undo / redo (snapshots of the object list; objects themselves are never edited in place) */
  push() { this.undoS.push(this.objs); if (this.undoS.length > 80) this.undoS.shift(); this.redoS = []; }
  set(next, kind = 'draw') { this.objs = next; this.emit(kind); }
  add(o) { this.push(); this.set([...this.objs, o]); }
  remove(ids) { const s = new Set(ids); this.push(); this.set(this.objs.filter((o) => !s.has(o.id))); }
  update(id, patch) { this.push(); this.set(this.objs.map((o) => (o.id === id ? { ...o, ...patch } : o))); }
  tweak(id, patch) { if (this._tw !== id) { this.push(); this._tw = id; } this.set(this.objs.map((o) => (o.id === id ? { ...o, ...patch } : o))); } // a slider: one undo step for the whole drag
  endTweak() { this._tw = null; }
  replace(id, o) { this.push(); this.set(this.objs.map((x) => (x.id === id ? o : x))); }
  get canUndo() { return this.undoS.length > 0; }
  get canRedo() { return this.redoS.length > 0; }
  undo() { if (!this.undoS.length) return false; this.redoS.push(this.objs); this.set(this.undoS.pop(), 'undo'); return true; }
  redo() { if (!this.redoS.length) return false; this.undoS.push(this.objs); this.set(this.redoS.pop(), 'undo'); return true; }
  clearAll() { if (!this.objs.length) return; this.push(); this.set([]); }
  clearPage(pi, pitchCss, H) {
    const y0 = (pi * pitchCss) / UNIT, y1 = (pi * pitchCss + H) / UNIT;
    const keep = this.objs.filter((o) => { const b = R.bbox(o), cy = b.y + b.h / 2; return !(cy >= y0 && cy < y1); });
    if (keep.length === this.objs.length) return; this.push(); this.set(keep);
  }
  dup(id) {
    const o = this.objs.find((x) => x.id === id); if (!o) return null;
    const n = { ...R.transform(o, 0, 0, 1, 1, 30, 30), id: uid(), seed: (Math.random() * 1e9) | 0 };
    this.push(); this.set([...this.objs, n]); return n;
  }
  order(id, front) {
    const o = this.objs.find((x) => x.id === id); if (!o) return;
    const rest = this.objs.filter((x) => x.id !== id);
    this.push(); this.set(front ? [...rest, o] : [o, ...rest]);
  }
}

export { R, UNIT };
