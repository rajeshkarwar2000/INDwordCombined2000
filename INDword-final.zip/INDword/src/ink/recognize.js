// Hold-to-draw shapes: turns a rough freehand stroke into a clean shape (line, circle / ellipse, rectangle / square, triangle, diamond).
// Points are [x, y, pressure] in ink units. Returns { kind, x1, y1, x2, y2 } (the same fields a Shapes-tool object uses) or null.

const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);

function segDist(p, a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1], l2 = dx * dx + dy * dy;
  let t = l2 ? ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l2 : 0; t = Math.max(0, Math.min(1, t));
  return Math.hypot(p[0] - (a[0] + t * dx), p[1] - (a[1] + t * dy));
}
const toPoly = (pts, closed) => { const e = []; for (let i = 1; i < pts.length; i++) e.push([pts[i - 1], pts[i]]); if (closed) e.push([pts[pts.length - 1], pts[0]]); return e; };
const minDist = (p, edges) => { let m = 1e18; for (const [a, b] of edges) { const d = segDist(p, a, b); if (d < m) m = d; } return m; };

// evenly spaced points along a polyline
function resample(pts, n, closed) {
  const path = closed ? [...pts, pts[0]] : pts; let L = 0; for (let i = 1; i < path.length; i++) L += dist(path[i - 1], path[i]);
  if (!L) return [pts[0]];
  const out = [], step = L / n; let acc = 0, target = 0;
  for (let i = 1; i < path.length && out.length < n; i++) {
    const a = path[i - 1], b = path[i], d = dist(a, b);
    while (acc + d >= target && out.length < n) { const f = d ? (target - acc) / d : 0; out.push([a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f]); target += step; }
    acc += d;
  }
  return out;
}

const UNIT_POLY = {
  rect: [[0, 0], [1, 0], [1, 1], [0, 1]],
  tri: [[0.5, 0], [1, 1], [0, 1]],
  diamond: [[0.5, 0], [1, 0.5], [0.5, 1], [0, 0.5]],
  ellipse: Array.from({ length: 72 }, (_, i) => { const a = (i * Math.PI * 2) / 72; return [0.5 + 0.5 * Math.cos(a), 0.5 + 0.5 * Math.sin(a)]; }),
};

/** the angle of a line snapped to 0 / 45 / 90 ... degrees when it is within about 4 degrees of one */
export function snapAngle(x1, y1, x2, y2) {
  const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy); if (!L) return [x2, y2];
  const q = Math.PI / 4, a = Math.atan2(dy, dx), n = Math.round(a / q);
  if (Math.abs(a - n * q) < 0.07) return [x1 + L * Math.cos(n * q), y1 + L * Math.sin(n * q)];
  return [x2, y2];
}

// a straight stroke that ends with an arrow head drawn behind the tip (a short hook, a V, or a small triangle) is an arrow: start -> tip
function tryArrow(pts) {
  const a = pts[0], n = pts.length; let ti = 0, td = 0;
  for (let i = 0; i < n; i++) { const d = dist(a, pts[i]); if (d > td) { td = d; ti = i; } }
  if (td < 60 || ti < 3 || ti > n - 3) return null;
  const tip = pts[ti]; let dev = 0;
  for (let i = 0; i <= ti; i++) { const d = segDist(pts[i], a, tip); if (d > dev) dev = d; }
  const straight = dev <= 0.09 * td + 3;
  let ux = (a[0] - tip[0]) / td, uy = (a[1] - tip[1]) / td, ctrl = null;  // from the tip back along the shaft
  if (!straight) {
    // a curved shaft: one smooth bend of up to about a half turn (not a loop, not a zig-zag)
    if (dev > 0.6 * td) return null;
    const sh = resample(pts.slice(0, ti + 1), 18, false); let tot = 0, pos = 0, neg = 0;
    for (let i = 2; i < sh.length; i++) {
      const a1 = Math.atan2(sh[i - 1][1] - sh[i - 2][1], sh[i - 1][0] - sh[i - 2][0]), a2 = Math.atan2(sh[i][1] - sh[i - 1][1], sh[i][0] - sh[i - 1][0]);
      let d = a2 - a1; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; tot += d; if (d > 0.12) pos++; else if (d < -0.12) neg++;
    }
    if (Math.abs(tot) < 0.3 || Math.abs(tot) > 3.4 || (pos && neg && Math.min(pos, neg) > 2)) return null;
    let bi = ti; while (bi > 0 && dist(pts[bi], tip) < 0.18 * td) bi--;      // direction of the curve at its tip
    const bl = dist(pts[bi], tip) || 1; ux = (pts[bi][0] - tip[0]) / bl; uy = (pts[bi][1] - tip[1]) / bl;
    let pk = pts[0], pd = -1; for (let i = 0; i <= ti; i++) { const d = segDist(pts[i], a, tip); if (d > pd) { pd = d; pk = pts[i]; } }
    ctrl = [2 * pk[0] - (a[0] + tip[0]) / 2, 2 * pk[1] - (a[1] + tip[1]) / 2];  // the bend that passes through the farthest point
  }
  let lt = 0, maxD = 0, maxAlong = -1e9, maxLat = 0, minAlong = 1e9;
  for (let i = ti + 1; i < n; i++) {
    lt += dist(pts[i - 1], pts[i]);
    const px = pts[i][0] - tip[0], py = pts[i][1] - tip[1], along = px * ux + py * uy, lat = Math.abs(px * uy - py * ux);
    maxD = Math.max(maxD, Math.hypot(px, py)); maxAlong = Math.max(maxAlong, along); minAlong = Math.min(minAlong, along); maxLat = Math.max(maxLat, lat);
  }
  if (maxD < 0.1 * td || maxD > 0.6 * td) return null;                    // a head, not a second stroke
  if (minAlong < -0.1 * td || maxAlong < 0.05 * td || maxLat > 0.5 * td || lt > 2.2 * td) return null;
  const end = pts[n - 1], closing = dist(end, tip) < 0.4 * maxD && lt > 1.4 * maxD; // drawn all the way round: a filled triangle head
  if (ctrl) return { kind: closing ? 'tcarrow' : 'carrow', x1: a[0], y1: a[1], x2: tip[0], y2: tip[1], qx: ctrl[0], qy: ctrl[1] };
  const [ex, ey] = snapAngle(a[0], a[1], tip[0], tip[1]);
  return { kind: closing ? 'tarrow' : 'arrow', x1: a[0], y1: a[1], x2: ex, y2: ey };
}

export function recognize(pts) {
  if (!pts || pts.length < 6) return null;
  let L = 0, x0 = 1e18, y0 = 1e18, x1 = -1e18, y1 = -1e18, turn = 0;
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i];
    if (p[0] < x0) x0 = p[0]; if (p[1] < y0) y0 = p[1]; if (p[0] > x1) x1 = p[0]; if (p[1] > y1) y1 = p[1];
    if (i) L += dist(pts[i - 1], p);
  }
  const w = x1 - x0, h = y1 - y0;
  if (L < 70 || Math.max(w, h) < 40) return null;                       // too small to be a deliberate shape
  // total turning of the path (a closed loop turns about 360 degrees, a line hardly at all)
  const s = resample(pts, 48, false);
  for (let i = 2; i < s.length; i++) {
    const a1 = Math.atan2(s[i - 1][1] - s[i - 2][1], s[i - 1][0] - s[i - 2][0]), a2 = Math.atan2(s[i][1] - s[i - 1][1], s[i][0] - s[i - 1][0]);
    let d = a2 - a1; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; turn += d;
  }
  const a = pts[0], z = pts[pts.length - 1], gap = dist(a, z);
  const closed = gap < 0.22 * L && Math.abs(turn) > 3.7;

  if (!closed) {
    const ar = tryArrow(pts); if (ar) return ar;
    // straight line: every point stays close to the chord
    if (gap < 60) return null;
    let dev = 0; for (const p of pts) { const d = segDist(p, a, z); if (d > dev) dev = d; }
    if (dev < 0.07 * gap + 3 && L < 1.3 * gap) { const [ex, ey] = snapAngle(a[0], a[1], z[0], z[1]); return { kind: 'line', x1: a[0], y1: a[1], x2: ex, y2: ey }; }
    return null;
  }
  if (Math.min(w, h) < 0.18 * Math.max(w, h)) return null;              // a squashed loop is not a shape

  const samp = resample(pts, 72, true), norm = (w + h) / 2;
  let best = null;
  for (const [kind, unit] of Object.entries(UNIT_POLY)) {
    const poly = unit.map((p) => [x0 + p[0] * w, y0 + p[1] * h]), edges = toPoly(poly, true);
    // how far the stroke is from the shape, and how much of the shape the stroke covers
    let e1 = 0; for (const p of samp) e1 += minDist(p, edges); e1 /= samp.length;
    const strokeEdges = toPoly(samp, true), dense = resample(poly, 96, true);
    let e2 = 0; for (const p of dense) e2 += minDist(p, strokeEdges); e2 /= dense.length;
    const err = (e1 + e2) / 2 / norm;
    if (!best || err < best.err) best = { kind, err };
  }
  if (!best || best.err > 0.07) return null;

  let { kind } = best, bx0 = x0, by0 = y0, bx1 = x1, by1 = y1;
  const sq = Math.abs(w - h) / Math.max(w, h) < (kind === 'ellipse' ? 0.14 : 0.1);
  if (sq && (kind === 'ellipse' || kind === 'rect')) { // a circle or a square: make it exact, around the same centre
    const m = Math.max(w, h) / 2, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2; bx0 = cx - m; bx1 = cx + m; by0 = cy - m; by1 = cy + m;
  }
  return { kind, x1: bx0, y1: by0, x2: bx1, y2: by1 };
}
