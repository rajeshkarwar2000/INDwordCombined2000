// Ink rendering engine, ported from INDnote: pen / brush / highlighter strokes, shapes and the neon laser.
// Coordinates are "ink units": 1 unit = 0.6403 CSS px (INDnote's 1240-wide page mapped onto an A4 page of 794 px).
const TAU = Math.PI * 2;
const R = {};
export const UNIT = 794 / 1240; // css px per ink unit

  // ---------- seeded random ----------
  function rng(seed) {
    let a = (seed | 0) || 1;
    return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function shade(hex, d) {
    const n = (i) => Math.max(0, Math.min(255, parseInt(hex.slice(i, i + 2), 16) + d));
    return 'rgb(' + n(1) + ',' + n(3) + ',' + n(5) + ')';
  }
  function rgba(hex, a) { return 'rgba(' + parseInt(hex.slice(1, 3), 16) + ',' + parseInt(hex.slice(3, 5), 16) + ',' + parseInt(hex.slice(5, 7), 16) + ',' + a + ')'; }

  // ---------- path walker (stamps along a stroke at fixed spacing) ----------
  function newState(s) { return { started: false, lx: 0, ly: 0, lp: 0.5, acc: 0, pos: 0, rnd: rng(s.seed || 1), n: 0 }; }
  // The first stamp is placed once the direction of the stroke is known (so bristles never pile up into a dot at the start).
  function walk(pts, from, st, step, cb) {
    for (let i = Math.max(from, 0); i < pts.length; i++) {
      const p = pts[i];
      if (!st.started) { st.started = true; st.first = true; st.lx = p[0]; st.ly = p[1]; st.lp = p[2]; continue; }
      const dx = p[0] - st.lx, dy = p[1] - st.ly, d = Math.hypot(dx, dy);
      if (d < 1e-6) continue;
      const ux = dx / d, uy = dy / d; let s = 0;
      if (st.first) { st.first = false; cb(st.lx, st.ly, st.lp, ux, uy, d); }
      while (d - s >= step - st.acc) {
        s += step - st.acc; st.acc = 0; st.pos += step;
        const f = s / d;
        cb(st.lx + dx * f, st.ly + dy * f, st.lp + (p[2] - st.lp) * f, ux, uy, d);
      }
      st.acc += d - s; st.lx = p[0]; st.ly = p[1]; st.lp = p[2];
    }
  }

  // ---------- strokes ----------
  // Draws points [from..] of stroke s. For incremental drawing pass the same `st` each call.
  R.newStrokeState = newState;
  R.drawStroke = function (ctx, s, from, st, live) {
    const pts = s.pts;
    if (!pts.length) return;
    if (s.tool === 'hl') return drawHighlighter(ctx, s, live);
    st = st || newState(s);
    const size = s.size, col = s.color;
    if (s.tool === 'brush') return drawBrush(ctx, s, from, st);
    // pen
    const line = s.line || 'solid', space = s.space || 10;
    const step = Math.max(0.6, size * 0.14);
    const period = line === 'dotted' ? size * 1.2 + space : size * 3.2 + space;
    ctx.fillStyle = col;
    if (line !== 'solid') return drawDashed(ctx, s, line);
    if ((s.pen || 'ball') === 'ball') return drawBallPen(ctx, s, from, st);
    if (s.pen === 'natural' || s.pen === 'calligraphy' || s.pen === 'fountain') return drawVarPen(ctx, s, from, st);
    let typ = line !== 'solid' ? 'ball' : s.pen || 'ball';
    if (typ === 'fountain') typ = 'calligraphy';
    const nib = s.nib || 'chisel', ang = ((s.angle == null ? 40 : s.angle) * Math.PI) / 180;
    ctx.beginPath(); // all stamps of this call go into one path and are filled once (much faster than one fill per stamp)
    const circ = (x, y, r) => { ctx.moveTo(x + r, y); ctx.arc(x, y, r, 0, TAU); };
    walk(pts, from, st, step, (x, y, p, ux, uy) => {
      if (line === 'dotted' && !(st.pos % period < step - 1e-6 || st.pos === 0)) return;
      if (line === 'dashdot' && !(st.pos % period < size * 3.2)) return;
      if (typ === 'ball') circ(x, y, size / 2);
      else if (typ === 'natural') circ(x, y, (size / 2) * (0.3 + 1.4 * (p == null ? 0.5 : p)));
      else if (nib === 'pointed') {
        // copperplate pen: thick on downstrokes, hairline on upstrokes, swells with pressure
        st.dy = (st.dy || 0) * 0.7 + uy * 0.3;
        const down = Math.max(0, st.dy), pr = p == null ? 0.5 : p;
        circ(x, y, Math.max(0.5, (size / 2) * (0.35 + 1.25 * pr) * (0.16 + 0.84 * down)));
      } else {
        // broad-nib (chisel) calligraphy: width follows the angle of the nib
        const pr = p == null ? 0.5 : p, rx = size * 0.62 * (0.75 + 0.5 * pr);
        ctx.moveTo(x + rx * Math.cos(-ang), y + rx * Math.sin(-ang));
        ctx.ellipse(x, y, rx, Math.max(0.6, size * 0.075), -ang, 0, TAU);
      }
    });
    ctx.fill();
    if (st.final === undefined && pts.length === 1) { ctx.beginPath(); ctx.arc(pts[0][0], pts[0][1], size / 2, 0, TAU); ctx.fill(); }
  };

  // Dotted and dashed lines: one native dashed stroke along the smoothed path (redrawn whole, so the pattern stays continuous)
  function drawDashed(ctx, s, line) {
    const pts = s.pts, n = pts.length; if (!n) return; const size = s.size, gap = s.space || 10;
    ctx.save(); ctx.strokeStyle = ctx.fillStyle = s.color; ctx.lineWidth = size; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (n === 1) { ctx.beginPath(); ctx.arc(pts[0][0], pts[0][1], size / 2, 0, TAU); ctx.fill(); ctx.restore(); return; }
    ctx.setLineDash(line === 'dotted' ? [0.01, size * 1.2 + gap] : [Math.max(0.01, size * 2.2), gap + size]);
    ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < n - 1; i++) ctx.quadraticCurveTo(pts[i][0], pts[i][1], (pts[i][0] + pts[i + 1][0]) / 2, (pts[i][1] + pts[i + 1][1]) / 2);
    ctx.lineTo(pts[n - 1][0], pts[n - 1][1]); ctx.stroke(); ctx.restore();
  }
  // Natural, calligraphy and fountain pens work exactly like the ball pen: the finished part of the curve is one native stroke through the
  // quadratic midpoints, so it is cheap to draw, identical while drawing and once saved, and never has to be redrawn from scratch in pieces.
  // The width changes in small steps: every step is one more native stroke (round caps hide the joins). A flat nib is a round pen seen
  // through a squashed, rotated transform, so the same strokes give the calligraphic thick-and-thin line.
  function varGeom(s) {
    const size = s.size, cal = s.pen === 'calligraphy' || s.pen === 'fountain', flat = cal && s.nib !== 'pointed', pointed = cal && s.nib === 'pointed';
    const ang = ((s.angle == null ? 40 : s.angle) * Math.PI) / 180;
    return { size, flat, pointed, ang, minor: Math.max(0.8, size * 0.12), qs: Math.max(0.08, size * 0.06) };
  }
  // visible width of the pen for the segment a -> b (diameter of a round tip, or the long side of a flat nib)
  function varWidth(g, st, a, b, len) {
    const pr = ((a[2] == null ? 0.5 : a[2]) + (b[2] == null ? 0.5 : b[2])) / 2;
    let w;
    if (g.flat) w = 2 * g.size * 0.62 * (0.75 + 0.5 * pr);
    else if (g.pointed) { st.dy = (st.dy || 0) * 0.7 + (len ? (b[1] - a[1]) / len : 0) * 0.3; w = 2 * Math.max(0.5, (g.size / 2) * (0.35 + 1.25 * pr) * (0.16 + 0.84 * Math.max(0, st.dy))); }
    else {
      st.sp = st.sp == null ? len : st.sp * 0.7 + len * 0.3; st.rp = st.rp == null ? pr : st.rp * 0.6 + pr * 0.4;
      w = 2 * Math.max(0.5, (g.size / 2) * (0.3 + 1.4 * st.rp) * Math.max(0.6, Math.min(1.2, 1.25 - st.sp * 0.025)));
    }
    return Math.max(g.qs, Math.round(w / g.qs) * g.qs);
  }
  // runs fn(map) with the pen set up for width w; map turns a point into the space the stroke is drawn in
  function varStroke(ctx, g, w, fn) {
    ctx.lineWidth = w;
    if (!g.flat) { fn((x, y) => [x, y]); return; }
    const k = Math.max(0.02, Math.min(1, g.minor / w)), c = Math.cos(-g.ang), d = Math.sin(-g.ang), ca = Math.cos(g.ang), sa = Math.sin(g.ang);
    ctx.save(); ctx.transform(c, d, -d * k, c * k, 0, 0);
    fn((x, y) => [ca * x - sa * y, (sa * x + ca * y) / k]);
    ctx.restore();
  }
  function drawVarPen(ctx, s, from, st) {
    const pts = s.pts, n = pts.length; if (!n) return;
    const g = varGeom(s); ctx.save(); ctx.strokeStyle = ctx.fillStyle = s.color; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (n === 1) {
      const pr = pts[0][2] == null ? 0.5 : pts[0][2];
      if (g.flat) varStroke(ctx, g, g.size * 1.24 * (0.75 + 0.5 * pr), (m) => { const [x, y] = m(pts[0][0], pts[0][1]); ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 0.01, y); ctx.stroke(); });
      else { ctx.beginPath(); ctx.arc(pts[0][0], pts[0][1], Math.max(0.5, (g.size / 2) * (0.3 + 1.4 * pr)), 0, TAU); ctx.fill(); }
      ctx.restore(); return;
    }
    let i = Math.max(1, from || 0);
    if (i === 1 || st.bx == null) { st.bx = pts[0][0]; st.by = pts[0][1]; st.cw = null; st.sp = null; st.rp = null; st.dy = 0; i = 1; }
    let ops = [[st.bx, st.by]], w = st.cw;                    // ops[0] is the start point, then [control x, control y, end x, end y]
    const flush = () => {
      if (ops.length < 2 || w == null) return;
      varStroke(ctx, g, w, (m) => {
        ctx.beginPath(); const p0 = m(ops[0][0], ops[0][1]); ctx.moveTo(p0[0], p0[1]);
        for (let k = 1; k < ops.length; k++) { const o = ops[k], c = m(o[0], o[1]), e = m(o[2], o[3]); ctx.quadraticCurveTo(c[0], c[1], e[0], e[1]); }
        ctx.stroke();
      });
    };
    for (; i < n; i++) {
      const a = pts[i - 1], b = pts[i], mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2, len = Math.hypot(b[0] - a[0], b[1] - a[1]);
      const nw = varWidth(g, st, a, b, len);
      if (w == null) w = nw;
      else if (nw !== w) { flush(); ops = [[st.bx, st.by]]; w = nw; }
      ops.push([a[0], a[1], mx, my]); st.bx = mx; st.by = my;
    }
    st.cw = w;
    if (!st.noTail) ops.push([pts[n - 1][0], pts[n - 1][1], pts[n - 1][0], pts[n - 1][1]]); // last half segment (redrawn by the next call)
    flush(); ctx.restore();
  }
  // the unfinished last half-segment while drawing (on its own canvas, wiped every frame, like the ball pen)
  R.drawVarTail = function (ctx, s, st) {
    const pts = s.pts, n = pts.length; if (n < 2 || st.bx == null || st.cw == null) return;
    const g = varGeom(s), l = pts[n - 1]; ctx.save(); ctx.strokeStyle = ctx.fillStyle = s.color; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    varStroke(ctx, g, st.cw, (m) => { const a = m(st.bx, st.by), b = m(l[0], l[1]); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); });
    ctx.restore();
  };
  R.isVarPen = (s) => s.tool === 'pen' && (!s.line || s.line === 'solid') && (s.pen === 'natural' || s.pen === 'calligraphy' || s.pen === 'fountain');
  // Ball pen: one native round-capped stroke per new point, joined with quadratic curves (smooth, cheap, identical live and when committed)
  function drawBallPen(ctx, s, from, st) {
    const pts = s.pts, n = pts.length; if (!n) return;
    ctx.save(); ctx.strokeStyle = ctx.fillStyle = s.color; ctx.lineWidth = s.size; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (n === 1) { ctx.beginPath(); ctx.arc(pts[0][0], pts[0][1], s.size / 2, 0, TAU); ctx.fill(); ctx.restore(); return; }
    let i = Math.max(1, from || 0);
    if (i === 1 || st.bx == null) { st.bx = pts[0][0]; st.by = pts[0][1]; i = 1; }
    ctx.beginPath(); ctx.moveTo(st.bx, st.by);
    for (; i < n; i++) {
      const a = pts[i - 1], b = pts[i], mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
      ctx.quadraticCurveTo(a[0], a[1], mx, my); st.bx = mx; st.by = my;
    }
    ctx.lineTo(pts[n - 1][0], pts[n - 1][1]); // last half segment (redrawn by the next call)
    ctx.stroke(); ctx.restore();
    st.bx = st.bx; // midpoint kept for the next incremental call
  }

  function drawHighlighter(ctx, s, live) {
    const pts = s.pts; if (!pts.length) return;
    ctx.save();
    ctx.globalAlpha = s.alpha == null ? 0.45 : s.alpha;
    // multiply keeps the text under the highlight readable (the live layer uses a CSS multiply blend so it looks the same)
    ctx.globalCompositeOperation = live ? 'source-over' : 'multiply';
    const tip = s.tip || 'round';
    ctx.strokeStyle = ctx.fillStyle = s.color; ctx.lineWidth = s.size; ctx.lineJoin = tip === 'square' ? 'miter' : 'round';
    ctx.lineCap = tip === 'round' ? 'round' : tip === 'square' ? 'butt' : 'butt';
    if (tip === 'flat') { // chisel marker: a slanted flat nib swept along the path, filled once so overlaps do not darken
      const a = -Math.PI / 4, nx = Math.cos(a) * s.size / 2, ny = Math.sin(a) * s.size / 2;
      ctx.beginPath();
      const q = pts.length === 1 ? [pts[0], [pts[0][0] + 0.01, pts[0][1]]] : pts;
      for (let i = 1; i < q.length; i++) { const A = q[i - 1], B = q[i]; ctx.moveTo(A[0] - nx, A[1] - ny); ctx.lineTo(A[0] + nx, A[1] + ny); ctx.lineTo(B[0] + nx, B[1] + ny); ctx.lineTo(B[0] - nx, B[1] - ny); ctx.closePath(); }
      ctx.fill(); ctx.restore(); return;
    }
    ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
    if (pts.length === 1) ctx.lineTo(pts[0][0] + 0.01, pts[0][1]);
    for (let i = 1; i < pts.length - 1; i++) {
      const mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2;
      ctx.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
    }
    if (pts.length > 1) ctx.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
    ctx.stroke(); ctx.restore();
  }

  // brushes that are drawn as one smooth path (redrawn whole while drawing, like dashed lines and the highlighter)
  R.isWhole = (s) => s.t === 's' && ((s.tool === 'brush' && (s.brush === 'neon' || s.brush === 'marker')) || (s.tool === 'pen' && s.line && s.line !== 'solid') || s.tool === 'hl');
  function smoothPath(ctx, pts) {
    ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
    if (pts.length === 1) ctx.lineTo(pts[0][0] + 0.01, pts[0][1]);
    for (let i = 1; i < pts.length - 1; i++) ctx.quadraticCurveTo(pts[i][0], pts[i][1], (pts[i][0] + pts[i + 1][0]) / 2, (pts[i][1] + pts[i + 1][1]) / 2);
    if (pts.length > 1) ctx.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
  }
  function drawPathBrush(ctx, s, type) {
    const size = s.size, col = s.color, pts = s.pts; if (!pts.length) return;
    ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (type === 'neon') { // glowing tube: wide soft halos, the colour, then a white-hot core
      for (const [w, a, c] of [[2.1, 0.10, col], [1.55, 0.17, col], [1.1, 0.32, col], [0.62, 1, col], [0.22, 0.95, '#ffffff']]) {
        ctx.globalAlpha = a; ctx.strokeStyle = c; ctx.lineWidth = Math.max(0.6, size * w * 0.5); smoothPath(ctx, pts); ctx.stroke();
      }
    } else { // felt-tip marker: even, slightly see-through colour with a darker rim
      ctx.strokeStyle = shade(col, -38); ctx.globalAlpha = 0.9; ctx.lineWidth = size * 0.62; smoothPath(ctx, pts); ctx.stroke();
      ctx.strokeStyle = col; ctx.globalAlpha = 0.78; ctx.lineWidth = size * 0.5; smoothPath(ctx, pts); ctx.stroke();
    }
    ctx.restore();
  }
  const star4 = (ctx, x, y, r) => { ctx.moveTo(x, y - r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.quadraticCurveTo(x, y, x, y + r); ctx.quadraticCurveTo(x, y, x - r, y); ctx.quadraticCurveTo(x, y, x, y - r); };
  R.BRUSHES = [['pencil', 'Pencil'], ['oil', 'Oil'], ['spill', 'Spill'], ['watercolor', 'Watercolor'], ['crayon', 'Crayon'],
    ['charcoal', 'Charcoal'], ['chalk', 'Chalk'], ['airbrush', 'Airbrush'], ['inkbrush', 'Ink brush'], ['marker', 'Marker'], ['neon', 'Neon'], ['rainbow', 'Rainbow'], ['sparkle', 'Sparkle']];
  const STEP = { oil: 0.1, airbrush: 0.1, inkbrush: 0.07, rainbow: 0.1, sparkle: 0.22, charcoal: 0.12, chalk: 0.13 };

  function drawBrush(ctx, s, from, st) {
    const size = s.size, col = s.color, type = s.brush || 'pencil', rnd = st.rnd;
    if (type === 'neon' || type === 'marker') return drawPathBrush(ctx, s, type);
    if (!st.bristles) st.bristles = [-2, -1, 0, 1, 2].map((k) => shade(col, (rnd() - 0.5) * 70));
    const step = Math.max(0.8, size * (STEP[type] || 0.14));
    ctx.save();
    walk(s.pts, from, st, step, (x, y, p, ux, uy, seg) => {
      if (type === 'pencil') {
        ctx.fillStyle = rgba(col, 0.16); ctx.beginPath(); ctx.arc(x, y, size * 0.32, 0, TAU); ctx.fill();
        ctx.fillStyle = rgba(col, 0.55);
        for (let j = 0; j < 5; j++) { const a = rnd() * TAU, r = Math.sqrt(rnd()) * size * 0.5; ctx.fillRect(x + Math.cos(a) * r, y + Math.sin(a) * r, 1.1, 1.1); }
      } else if (type === 'oil') {
        ctx.fillStyle = rgba(col, 0.55); ctx.beginPath(); ctx.arc(x, y, size * 0.34, 0, TAU); ctx.fill();
        for (let k = -2; k <= 2; k++) {
          const ox = -uy * k * size * 0.17, oy = ux * k * size * 0.17;
          ctx.fillStyle = st.bristles[k + 2]; ctx.globalAlpha = 0.92;
          ctx.beginPath(); ctx.arc(x + ox, y + oy, size * 0.11, 0, TAU); ctx.fill();
        }
        ctx.globalAlpha = 1;
      } else if (type === 'spill') {
        const r = size * (0.8 + rnd() * 0.5);
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, rgba(col, 0.2)); g.addColorStop(1, rgba(col, 0));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
        if (rnd() < 0.1) {
          const a = rnd() * TAU, dd = size * (0.7 + rnd() * 0.9);
          ctx.fillStyle = rgba(col, 0.55); ctx.beginPath(); ctx.arc(x + Math.cos(a) * dd, y + Math.sin(a) * dd, 0.8 + rnd() * size * 0.22, 0, TAU); ctx.fill();
        }
      } else if (type === 'watercolor') {
        const r = size * 0.8;
        const g = ctx.createRadialGradient(x, y, r * 0.2, x, y, r);
        g.addColorStop(0, rgba(col, 0.07)); g.addColorStop(0.85, rgba(col, 0.06)); g.addColorStop(1, rgba(col, 0.14));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      } else if (type === 'charcoal') { // soft smudge plus rough grain and streaks along the stroke
        ctx.fillStyle = rgba(col, 0.07); ctx.beginPath(); ctx.arc(x, y, size * 0.42, 0, TAU); ctx.fill();
        ctx.fillStyle = rgba(col, 0.5);
        for (let j = 0; j < 7; j++) { const a = rnd() * TAU, r = Math.sqrt(rnd()) * size * 0.5; ctx.fillRect(x + Math.cos(a) * r, y + Math.sin(a) * r, 0.8 + rnd() * 2.4, 0.8 + rnd() * 1.6); }
        ctx.save(); ctx.translate(x, y); ctx.rotate(Math.atan2(uy, ux) + (rnd() - 0.5) * 0.5); ctx.fillStyle = rgba(col, 0.1);
        ctx.fillRect(-size * 0.2, (rnd() - 0.5) * size * 0.8, size * 0.4, 0.8 + rnd() * 1.4); ctx.restore();
      } else if (type === 'chalk') { // dusty, broken colour with gaps
        ctx.fillStyle = rgba(col, 0.6);
        for (let j = 0; j < 12; j++) { const a = rnd() * TAU, r = Math.sqrt(rnd()) * size * 0.5, keep = rnd() > 0.28, sz = 1 + rnd() * 2.4; if (keep) ctx.fillRect(x + Math.cos(a) * r, y + Math.sin(a) * r, sz, sz); }
        ctx.fillStyle = rgba(col, 0.1); ctx.beginPath(); ctx.arc(x, y, size * 0.36, 0, TAU); ctx.fill();
      } else if (type === 'airbrush') { // soft spray: a faint haze and fine speckles
        const r = size * 0.75, g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, rgba(col, 0.055)); g.addColorStop(1, rgba(col, 0));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
        ctx.fillStyle = rgba(col, 0.5);
        for (let j = 0; j < 10; j++) { const a = rnd() * TAU, rr = (rnd() + rnd()) * 0.5 * size * 0.75; ctx.fillRect(x + Math.cos(a) * rr, y + Math.sin(a) * rr, 0.9 + rnd() * 0.6, 0.9 + rnd() * 0.6); }
      } else if (type === 'inkbrush') { // calligraphy brush: swells with pressure, thins when you move fast, tapers at the start
        st.sp = st.sp == null ? seg : st.sp * 0.85 + seg * 0.15; st.ib = (st.ib || 0) + 1;
        const pr = p == null ? 0.5 : p, sf = Math.max(0.45, Math.min(1.25, 1.3 - st.sp * 0.035)), tp = Math.min(1, 0.35 + st.ib * 0.1);
        ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, Math.max(0.5, size * 0.5 * (0.45 + 0.9 * pr) * sf * tp), 0, TAU); ctx.fill();
      } else if (type === 'rainbow') {
        ctx.fillStyle = `hsl(${(st.pos * 0.9) % 360},90%,55%)`; ctx.beginPath(); ctx.arc(x, y, size * 0.4, 0, TAU); ctx.fill();
      } else if (type === 'sparkle') { // glitter: dots and little four-point stars around the path
        for (let j = 0; j < 4; j++) {
          const a = rnd() * TAU, r = Math.sqrt(rnd()) * size * 0.55, k = rnd(), sz = 0.8 + rnd() * size * 0.14, px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
          ctx.fillStyle = k < 0.35 ? col : k < 0.7 ? shade(col, 70) : '#ffffff'; ctx.globalAlpha = 0.92; ctx.beginPath();
          if (k > 0.82) star4(ctx, px, py, sz * 2.4); else ctx.arc(px, py, sz, 0, TAU);
          ctx.fill();
        }
        ctx.globalAlpha = 1;
      } else { // crayon
        ctx.fillStyle = rgba(col, 0.78);
        for (let j = 0; j < 9; j++) { const a = rnd() * TAU, r = Math.sqrt(rnd()) * size * 0.5, sz = 1 + rnd() * 2.2; ctx.fillRect(x + Math.cos(a) * r, y + Math.sin(a) * r, sz, sz); }
      }
    });
    if (s.pts.length === 1) { // a tap leaves a small dab (never drawn while a stroke is still being drawn)
      ctx.fillStyle = type === 'rainbow' ? 'hsl(0,90%,55%)' : rgba(col, 0.6); ctx.beginPath(); ctx.arc(s.pts[0][0], s.pts[0][1], size * 0.4, 0, TAU); ctx.fill();
    }
    ctx.restore();
  }

  // ---------- shapes ----------
  const poly = {
    tri: [[.5, 0], [1, 1], [0, 1]], rtri: [[0, 0], [1, 1], [0, 1]], diamond: [[.5, 0], [1, .5], [.5, 1], [0, .5]],
    para: [[.2, 0], [1, 0], [.8, 1], [0, 1]], trap: [[.2, 0], [.8, 0], [1, 1], [0, 1]],
    plus: [[.35, 0], [.65, 0], [.65, .35], [1, .35], [1, .65], [.65, .65], [.65, 1], [.35, 1], [.35, .65], [0, .65], [0, .35], [.35, .35]],
    arrowR: [[0, .3], [.6, .3], [.6, 0], [1, .5], [.6, 1], [.6, .7], [0, .7]],
    bolt: [[.6, 0], [.15, .55], [.45, .55], [.35, 1], [.85, .4], [.55, .4]],
    bubble: [[0, 0], [1, 0], [1, .75], [.4, .75], [.2, 1], [.25, .75], [0, .75]],
  };
  const regular = (n, rot) => Array.from({ length: n }, (_, i) => { const a = rot + (i * TAU) / n; return [.5 + Math.cos(a) * .5, .5 + Math.sin(a) * .5]; });
  const star = (n, inner) => Array.from({ length: n * 2 }, (_, i) => { const a = -Math.PI / 2 + (i * Math.PI) / n, r = i % 2 ? inner * .5 : .5; return [.5 + Math.cos(a) * r, .5 + Math.sin(a) * r]; });
  poly.pent = regular(5, -Math.PI / 2); poly.hex = regular(6, 0); poly.oct = regular(8, Math.PI / 8);
  poly.star = star(5, .42); poly.star4 = star(4, .38);
  R.SHAPES = [
    ['line', 'Line'], ['arrow', 'Arrow'], ['tarrow', 'Triangle arrow'], ['darrow', 'Double arrow'], ['carrow', 'Curved arrow'], ['tcarrow', 'Curved triangle arrow'], ['rect', 'Rectangle'], ['round', 'Rounded'], ['ellipse', 'Ellipse'],
    ['tri', 'Triangle'], ['rtri', 'Right tri.'], ['diamond', 'Diamond'], ['para', 'Parallelogram'], ['trap', 'Trapezoid'], ['pent', 'Pentagon'],
    ['hex', 'Hexagon'], ['oct', 'Octagon'], ['star', 'Star'], ['star4', '4-point star'], ['heart', 'Heart'], ['cloud', 'Cloud'],
    ['plus', 'Cross'], ['check', 'Check'], ['bubble', 'Speech'], ['arrowR', 'Block arrow'], ['moon', 'Crescent'], ['bolt', 'Lightning'],
  ];
  R.isLineShape = (k) => k === 'line' || k === 'arrow' || k === 'darrow' || k === 'tarrow';

  function shapePath(ctx, o) {
    const x = Math.min(o.x1, o.x2), y = Math.min(o.y1, o.y2), w = Math.abs(o.x2 - o.x1), h = Math.abs(o.y2 - o.y1);
    const P = (u, v) => [x + u * w, y + v * h];
    const k = o.kind; ctx.beginPath();
    if (k === 'rect') ctx.rect(x, y, w, h);
    else if (k === 'round') { const r = Math.min(w, h) * 0.2; ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
    else if (k === 'ellipse') ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, TAU);
    else if (k === 'heart') {
      const m = (a, b) => P(a, b);
      ctx.moveTo(...m(.5, .95)); ctx.bezierCurveTo(...m(.1, .62), ...m(0, .4), ...m(0, .27)); ctx.bezierCurveTo(...m(0, .1), ...m(.15, 0), ...m(.3, 0));
      ctx.bezierCurveTo(...m(.4, 0), ...m(.47, .06), ...m(.5, .16)); ctx.bezierCurveTo(...m(.53, .06), ...m(.6, 0), ...m(.7, 0));
      ctx.bezierCurveTo(...m(.85, 0), ...m(1, .1), ...m(1, .27)); ctx.bezierCurveTo(...m(1, .4), ...m(.9, .62), ...m(.5, .95)); ctx.closePath();
    } else if (k === 'cloud') {
      const m = (a, b) => P(a, b);
      ctx.moveTo(...m(.25, .85)); ctx.bezierCurveTo(...m(.05, .85), ...m(0, .55), ...m(.2, .5)); ctx.bezierCurveTo(...m(.15, .25), ...m(.4, .15), ...m(.5, .3));
      ctx.bezierCurveTo(...m(.6, .05), ...m(.9, .15), ...m(.85, .45)); ctx.bezierCurveTo(...m(1.05, .5), ...m(1, .85), ...m(.78, .85)); ctx.closePath();
    } else if (k === 'moon') {
      const m = (a, b) => P(a, b);
      ctx.moveTo(...m(.7, .05)); ctx.bezierCurveTo(...m(.1, .1), ...m(.1, .9), ...m(.7, .95)); ctx.bezierCurveTo(...m(.4, .75), ...m(.4, .25), ...m(.7, .05)); ctx.closePath();
    } else if (k === 'check') { const a = [[.05, .55], [.38, .9], [.95, .12]]; a.forEach((p, i) => ctx[i ? 'lineTo' : 'moveTo'](...P(p[0], p[1]))); }
    else if (poly[k]) { poly[k].forEach((p, i) => ctx[i ? 'lineTo' : 'moveTo'](...P(p[0], p[1]))); ctx.closePath(); }
  }

  const isCurved = (k) => k === 'carrow' || k === 'tcarrow';
  /* control point of a curved arrow: kept in the object (qx, qy) or a gentle default bend */
  const curveCtl = (o) => (o.qx != null ? [o.qx, o.qy] : [(o.x1 + o.x2) / 2 - (o.y2 - o.y1) * 0.35, (o.y1 + o.y2) / 2 + (o.x2 - o.x1) * 0.35]);
  R.isCurved = isCurved;
  R.PT = 1240 / 595.28;
  function drawShape(ctx, o) {
    ctx.save();
    ctx.globalAlpha = o.op == null ? 1 : o.op;
    ctx.strokeStyle = o.color; ctx.fillStyle = o.fillColor || o.color; ctx.lineWidth = o.bw; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    const dash = o.dash === 'dashed' ? [o.bw * 3, o.bw * 2.2] : o.dash === 'dotted' ? [0.01, o.bw * 2.4] : [];
    if (isCurved(o.kind)) { // curved arrow: a smooth bend with the head turned along the end of the curve
      const [qx, qy] = curveCtl(o);
      ctx.setLineDash(dash); ctx.beginPath(); ctx.moveTo(o.x1, o.y1); ctx.quadraticCurveTo(qx, qy, o.x2, o.y2); ctx.stroke(); ctx.setLineDash([]);
      const a = Math.atan2(o.y2 - qy, o.x2 - qx), bx = o.x2, by = o.y2;
      if (o.kind === 'tcarrow') {
        const L = Math.max(16, o.bw * 5.5), w = L * 0.46;
        ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx - L * Math.cos(a) + w * Math.sin(a), by - L * Math.sin(a) - w * Math.cos(a)); ctx.lineTo(bx - L * Math.cos(a) - w * Math.sin(a), by - L * Math.sin(a) + w * Math.cos(a)); ctx.closePath(); ctx.fill(); ctx.stroke();
      } else {
        const L = Math.max(14, o.bw * 4.5);
        ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx - L * Math.cos(a - 0.5), by - L * Math.sin(a - 0.5)); ctx.moveTo(bx, by); ctx.lineTo(bx - L * Math.cos(a + 0.5), by - L * Math.sin(a + 0.5)); ctx.stroke();
      }
      ctx.restore(); return;
    }
    if (R.isLineShape(o.kind)) {
      ctx.setLineDash(dash);
      ctx.beginPath(); ctx.moveTo(o.x1, o.y1); ctx.lineTo(o.x2, o.y2); ctx.stroke(); ctx.setLineDash([]);
      const head = (ax, ay, bx, by) => {
        const a = Math.atan2(by - ay, bx - ax), L = Math.max(14, o.bw * 4.5);
        ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx - L * Math.cos(a - 0.5), by - L * Math.sin(a - 0.5));
        ctx.moveTo(bx, by); ctx.lineTo(bx - L * Math.cos(a + 0.5), by - L * Math.sin(a + 0.5)); ctx.stroke();
      };
      const tri = (ax, ay, bx, by) => { // filled triangle head
        const a = Math.atan2(by - ay, bx - ax), L = Math.max(16, o.bw * 5.5), w = L * 0.46;
        ctx.setLineDash([]); ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx - L * Math.cos(a) + w * Math.sin(a), by - L * Math.sin(a) - w * Math.cos(a)); ctx.lineTo(bx - L * Math.cos(a) - w * Math.sin(a), by - L * Math.sin(a) + w * Math.cos(a)); ctx.closePath(); ctx.fillStyle = o.color; ctx.fill(); ctx.stroke();
      };
      if (o.kind === 'tarrow') tri(o.x1, o.y1, o.x2, o.y2);
      else if (o.kind !== 'line') head(o.x1, o.y1, o.x2, o.y2);
      if (o.kind === 'darrow') head(o.x2, o.y2, o.x1, o.y1);
    } else {
      shapePath(ctx, o);
      if (o.fill && o.kind !== 'check') { const ga = ctx.globalAlpha; ctx.globalAlpha = ga * 0.9; ctx.fill(); ctx.globalAlpha = ga; }
      ctx.setLineDash(dash); ctx.stroke();
    }
    ctx.restore();
  }

  // al = alpha per point (the tail of a trail fades first), o.taper thins the faded part, o.head draws the glowing pointer dot.
  R.drawLaser = function (ctx, pts, al, color, size, o) {
    o = o || {}; const n = pts.length; if (!n && !o.head) return;
    const A = (i) => (al ? al[i] : (o.alpha == null ? 1 : o.alpha));
    ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (!o.dot && n > 1) {
      const buckets = new Map(), mid = (i, j) => [(pts[i].x + pts[j].x) / 2, (pts[i].y + pts[j].y) / 2];
      for (let i = 0; i < n; i++) {
        const a = A(i); if (a <= 0.03) continue; let seg;
        if (i === 0) { const m = mid(0, 1); seg = [pts[0].x, pts[0].y, null, null, m[0], m[1]]; }
        else if (i === n - 1) { const m = mid(n - 2, n - 1); seg = [m[0], m[1], null, null, pts[i].x, pts[i].y]; }
        else { const m0 = mid(i - 1, i), m1 = mid(i, i + 1); seg = [m0[0], m0[1], pts[i].x, pts[i].y, m1[0], m1[1]]; }
        const k = Math.round(a * 8); let l = buckets.get(k); if (!l) buckets.set(k, (l = [])); l.push(seg);
      }
      for (const [wm, pa, col] of [[2.3, 0.17, color], [1, 1, color], [0.38, 0.97, '#fff']]) {
        ctx.strokeStyle = col; ctx.lineCap = wm >= 2 ? 'butt' : 'round'; // butt on the soft glow avoids visible beads where alpha levels meet
        for (const [k, segs] of buckets) {
          const a = k / 8, sc = o.taper ? 0.35 + 0.65 * a : 1; ctx.globalAlpha = a * pa; ctx.lineWidth = Math.max(1, size * wm * sc); ctx.beginPath();
          for (const g of segs) { ctx.moveTo(g[0], g[1]); if (g[2] == null) ctx.lineTo(g[4], g[5]); else ctx.quadraticCurveTo(g[2], g[3], g[4], g[5]); }
          ctx.stroke();
        }
      }
    }
    const hd = o.head || (n === 1 && o.dot ? { x: pts[0].x, y: pts[0].y, a: A(0) } : null);
    if (hd && hd.a > 0.02) {
      const r = size * 0.95, gr = ctx.createRadialGradient(hd.x, hd.y, 0, hd.x, hd.y, r * 2.7);
      gr.addColorStop(0, rgba(color, 0.85)); gr.addColorStop(0.4, rgba(color, 0.45)); gr.addColorStop(1, rgba(color, 0));
      ctx.globalAlpha = hd.a; ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(hd.x, hd.y, r * 2.7, 0, TAU); ctx.fill();
      ctx.fillStyle = color; ctx.beginPath(); ctx.arc(hd.x, hd.y, r, 0, TAU); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(hd.x, hd.y, r * 0.4, 0, TAU); ctx.fill();
    }
    ctx.restore();
  };
  R.drawNeon = function (ctx, pts, color, size, glow, alpha, dot) { R.drawLaser(ctx, pts, null, color, size, { alpha, dot, head: dot ? { x: pts[pts.length - 1].x, y: pts[pts.length - 1].y, a: alpha } : null }); };

  // ---------- pictures placed with the INDnote tools ----------
  const imgs = new Map(); // iid -> { img, ok, p }
  R.onImage = null;       // called when a picture has finished loading, so the page can be redrawn
  R.img = function (o) {
    let e = imgs.get(o.iid);
    if (!e) {
      e = { img: new Image(), ok: false, p: null }; imgs.set(o.iid, e);
      e.p = new Promise((res) => { e.img.onload = () => { e.ok = true; res(true); R.onImage && R.onImage(); }; e.img.onerror = () => res(false); });
      e.img.src = o.src;
    }
    return e;
  };
  R.loadImg = (o) => R.img(o).p;
  function drawImg(ctx, o) {
    const e = R.img(o), x = Math.min(o.x1, o.x2), y = Math.min(o.y1, o.y2), w = Math.abs(o.x2 - o.x1), h = Math.abs(o.y2 - o.y1);
    if (!e.ok) { ctx.save(); ctx.fillStyle = 'rgba(120,130,150,.12)'; ctx.fillRect(x, y, w, h); ctx.restore(); return; }
    ctx.save(); ctx.globalAlpha = o.op == null ? 1 : o.op; ctx.imageSmoothingQuality = 'high'; ctx.drawImage(e.img, x, y, w, h); ctx.restore();
  }

  R.drawObj = function (ctx, o) {
    if (o.t === 's') R.drawStroke(ctx, o, 0, null, false);
    else if (o.t === 'shape') drawShape(ctx, o);
    else if (o.t === 'img') drawImg(ctx, o);
  };
  R.isHl = (o) => o.t === 's' && o.tool === 'hl';
  R.bbox = function (o) {
    if (o.t === 's') {
      let a = 1e9, b = 1e9, c = -1e9, d = -1e9;
      for (const p of o.pts) { if (p[0] < a) a = p[0]; if (p[1] < b) b = p[1]; if (p[0] > c) c = p[0]; if (p[1] > d) d = p[1]; }
      const r = o.size / 2 + 1; return { x: a - r, y: b - r, w: c - a + 2 * r, h: d - b + 2 * r };
    }
    if (isCurved(o.kind)) { const [qx, qy] = curveCtl(o), mx = (qx + (o.x1 + o.x2) / 2) / 2, my = (qy + (o.y1 + o.y2) / 2) / 2, pp = (o.bw || 0) / 2 + 8; const xs = [o.x1, o.x2, mx], ys = [o.y1, o.y2, my]; return { x: Math.min(...xs) - pp, y: Math.min(...ys) - pp, w: Math.max(...xs) - Math.min(...xs) + 2 * pp, h: Math.max(...ys) - Math.min(...ys) + 2 * pp }; }
    const p = (o.bw || 0) / 2 + 2; return { x: Math.min(o.x1, o.x2) - p, y: Math.min(o.y1, o.y2) - p, w: Math.abs(o.x2 - o.x1) + 2 * p, h: Math.abs(o.y2 - o.y1) + 2 * p };
  };
  // scale about (ox,oy) then translate; returns a new object
  R.transform = function (o, ox, oy, sx, sy, dx, dy) {
    const X = (v) => ox + (v - ox) * sx + dx, Y = (v) => oy + (v - oy) * sy + dy;
    const n = Object.assign({}, o);
    if (o.t === 's') { n.pts = o.pts.map((p) => [X(p[0]), Y(p[1]), p[2]]); n.size = Math.max(0.5, o.size * (Math.abs(sx) + Math.abs(sy)) / 2); }
    else { n.x1 = X(o.x1); n.y1 = Y(o.y1); n.x2 = X(o.x2); n.y2 = Y(o.y2); if (o.qx != null) { n.qx = X(o.qx); n.qy = Y(o.qy); } }
    return n;
  };

  function segDist(px, py, ax, ay, bx, by) {
    const dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
    let t = l2 ? ((px - ax) * dx + (py - ay) * dy) / l2 : 0; t = Math.max(0, Math.min(1, t));
    return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
  }
  R.segDist = segDist;
  const bbCache = new WeakMap(); // strokes are never edited in place, so their bounding box is measured once
  R.hit = function (o, x, y, r) {
    if (o.t === 's') {
      const lim = o.size / 2 + r, p = o.pts;
      let bb = bbCache.get(o); if (!bb) { bb = R.bbox(o); bbCache.set(o, bb); }
      if (x < bb.x - lim || x > bb.x + bb.w + lim || y < bb.y - lim || y > bb.y + bb.h + lim) return false;
      if (p.length === 1) return Math.hypot(x - p[0][0], y - p[0][1]) <= lim;
      for (let i = 1; i < p.length; i++) if (segDist(x, y, p[i - 1][0], p[i - 1][1], p[i][0], p[i][1]) <= lim) return true;
      return false;
    }
    const b = R.bbox(o);
    if (o.t === 'shape' && isCurved(o.kind)) { const [qx, qy] = curveCtl(o); let px = o.x1, py = o.y1; for (let i = 1; i <= 16; i++) { const t = i / 16, u = 1 - t, X = u * u * o.x1 + 2 * u * t * qx + t * t * o.x2, Y = u * u * o.y1 + 2 * u * t * qy + t * t * o.y2; if (segDist(x, y, px, py, X, Y) <= o.bw / 2 + r + 6) return true; px = X; py = Y; } return false; }
    if (o.t === 'shape' && R.isLineShape(o.kind)) return segDist(x, y, o.x1, o.y1, o.x2, o.y2) <= o.bw / 2 + r + 6;
    return x >= b.x - r && x <= b.x + b.w + r && y >= b.y - r && y <= b.y + b.h + r;
  };

export default R;
export { R };
