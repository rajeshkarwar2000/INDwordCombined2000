import { useEffect, useRef, useState } from 'react';

const hexToHsv = (hex) => {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); const n = m ? parseInt(m[1], 16) : 0x111827;
  const r = ((n >> 16) & 255) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
  let h = 0; if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
  return { h, s: mx ? d / mx : 0, v: mx };
};
const hsvToRgb = (h, s, v) => {
  const c = v * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = v - c; let r = 0, g = 0, b = 0;
  if (h < 60) [r, g, b] = [c, x, 0]; else if (h < 120) [r, g, b] = [x, c, 0]; else if (h < 180) [r, g, b] = [0, c, x]; else if (h < 240) [r, g, b] = [0, x, c]; else if (h < 300) [r, g, b] = [x, 0, c]; else [r, g, b] = [c, 0, x];
  return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
};
const toHex = (h, s, v) => `#${hsvToRgb(h, s, v).map((x) => x.toString(16).padStart(2, '0')).join('')}`;

/** A colour wheel: hue around the circle, saturation towards the edge, a brightness slider and a hex box. Calls onChange(hex) while you drag. */
export default function ColorWheel({ value, onChange, size = 190, className = '' }) {
  const cv = useRef(null), drag = useRef(false);
  const [hsv, setHsv] = useState(() => hexToHsv(value));
  const [hex, setHex] = useState((value || '#111827').toLowerCase());
  const last = useRef(value);
  useEffect(() => { if (value && value.toLowerCase() !== last.current?.toLowerCase()) { setHsv(hexToHsv(value)); setHex(value.toLowerCase()); last.current = value; } }, [value]);

  useEffect(() => { // the disc, redrawn when the brightness changes
    const c = cv.current; if (!c) return;
    const d = Math.min(window.devicePixelRatio || 1, 2), px = Math.round(size * d); c.width = px; c.height = px;
    const x = c.getContext('2d'), img = x.createImageData(px, px), R = px / 2;
    for (let j = 0; j < px; j++) for (let i = 0; i < px; i++) {
      const dx = i + 0.5 - R, dy = j + 0.5 - R, r = Math.hypot(dx, dy), k = (j * px + i) * 4;
      if (r > R) { img.data[k + 3] = 0; continue; }
      let h = (Math.atan2(dy, dx) * 180) / Math.PI; if (h < 0) h += 360;
      const [rr, gg, bb] = hsvToRgb(h, Math.min(1, r / (R - 1)), hsv.v);
      img.data[k] = rr; img.data[k + 1] = gg; img.data[k + 2] = bb; img.data[k + 3] = r > R - 1.2 ? 255 * (R - r) / 1.2 : 255;
    }
    x.putImageData(img, 0, 0);
  }, [hsv.v, size]);

  const emit = (n) => { setHsv(n); const hx = toHex(n.h, n.s, n.v); setHex(hx); last.current = hx; onChange(hx); };
  const pick = (e) => {
    const r = cv.current.getBoundingClientRect(), R = r.width / 2, dx = e.clientX - r.left - R, dy = e.clientY - r.top - R;
    let h = (Math.atan2(dy, dx) * 180) / Math.PI; if (h < 0) h += 360;
    emit({ h, s: Math.min(1, Math.hypot(dx, dy) / R), v: hsv.v });
  };
  const ang = (hsv.h * Math.PI) / 180, kx = size / 2 + Math.cos(ang) * hsv.s * (size / 2), ky = size / 2 + Math.sin(ang) * hsv.s * (size / 2);
  const full = toHex(hsv.h, hsv.s, 1);
  return (
    <div className={`ink-ui select-none ${className}`} style={{ width: size }} data-inkui="1" onPointerDown={(e) => e.stopPropagation()}>
      <div className="relative" style={{ width: size, height: size, touchAction: 'none' }}>
        <canvas ref={cv} style={{ width: size, height: size, borderRadius: '50%', boxShadow: '0 0 0 1px rgba(0,0,0,.15)', touchAction: 'none' }}
          onPointerDown={(e) => { drag.current = true; try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /* ignore */ } pick(e); }}
          onPointerMove={(e) => { if (drag.current) pick(e); }} onPointerUp={() => { drag.current = false; }} onPointerCancel={() => { drag.current = false; }} />
        <span className="pointer-events-none absolute rounded-full" style={{ left: kx - 11, top: ky - 11, width: 22, height: 22, background: hex, border: '3px solid #fff', boxShadow: '0 0 0 1.5px rgba(0,0,0,.55), 0 2px 6px rgba(0,0,0,.35)' }} />
      </div>
      <label className="mt-3 block text-xs opacity-70">Brightness</label>
      <input type="range" min={0} max={100} value={Math.round(hsv.v * 100)} onChange={(e) => emit({ ...hsv, v: Number(e.target.value) / 100 })} className="h-7 w-full appearance-none rounded-full" style={{ background: `linear-gradient(90deg,#000,${full})`, touchAction: 'pan-x' }} />
      <div className="mt-2 flex items-center gap-2">
        <span className="h-8 w-8 shrink-0 rounded-full border border-black/20" style={{ background: hex }} />
        <input value={hex} onChange={(e) => { const v = e.target.value.startsWith('#') ? e.target.value : `#${e.target.value}`; setHex(v); if (/^#[0-9a-f]{6}$/i.test(v)) { setHsv(hexToHsv(v)); last.current = v; onChange(v.toLowerCase()); } }}
          maxLength={7} spellCheck={false} className="ginput !w-full !py-1 font-mono text-sm" aria-label="Hex colour" />
      </div>
    </div>
  );
}
