import { UNIT } from './render.js';
import { uid } from './engine.js';

/** Reads a picture file and shrinks it (longest side 1600 px) so documents with pictures stay small. */
export function fileToInkImage(file, maxSide = 1600) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), im = new Image();
    im.onload = () => {
      const s = Math.min(1, maxSide / Math.max(im.naturalWidth, im.naturalHeight, 1));
      const w = Math.max(1, Math.round(im.naturalWidth * s)), h = Math.max(1, Math.round(im.naturalHeight * s));
      const c = document.createElement('canvas'); c.width = w; c.height = h;
      const x = c.getContext('2d'); const alpha = /png|webp|gif|svg/.test(file.type);
      if (!alpha) { x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); }
      x.drawImage(im, 0, 0, w, h); URL.revokeObjectURL(url);
      let src = alpha ? c.toDataURL('image/webp', 0.92) : c.toDataURL('image/jpeg', 0.88);
      if (alpha && !src.startsWith('data:image/webp')) src = c.toDataURL('image/png');
      res({ src, w, h });
    };
    im.onerror = () => { URL.revokeObjectURL(url); rej(new Error('That picture could not be opened')); };
    im.src = url;
  });
}

/** Puts a picture in the middle of the part of the page that is on screen and selects it, ready to move and resize. */
export async function insertInkImage(ink, file) {
  const img = await fileToInkImage(file);
  const layer = document.querySelector('[data-ink-layer="1"]'); if (!layer) throw new Error('Open a document first');
  const main = layer.closest('main') || document.body;
  const lr = layer.getBoundingClientRect(), mr = main.getBoundingClientRect(), z = lr.width / layer.offsetWidth || 1;
  const W = layer.offsetWidth / UNIT, H = layer.offsetHeight / UNIT;
  let wi = Math.min(W * 0.5, img.w / UNIT * 0.6 + W * 0.2), hi = wi * img.h / img.w;
  const maxH = (mr.height / z / UNIT) * 0.7; if (hi > maxH) { hi = maxH; wi = hi * img.w / img.h; }
  const cx = ((mr.left + mr.right) / 2 - lr.left) / z / UNIT, cy = ((mr.top + mr.bottom) / 2 - lr.top) / z / UNIT;
  const x1 = Math.max(0, Math.min(W - wi, cx - wi / 2)), y1 = Math.max(0, Math.min(H - hi, cy - hi / 2));
  const o = { id: uid(), t: 'img', iid: uid(), src: img.src, x1, y1, x2: x1 + wi, y2: y1 + hi, bw: 0, op: 1 };
  ink.engine.pendingSelect = o.id;
  ink.setTool('select');
  ink.engine.push(); ink.engine.set([...ink.engine.objs, o], 'draw');
}

/* ---------- editing a picture that is already on the page (same options as pictures in the text) ---------- */
const load = (src) => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Picture could not be read')); i.src = src; });
const encode = (c, like) => (/^data:image\/jpeg/.test(like) ? c.toDataURL('image/jpeg', 0.9) : c.toDataURL('image/png'));
const box = (o) => ({ w: Math.abs(o.x2 - o.x1), h: Math.abs(o.y2 - o.y1), cx: (o.x1 + o.x2) / 2, cy: (o.y1 + o.y2) / 2, x: Math.min(o.x1, o.x2), y: Math.min(o.y1, o.y2) });

/** Turns the picture by 90 degrees (the frame turns with it, around its centre) */
export async function rotateInkImage(engine, o, deg) {
  const im = await load(o.src), c = document.createElement('canvas'); c.width = im.naturalHeight; c.height = im.naturalWidth;
  const x = c.getContext('2d'); x.translate(c.width / 2, c.height / 2); x.rotate((deg * Math.PI) / 180); x.drawImage(im, -im.naturalWidth / 2, -im.naturalHeight / 2);
  const b = box(o);
  engine.update(o.id, { src: encode(c, o.src), iid: uid(), x1: b.cx - b.h / 2, x2: b.cx + b.h / 2, y1: b.cy - b.w / 2, y2: b.cy + b.w / 2 });
}
export async function flipInkImage(engine, o, vertical) {
  const im = await load(o.src), c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight;
  const x = c.getContext('2d'); if (vertical) { x.translate(0, c.height); x.scale(1, -1); } else { x.translate(c.width, 0); x.scale(-1, 1); }
  x.drawImage(im, 0, 0); engine.update(o.id, { src: encode(c, o.src), iid: uid() });
}
/** Crop: t/l/r/b are percentages of the picture to cut away; the part that is left stays where it is on the page */
export async function cropInkImage(engine, o, src, { t, l, r, b }) {
  const k = box(o), nw = k.w * (100 - l - r) / 100, nh = k.h * (100 - t - b) / 100, x1 = k.x + k.w * l / 100, y1 = k.y + k.h * t / 100;
  engine.update(o.id, { src, iid: uid(), x1, y1, x2: x1 + nw, y2: y1 + nh });
}
export async function replaceInkImage(engine, o, file) {
  const img = await fileToInkImage(file), k = box(o), nh = k.w * img.h / img.w;
  engine.update(o.id, { src: img.src, iid: uid(), x1: k.x, y1: k.y, x2: k.x + k.w, y2: k.y + nh });
}
/** width as a share of the page width (keeps the shape), top-left corner stays */
export function sizeInkImage(engine, o, pageW, pct) {
  const k = box(o), nw = (pageW / UNIT) * pct / 100; engine.update(o.id, { x2: k.x + nw, y2: k.y + nw * k.h / k.w, x1: k.x, y1: k.y });
}
export async function resetInkImage(engine, o, pageW) {
  const im = await load(o.src), k = box(o), nw = Math.min(im.naturalWidth, (pageW / UNIT) * 0.6);
  engine.update(o.id, { x1: k.x, y1: k.y, x2: k.x + nw, y2: k.y + nw * im.naturalHeight / im.naturalWidth });
}
export function dataUrlToBlob(src) { const [h, d] = src.split(','), m = /data:([^;]+)/.exec(h)?.[1] || 'image/png', bin = atob(d), a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return new Blob([a], { type: m }); }
