import React from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource/inter/400.css';
import '@fontsource/inter/500.css';
import '@fontsource/inter/700.css';
import '@fontsource/carlito/400.css';
import '@fontsource/carlito/700.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/700.css';
import '@fontsource/jetbrains-mono/400.css';
import './index.css';
import App from './App.jsx';
import { resetSettings } from './services/store.js';

/** Instead of a blank screen, show what went wrong and let the person reset the look of the app. */
class Boundary extends React.Component {
  constructor(p) { super(p); this.state = { err: null }; }
  static getDerivedStateFromError(err) { return { err }; }
  componentDidCatch(err) { console.error(err); }
  render() {
    if (!this.state.err) return this.props.children;
    const e = this.state.err;
    return (
      <div style={{ padding: 20, fontFamily: 'system-ui, sans-serif' }}>
        <h2 style={{ fontSize: 20, fontWeight: 700 }}>INDword hit a problem</h2>
        <p style={{ margin: '8px 0' }}>Your documents are safe. Tap the button to reset the app look (theme, wallpaper, mascots) and reload.</p>
        <button type="button" style={{ padding: '10px 16px', borderRadius: 12, background: '#2563eb', color: '#fff', fontWeight: 600 }}
          onClick={async () => { try { await resetSettings(); } catch { /* ignore */ } location.reload(); }}>Reset appearance and reload</button>
        <pre style={{ marginTop: 14, whiteSpace: 'pre-wrap', fontSize: 12, color: '#b91c1c' }}>{String((e && e.stack) || e)}</pre>
      </div>
    );
  }
}

createRoot(document.getElementById('root')).render(<Boundary><App /></Boundary>);
