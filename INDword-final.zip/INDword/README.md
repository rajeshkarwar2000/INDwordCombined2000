# INDword
Word-style document app for Android tablets. Documents are stored on the device (IndexedDB) and work offline.
GitHub is used only to hold this source and to build the APK remotely.

## AI Notes
Add article images (Home card or Notes tab > From Images). Works through copy-paste with Gemini (no API key). Generated PYQ labels must be verified.

## Notes pages
Notes documents use a real paged layout (Notes tab > Notes Page): A4 cards with gaps, dashed border, header, footer, page numbers and the indIAS logo background. Text fills column 1, then column 2, then the next page. PDF export renders page by page.

## Save to…
Export (PDF, Word, etc.) opens Android's own "Save to" window so you choose the folder. The small native plugin is copied in automatically by the `capacitor:*:after` scripts in package.json (see scripts-native.cjs and resources/native). If it is missing, the app falls back to the share sheet.

## Draw tab (INDnote tools inside INDword) - version 2.0
Open the **Draw** tab (or any document) and pick a tool; a floating tool bar appears at the bottom. Tap an active tool again for its options.

- **Pen** (ball, natural, calligraphy broad/pointed; solid, dotted, dash), **Brush** (pencil, oil, spill, watercolor, crayon), **Highlighter** (round, flat, square, straight line; multiplied onto the text so words stay readable), **Laser pointer** (dot, trail, hold; never saved), **Eraser** (whole stroke or part of stroke, clear page / all), **Select** (move, resize, line ends, duplicate, front/back, recolour, delete), **Shapes** (24 shapes, fill, dash, opacity).
- Editable colour lists, colour wheel, stylus-only drawing with finger scrolling and palm rejection (switch to *Finger draws* when you have no stylus).
- Ink lives on a transparent layer over the pages, in Print Layout (paged or continuous). It is saved inside the document, follows page size changes, and is included in PDF export. Ink stays where it was drawn if the text above it changes, like a pen on paper.
- Undo / Redo in the top bar act on the drawing while a drawing tool is on, and on the text otherwise. **Done** (or the Back button) returns to typing.
- The ink layer is not part of Word (.docx), Markdown, HTML or text exports.

## Version 2.1
- Pen: the live line is now drawn exactly like the finished line (finished curve plus a separate unfinished tail), so there are no sharp corners while drawing and no change when you lift the pen. Lifting no longer repaints every drawing, which removed the lag.
- Highlighter: no flicker when a highlight is finished, and drawing at the same sharpness as the saved highlight.
- All drawing tools start without delay (drawing canvases are prepared when you pick the tool), and pointer positions are read once per frame.
- Zoom: pinch, the + / - buttons, Fit and the View menu now keep the spot you zoom on in place; the page no longer slides sideways.
- AI Notes prompts (Gemini and ChatGPT): bold only (no yellow highlight), other related facts, a box for extra facts / topics you want included, a much deeper static part, arguments as short chronological bullets, dynamic part arranged step by step for understanding, and a set of innovative exam arguments.

## Version 2.2
- Drawing toolbar can sit at the top, left, right or bottom (Draw tab > Position, the move button on the toolbar, or Settings > Drawing).
- AI Notes: a Summary of what the article is about at the top; the dynamic part is lean (names things, no over-explaining); the static part is the main, much deeper explanation; a new "Possible confusions in the exam" section clears similar terms, look-alike facts and tricky statements.
- Settings reorganised into Appearance, Drawing, Documents and a collapsed Advanced section (glass fine-tuning, performance, corner style, scrollbar).

## Version 2.3
- Brush: no start dot; 13 brushes; hold-to-draw shapes (pen and brush).
- Two-finger pan and pinch; zoom up to 600% with sharp tiled ink.
- Insert image in INDnote tools; Copy prompt beside "Tap here to add image".
- Custom auto-save timer; app-drawn blinking caret; PDF import (pdf.js); new logo.
- Smoother laser; Reading mode with INDnote tools.

## Version 2.4
- PDF import opens each page exactly as it is (one document page per PDF page); new text and drawings go on or after the pages. Export keeps drawings on their pages.
- Natural / calligraphy pens commit about 5x faster; highlighter, eraser and laser lighter; frosted blur is off while drawing.
- Smaller sizes for every tool, colour wheel, exit (X) buttons, arrow and triangle-arrow hold-to-draw, picture options for pictures placed with INDnote tools, tighter logo.

### v2.4 – export / import fidelity
- Natural, Calligraphy and Fountain pens now use the same native-stroke path as the Ball pen (no blink on release).
- Laser is drawn at full device resolution with a crisp core and soft glow.
- Hold-to-draw recognises arrow shapes (hook, V and triangle heads) more reliably.
- PDF export of the continuous layout now uses the same browser-rendered page technique as the paged layout (what you see is what you get: margins, colours, borders, watermark, columns, ink).
- DOCX export: inline pictures, hyperlinks, paragraph shading/borders/spacing, table cell shading/borders/widths, numbered-list restarts.
- DOCX import: pictures inside Word "AlternateContent" are read, cropped pictures are cropped, unsupported picture formats leave a visible placeholder.

### v2.4.1
- Highlighter now sits UNDER the text on light pages (pictures, shaded cells and marks multiply over it), like INDnote, so words stay crisp.
- PDF size: imported-PDF pages that carry no ink are written back as the original JPEG (no re-encoding); pages with ink are composited at the source resolution. Text pages render at 2.5x / JPEG 0.90. A 40 MB PDF should now export at roughly the same size instead of 150 MB.

### v2.4.2
- PDF export: highlighter is multiplied behind the text (was painted normally over it).
- Pen: input smoothing so curves no longer get sharp corners.
- DOCX export: heading colours/fonts, body font, page colour; imported-PDF pages export as one full-page picture per sheet.

### v2.5 – Word export fidelity
- New export **Word (.docx) – exact look (pictures)**: every page is exported exactly as drawn in the app (text, boxes, shapes, symbols, pictures, watermark, borders and pen/highlighter drawings). The text is not editable in Word.
- **Word (.docx) – editable** now also keeps: callout boxes (coloured box, side bar and label), banner side bars, column sections and column breaks (content was dropped before), title/subtitle/quote styles, underline styles (double, dotted, dashed, wavy), double strikethrough, left/right floating pictures, page and margin borders, and the watermark / logo background.

### v2.6 – Spider-Man theme
Settings > Appearance > Theme > **Spider-Man**: dark mode, red accent, red/blue web wallpaper and red-rimmed glass. Choose any other wallpaper to go back to the normal look. Red and blue were also added to the accent colours.

### v2.7 – Spider-Man poses and versions
With the Spider-Man theme on, original web-slinger mascots appear in 7 poses (swing, crouch, wall crawl, punch, hang, web shot, perch) next to the Home buttons, the sidebar, empty lists, section titles, the export/import progress box and the editor status bar. Settings > Appearance shows **5 versions** (Classic, Midnight, Neon, Street, Frost) and lets you replace any pose with your own picture.

### v2.8 – Start-up safety
If the app ever fails to start, it now shows the error text and a **Reset appearance and reload** button instead of a blank screen. Mascots can no longer crash the app: if one fails to draw, it is simply hidden.

### v2.9 – Fix
Fixed the start-up error "nx is not defined" (a leftover line in the mascot drawing code).

### v3.0
- **Page view** (View tab > Page View, the page-number menu in the status bar, or the Pages side panel): every page as a picture. Tap to select pages, hold the grip and drag, or use the arrows to rearrange. Also duplicate, delete, insert a blank page, Undo and Apply. The text, boxes, pictures and your pen / highlighter drawings move together with the page.
- **Drawings follow their page**: inserting or removing a page break before a drawing now moves the drawing with its page. Page breaks carry an id for this.
- **More Spider-Man characters**: Black & Red, Black Suit, Spider, Garden Spider and "Mix of all" (a different character in every place), besides Classic, Midnight, Neon, Street and Frost.
- **On/off switch** for the Spider-Man theme (restores your previous look) and a second switch for the characters only.
- Spider-Man crawls along the page slider on the right, and sits beside the tabs on the working screen (hidden on narrow phones so the tools keep their room).

### v3.1 – Smoother writing and curved arrows
- Pen strokes (ball pen, dashed lines and the path-style brushes) are now drawn as one smooth curve through the pen points, so the round parts of letters (c, o, s) no longer get small corners. The points themselves are not changed.
- Hold to draw shapes now also makes **curved arrows**: draw an arc, finish it with an arrow head (a V, a hook or a small triangle) and keep the pen still. A straight line with a triangle head becomes a triangle arrow, as before.
- Curved arrows (open head and triangle head) are also in the Shapes tool, and they can be selected, moved, resized and rotated like other shapes.

### v3.2 – iPad-style writing
- **One Euro filter** on the pen position: strong smoothing while writing slowly (no jitter), almost none while writing fast (no lag).
- **Low-latency drawing canvas** for the stroke being drawn (skips the wait for the screen refresh).
- Together with the smooth curve through the points and the denser points from before.

### v3.3
Removed the predicted pen points: at fast turns they showed a short straight line ahead of the pen for a moment.

### v3.4
Pen prediction is back in a careful form: only while the pen moves smoothly, only when the guess continues the pen's direction, at most a few pixels long and drawn lighter. On sudden turns nothing is guessed, so no straight line shows.
