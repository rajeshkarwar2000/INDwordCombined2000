# INDword
Word-style document app for Android tablets. Documents are stored on the device (IndexedDB) and work offline.
GitHub is used only to hold this source and to build the APK remotely.

## AI Notes
Add article images (Home card or Notes tab > From Images). Works through copy-paste with Gemini (no API key). Generated PYQ labels must be verified.

## Notes pages
Notes documents use a real paged layout (Notes tab > Notes Page): A4 cards with gaps, dashed border, header, footer, page numbers and the indIAS logo background. Text fills column 1, then column 2, then the next page. PDF export renders page by page.

## Save to…
Export (PDF, Word, etc.) opens Android's own "Save to" window so you choose the folder. The small native plugin is copied in automatically by the `capacitor:*:after` scripts in package.json (see scripts-native.cjs and resources/native). If it is missing, the app falls back to the share sheet.

## Draw tab (INDnote tools inside INDword) - version 2.0
Open the **Draw** tab (or any document) and pick a tool; a floating tool bar appears at the bottom. Tap an active tool again for its options.

- **Pen** (ball, natural, calligraphy broad/pointed; solid, dotted, dash), **Brush** (pencil, oil, spill, watercolor, crayon), **Highlighter** (round, flat, square, straight line; multiplied onto the text so words stay readable), **Laser pointer** (dot, trail, hold; never saved), **Eraser** (whole stroke or part of stroke, clear page / all), **Select** (move, resize, line ends, duplicate, front/back, recolour, delete), **Shapes** (24 shapes, fill, dash, opacity).
- Editable colour lists, colour wheel, stylus-only drawing with finger scrolling and palm rejection (switch to *Finger draws* when you have no stylus).
- Ink lives on a transparent layer over the pages, in Print Layout (paged or continuous). It is saved inside the document, follows page size changes, and is included in PDF export. Ink stays where it was drawn if the text above it changes, like a pen on paper.
- Undo / Redo in the top bar act on the drawing while a drawing tool is on, and on the text otherwise. **Done** (or the Back button) returns to typing.
- The ink layer is not part of Word (.docx), Markdown, HTML or text exports.

## Version 2.1
- Pen: the live line is now drawn exactly like the finished line (finished curve plus a separate unfinished tail), so there are no sharp corners while drawing and no change when you lift the pen. Lifting no longer repaints every drawing, which removed the lag.
- Highlighter: no flicker when a highlight is finished, and drawing at the same sharpness as the saved highlight.
- All drawing tools start without delay (drawing canvases are prepared when you pick the tool), and pointer positions are read once per frame.
- Zoom: pinch, the + / - buttons, Fit and the View menu now keep the spot you zoom on in place; the page no longer slides sideways.
- AI Notes prompts (Gemini and ChatGPT): bold only (no yellow highlight), other related facts, a box for extra facts / topics you want included, a much deeper static part, arguments as short chronological bullets, dynamic part arranged step by step for understanding, and a set of innovative exam arguments.

## Version 2.2
- Drawing toolbar can sit at the top, left, right or bottom (Draw tab > Position, the move button on the toolbar, or Settings > Drawing).
- AI Notes: a Summary of what the article is about at the top; the dynamic part is lean (names things, no over-explaining); the static part is the main, much deeper explanation; a new "Possible confusions in the exam" section clears similar terms, look-alike facts and tricky statements.
- Settings reorganised into Appearance, Drawing, Documents and a collapsed Advanced section (glass fine-tuning, performance, corner style, scrollbar).

## Version 2.3
- Brush: no start dot; 13 brushes; hold-to-draw shapes (pen and brush).
- Two-finger pan and pinch; zoom up to 600% with sharp tiled ink.
- Insert image in INDnote tools; Copy prompt beside "Tap here to add image".
- Custom auto-save timer; app-drawn blinking caret; PDF import (pdf.js); new logo.
- Smoother laser; Reading mode with INDnote tools.

## Version 2.4
- PDF import opens each page exactly as it is (one document page per PDF page); new text and drawings go on or after the pages. Export keeps drawings on their pages.
- Natural / calligraphy pens commit about 5x faster; highlighter, eraser and laser lighter; frosted blur is off while drawing.
- Smaller sizes for every tool, colour wheel, exit (X) buttons, arrow and triangle-arrow hold-to-draw, picture options for pictures placed with INDnote tools, tighter logo.
