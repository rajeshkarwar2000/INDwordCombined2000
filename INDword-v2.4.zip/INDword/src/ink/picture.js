// Picture helpers shared by the Draw tab and the picture options bar.

/* a picture from the gallery or camera, shrunk to at most 1400 px (PNG keeps transparency) */
export const pickPicture = () => new Promise((resolve) => {
  const input = document.createElement('input'); input.type = 'file'; input.accept = 'image/*';
  input.onchange = () => {
    const f = input.files && input.files[0]; if (!f) return resolve(null);
    const fr = new FileReader(); fr.onerror = () => resolve(null);
    fr.onload = () => {
      const im = new Image(); im.onerror = () => resolve(null);
      im.onload = () => {
        const k = Math.min(1, 1400 / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
        const png = /png|svg|gif|webp/.test(f.type);
        resolve({ url: c.toDataURL(png ? 'image/png' : 'image/jpeg', 0.88), w: c.width, h: c.height });
      };
      im.src = String(fr.result);
    };
    fr.readAsDataURL(f);
  };
  input.click();
});

export const imageSize = (src) => new Promise((resolve, reject) => {
  const i = new Image(); i.onload = () => resolve({ w: i.naturalWidth, h: i.naturalHeight }); i.onerror = () => reject(new Error('Picture could not be read')); i.src = src;
});

export const flipDataUrl = async (src) => {
  const i = new Image(); await new Promise((res, rej) => { i.onload = res; i.onerror = rej; i.src = src; });
  const c = document.createElement('canvas'); c.width = i.naturalWidth; c.height = i.naturalHeight;
  const x = c.getContext('2d'); x.translate(c.width, 0); x.scale(-1, 1); x.drawImage(i, 0, 0);
  return c.toDataURL('image/png');
};
