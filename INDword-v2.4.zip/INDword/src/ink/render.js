// Ink rendering engine, ported from INDnote: pen / brush / highlighter strokes, shapes and the neon laser.
// Coordinates are "ink units": 1 unit = 0.6403 CSS px (INDnote's 1240-wide page mapped onto an A4 page of 794 px).
const TAU = Math.PI * 2;
const R = {};
export const UNIT = 794 / 1240; // css px per ink unit

  // ---------- seeded random ----------
  function rng(seed) {
    let a = (seed | 0) || 1;
    return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function shade(hex, d) {
    const n = (i) => Math.max(0, Math.min(255, parseInt(hex.slice(i, i + 2), 16) + d));
    return 'rgb(' + n(1) + ',' + n(3) + ',' + n(5) + ')';
  }
  function rgba(hex, a) { return 'rgba(' + parseInt(hex.slice(1, 3), 16) + ',' + parseInt(hex.slice(3, 5), 16) + ',' + parseInt(hex.slice(5, 7), 16) + ',' + a + ')'; }

  // ---------- path walker (stamps along a stroke at fixed spacing) ----------
  function newState(s) { return { started: false, lx: 0, ly: 0, lp: 0.5, acc: 0, pos: 0, rnd: rng(s.seed || 1), n: 0 }; }
  function walk(pts, from, st, step, cb) {
    for (let i = Math.max(from, 0); i < pts.length; i++) {
      const p = pts[i];
      if (!st.started) { st.started = true; st.lx = p[0]; st.ly = p[1]; st.lp = p[2]; cb(p[0], p[1], p[2], 0, 0); continue; }
      const dx = p[0] - st.lx, dy = p[1] - st.ly, d = Math.hypot(dx, dy);
      if (d < 1e-6) continue;
      const ux = dx / d, uy = dy / d; let s = 0;
      while (d - s >= step - st.acc) {
        s += step - st.acc; st.acc = 0; st.pos += step;
        const f = s / d;
        cb(st.lx + dx * f, st.ly + dy * f, st.lp + (p[2] - st.lp) * f, ux, uy);
      }
      st.acc += d - s; st.lx = p[0]; st.ly = p[1]; st.lp = p[2];
    }
  }

  // ---------- strokes ----------
  // Draws points [from..] of stroke s. For incremental drawing pass the same `st` each call.
  R.newStrokeState = newState;
  // part (optional, natural / calligraphy pens): 'body' = only the finished curve, 'tail' = only the unfinished last bit (for live drawing)
  R.drawStroke = function (ctx, s, from, st, live, part) {
    const pts = s.pts;
    if (!pts.length) return;
    if (s.tool === 'hl') return drawHighlighter(ctx, s, live);
    st = st || newState(s);
    const size = s.size, col = s.color;
    if (s.tool === 'brush') return drawBrush(ctx, s, from, st, live);
    // pen
    const line = s.line || 'solid', space = s.space || 10;
    const step = Math.max(0.6, size * 0.14);
    const period = line === 'dotted' ? size * 1.2 + space : size * 3.2 + space;
    ctx.fillStyle = col;
    if (line !== 'solid') return drawDashed(ctx, s, line);
    if ((s.pen || 'ball') === 'ball') return drawBallPen(ctx, s, from, st);
    if (s.pen === 'natural') return drawNatural(ctx, s, from, st, part);
    if (line === 'solid' && (s.pen === 'calligraphy' || s.pen === 'fountain')) return drawCalligraphy(ctx, s, from, st, part);
    let typ = line !== 'solid' ? 'ball' : s.pen || 'ball';
    if (typ === 'fountain') typ = 'calligraphy';
    const nib = s.nib || 'chisel', ang = ((s.angle == null ? 40 : s.angle) * Math.PI) / 180;
    ctx.beginPath(); // all stamps of this call go into one path and are filled once (much faster than one fill per stamp)
    const circ = (x, y, r) => { ctx.moveTo(x + r, y); ctx.arc(x, y, r, 0, TAU); };
    walk(pts, from, st, step, (x, y, p, ux, uy) => {
      if (line === 'dotted' && !(st.pos % period < step - 1e-6 || st.pos === 0)) return;
      if (line === 'dashdot' && !(st.pos % period < size * 3.2)) return;
      if (typ === 'ball') circ(x, y, size / 2);
      else if (typ === 'natural') circ(x, y, (size / 2) * (0.3 + 1.4 * (p == null ? 0.5 : p)));
      else if (nib === 'pointed') {
        // copperplate pen: thick on downstrokes, hairline on upstrokes, swells with pressure
        st.dy = (st.dy || 0) * 0.7 + uy * 0.3;
        const down = Math.max(0, st.dy), pr = p == null ? 0.5 : p;
        circ(x, y, Math.max(0.5, (size / 2) * (0.35 + 1.25 * pr) * (0.16 + 0.84 * down)));
      } else {
        // broad-nib (chisel) calligraphy: width follows the angle of the nib
        const pr = p == null ? 0.5 : p, rx = size * 0.62 * (0.75 + 0.5 * pr);
        ctx.moveTo(x + rx * Math.cos(-ang), y + rx * Math.sin(-ang));
        ctx.ellipse(x, y, rx, Math.max(0.6, size * 0.075), -ang, 0, TAU);
      }
    });
    ctx.fill();
    if (st.final === undefined && pts.length === 1) { ctx.beginPath(); ctx.arc(pts[0][0], pts[0][1], size / 2, 0, TAU); ctx.fill(); }
  };

  // Calligraphy: the nib is swept along the smoothed path as one filled ribbon (no stamps, no gaps, no seams).
  // Broad nib: a slanted flat edge (thick or thin depending on the stroke direction). Pointed nib: copperplate, thick downstrokes and hairline upstrokes.
  function drawCalligraphy(ctx, s, from, st, part) {
    const pts = s.pts, n = pts.length; if (!n) return;
    if (n === 1 && part === 'body') return;
    const size = s.size, pointed = s.nib === 'pointed', ang = ((s.angle == null ? 40 : s.angle) * Math.PI) / 180, cx = Math.cos(-ang), cy = Math.sin(-ang);
    const half = (pr) => size * 0.62 * (0.75 + 0.5 * (pr == null ? 0.5 : pr));
    const rad = (pr, down) => Math.max(0.5, (size / 2) * (0.35 + 1.25 * (pr == null ? 0.5 : pr)) * (0.16 + 0.84 * down));
    ctx.save(); ctx.fillStyle = ctx.strokeStyle = s.color; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.lineWidth = Math.max(0.8, size * 0.09);
    ctx.beginPath();
    if (n === 1) {
      if (pointed) { ctx.arc(pts[0][0], pts[0][1], rad(pts[0][2], 0.6), 0, TAU); ctx.fill(); }
      else { const hh = half(pts[0][2]); ctx.moveTo(pts[0][0] - cx * hh, pts[0][1] - cy * hh); ctx.lineTo(pts[0][0] + cx * hh, pts[0][1] + cy * hh); ctx.stroke(); }
      ctx.restore(); return;
    }
    let i = Math.max(1, from || 0);
    if (i === 1 || !st.m) { if (part === 'tail' && st.m) { /* keep */ } else { st.m = [pts[0][0], pts[0][1], pts[0][2], null]; st.dy = 0; i = 1; } }
    if (part === 'tail') i = n;
    const emit = (qx, qy, qp) => {
      const m = st.m, dx = qx - m[0], dy = qy - m[1], d = Math.hypot(dx, dy); if (d < 0.01) return;
      if (pointed) {
        st.dy = (st.dy || 0) * 0.7 + (dy / d) * 0.3; const rb = rad(qp, Math.max(0, st.dy)), ra = m[3] == null ? rb : m[3], ux = dx / d, uy = dy / d;
        ctx.moveTo(m[0] - uy * ra, m[1] + ux * ra); ctx.lineTo(m[0] + uy * ra, m[1] - ux * ra); ctx.lineTo(qx + uy * rb, qy - ux * rb); ctx.lineTo(qx - uy * rb, qy + ux * rb); ctx.closePath();
        ctx.moveTo(qx + rb, qy); ctx.arc(qx, qy, rb, 0, TAU); st.m = [qx, qy, qp, rb];
      } else {
        const ha = half(m[2]), hb = half(qp);
        let P = [[m[0] - cx * ha, m[1] - cy * ha], [m[0] + cx * ha, m[1] + cy * ha], [qx + cx * hb, qy + cy * hb], [qx - cx * hb, qy - cy * hb]];
        if (cx * dy - cy * dx < 0) P = [P[3], P[2], P[1], P[0]]; // keep every quad the same winding so overlaps never cancel into holes
        ctx.moveTo(P[0][0], P[0][1]); ctx.lineTo(P[1][0], P[1][1]); ctx.lineTo(P[2][0], P[2][1]); ctx.lineTo(P[3][0], P[3][1]); ctx.closePath(); st.m = [qx, qy, qp, null];
      }
    };
    for (; i < n; i++) {
      const a = pts[i - 1], b = pts[i], mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2, mp = ((a[2] == null ? 0.5 : a[2]) + (b[2] == null ? 0.5 : b[2])) / 2, m0 = st.m;
      const steps = Math.max(1, Math.min(10, Math.ceil(Math.hypot(mx - m0[0], my - m0[1]) / Math.max(1, size * 0.3))));
      for (let k = 1; k <= steps; k++) { const t = k / steps, u = 1 - t; emit(u * u * m0[0] + 2 * u * t * a[0] + t * t * mx, u * u * m0[1] + 2 * u * t * a[1] + t * t * my, (m0[2] == null ? 0.5 : m0[2]) + (mp - (m0[2] == null ? 0.5 : m0[2])) * t); }
    }
    if (part !== 'body') { const keep = st.m, kd = st.dy; emit(pts[n - 1][0], pts[n - 1][1], pts[n - 1][2]); st.m = keep; st.dy = kd; } // last half segment (redrawn by the next call)
    ctx.fill(); if (!pointed) ctx.stroke(); ctx.restore();
  }

  // Dotted and dashed lines: one native dashed stroke along the smoothed path (redrawn whole, so the pattern stays continuous)
  function drawDashed(ctx, s, line) {
    const pts = s.pts, n = pts.length; if (!n) return; const size = s.size, gap = s.space || 10;
    ctx.save(); ctx.strokeStyle = ctx.fillStyle = s.color; ctx.lineWidth = size; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (n === 1) { ctx.beginPath(); ctx.arc(pts[0][0], pts[0][1], size / 2, 0, TAU); ctx.fill(); ctx.restore(); return; }
    ctx.setLineDash(line === 'dotted' ? [0.01, size * 1.2 + gap] : [Math.max(0.01, size * 2.2), gap + size]);
    ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < n - 1; i++) ctx.quadraticCurveTo(pts[i][0], pts[i][1], (pts[i][0] + pts[i + 1][0]) / 2, (pts[i][1] + pts[i + 1][1]) / 2);
    ctx.lineTo(pts[n - 1][0], pts[n - 1][1]); ctx.stroke(); ctx.restore();
  }
  // Natural (pressure) pen: a smooth ribbon whose width follows pressure (smoothed) and thins a little when you write fast
  function drawNatural(ctx, s, from, st, part) {
    const pts = s.pts, n = pts.length; if (!n) return; const size = s.size;
    if (n === 1 && part === 'body') return;
    const rad = (pr) => { const pe = st.rp = st.rp == null ? pr : st.rp * 0.6 + pr * 0.4, vf = Math.max(0.6, Math.min(1.2, 1.25 - (st.sp || 0) * 0.025)); return Math.max(0.5, (size / 2) * (0.3 + 1.4 * pe) * vf); };
    ctx.save(); ctx.fillStyle = s.color; ctx.beginPath();
    if (n === 1) { ctx.arc(pts[0][0], pts[0][1], rad(pts[0][2] == null ? 0.5 : pts[0][2]), 0, TAU); ctx.fill(); ctx.restore(); return; }
    let i = Math.max(1, from || 0);
    if (i === 1 || !st.m) { if (part === 'tail' && st.m) { /* keep */ } else { st.m = [pts[0][0], pts[0][1], pts[0][2] == null ? 0.5 : pts[0][2], rad(pts[0][2] == null ? 0.5 : pts[0][2])]; i = 1; } }
    if (part === 'tail') i = n;
    const emit = (qx, qy, qp) => {
      const m = st.m, dx = qx - m[0], dy = qy - m[1], d = Math.hypot(dx, dy); if (d < 0.01) return;
      const rb = rad(qp), ra = m[3], ux = dx / d, uy = dy / d;
      ctx.moveTo(m[0] - uy * ra, m[1] + ux * ra); ctx.lineTo(m[0] + uy * ra, m[1] - ux * ra); ctx.lineTo(qx + uy * rb, qy - ux * rb); ctx.lineTo(qx - uy * rb, qy + ux * rb); ctx.closePath();
      ctx.moveTo(qx + rb, qy); ctx.arc(qx, qy, rb, 0, TAU); st.m = [qx, qy, qp, rb];
    };
    for (; i < n; i++) {
      const a = pts[i - 1], b = pts[i], len = Math.hypot(b[0] - a[0], b[1] - a[1]); st.sp = st.sp == null ? len : st.sp * 0.7 + len * 0.3;
      const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2, mp = ((a[2] == null ? 0.5 : a[2]) + (b[2] == null ? 0.5 : b[2])) / 2, m0 = st.m;
      const steps = Math.max(1, Math.min(10, Math.ceil(Math.hypot(mx - m0[0], my - m0[1]) / Math.max(1, size * 0.3))));
      for (let k = 1; k <= steps; k++) { const t = k / steps, u = 1 - t; emit(u * u * m0[0] + 2 * u * t * a[0] + t * t * mx, u * u * m0[1] + 2 * u * t * a[1] + t * t * my, m0[2] + (mp - m0[2]) * t); }
    }
    if (part !== 'body') { const keep = st.m, kr = st.rp; emit(pts[n - 1][0], pts[n - 1][1], pts[n - 1][2] == null ? 0.5 : pts[n - 1][2]); st.m = keep; st.rp = kr; }
    ctx.fill(); ctx.restore();
  }

  // Ball pen: one native round-capped stroke per new point, joined with quadratic curves (smooth, cheap, identical live and when committed)
  function drawBallPen(ctx, s, from, st) {
    const pts = s.pts, n = pts.length; if (!n) return;
    ctx.save(); ctx.strokeStyle = ctx.fillStyle = s.color; ctx.lineWidth = s.size; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (n === 1) { ctx.beginPath(); ctx.arc(pts[0][0], pts[0][1], s.size / 2, 0, TAU); ctx.fill(); ctx.restore(); return; }
    let i = Math.max(1, from || 0);
    if (i === 1 || st.bx == null) { st.bx = pts[0][0]; st.by = pts[0][1]; i = 1; }
    ctx.beginPath(); ctx.moveTo(st.bx, st.by);
    for (; i < n; i++) {
      const a = pts[i - 1], b = pts[i], mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
      ctx.quadraticCurveTo(a[0], a[1], mx, my); st.bx = mx; st.by = my;
    }
    ctx.lineTo(pts[n - 1][0], pts[n - 1][1]); // last half segment (redrawn by the next call)
    ctx.stroke(); ctx.restore();
    st.bx = st.bx; // midpoint kept for the next incremental call
  }

  function drawHighlighter(ctx, s, live) {
    const pts = s.pts; if (!pts.length) return;
    ctx.save();
    ctx.globalAlpha = s.alpha == null ? 0.45 : s.alpha;
    // multiply keeps the text under the highlight readable (the live layer uses a CSS multiply blend so it looks the same)
    ctx.globalCompositeOperation = live ? 'source-over' : 'multiply';
    const tip = s.tip || 'round';
    ctx.strokeStyle = ctx.fillStyle = s.color; ctx.lineWidth = s.size; ctx.lineJoin = tip === 'square' ? 'miter' : 'round';
    ctx.lineCap = tip === 'round' ? 'round' : tip === 'square' ? 'butt' : 'butt';
    if (tip === 'flat') { // chisel marker: a slanted flat nib swept along the path, filled once so overlaps do not darken
      const a = -Math.PI / 4, nx = Math.cos(a) * s.size / 2, ny = Math.sin(a) * s.size / 2;
      ctx.beginPath();
      const q = pts.length === 1 ? [pts[0], [pts[0][0] + 0.01, pts[0][1]]] : pts;
      for (let i = 1; i < q.length; i++) { const A = q[i - 1], B = q[i]; ctx.moveTo(A[0] - nx, A[1] - ny); ctx.lineTo(A[0] + nx, A[1] + ny); ctx.lineTo(B[0] + nx, B[1] + ny); ctx.lineTo(B[0] - nx, B[1] - ny); ctx.closePath(); }
      ctx.fill(); ctx.restore(); return;
    }
    ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
    if (pts.length === 1) ctx.lineTo(pts[0][0] + 0.01, pts[0][1]);
    for (let i = 1; i < pts.length - 1; i++) {
      const mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2;
      ctx.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
    }
    if (pts.length > 1) ctx.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
    ctx.stroke(); ctx.restore();
  }

  function drawBrush(ctx, s, from, st, live) {
    const size = s.size, col = s.color, type = s.brush || 'pencil', rnd = st.rnd;
    if (!st.bristles) st.bristles = [-2, -1, 0, 1, 2].map((k) => shade(col, (rnd() - 0.5) * 70));
    const stepK = { oil: 0.1, marker: 0.07, airbrush: 0.1, ink: 0.07, neon: 0.1, rainbow: 0.1, stars: 0.18 }[type] || 0.14;
    const step = Math.max(0.8, size * stepK);
    ctx.save();
    walk(s.pts, from, st, step, (x, y, p, ux, uy) => {
      if (type === 'pencil') {
        ctx.fillStyle = rgba(col, 0.16); ctx.beginPath(); ctx.arc(x, y, size * 0.32, 0, TAU); ctx.fill();
        ctx.fillStyle = rgba(col, 0.55);
        for (let j = 0; j < 5; j++) { const a = rnd() * TAU, r = Math.sqrt(rnd()) * size * 0.5; ctx.fillRect(x + Math.cos(a) * r, y + Math.sin(a) * r, 1.1, 1.1); }
      } else if (type === 'oil') {
        ctx.fillStyle = rgba(col, 0.55); ctx.beginPath(); ctx.arc(x, y, size * 0.34, 0, TAU); ctx.fill();
        for (let k = -2; k <= 2; k++) {
          const ox = -uy * k * size * 0.17, oy = ux * k * size * 0.17;
          ctx.fillStyle = st.bristles[k + 2]; ctx.globalAlpha = 0.92;
          ctx.beginPath(); ctx.arc(x + ox, y + oy, size * 0.11, 0, TAU); ctx.fill();
        }
        ctx.globalAlpha = 1;
      } else if (type === 'spill') {
        const r = size * (0.8 + rnd() * 0.5);
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, rgba(col, 0.2)); g.addColorStop(1, rgba(col, 0));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
        if (rnd() < 0.1) {
          const a = rnd() * TAU, dd = size * (0.7 + rnd() * 0.9);
          ctx.fillStyle = rgba(col, 0.55); ctx.beginPath(); ctx.arc(x + Math.cos(a) * dd, y + Math.sin(a) * dd, 0.8 + rnd() * size * 0.22, 0, TAU); ctx.fill();
        }
      } else if (type === 'watercolor') {
        const r = size * 0.8;
        const g = ctx.createRadialGradient(x, y, r * 0.2, x, y, r);
        g.addColorStop(0, rgba(col, 0.07)); g.addColorStop(0.85, rgba(col, 0.06)); g.addColorStop(1, rgba(col, 0.14));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      } else if (type === 'marker') { // flat felt tip, overlaps get darker like a real marker
        ctx.save(); ctx.translate(x, y); ctx.rotate(-0.7); ctx.fillStyle = rgba(col, 0.5);
        ctx.fillRect(-size * 0.5, -size * 0.22, size, size * 0.44); ctx.restore();
      } else if (type === 'airbrush') { // soft spray that builds up
        const r = size * 0.9, g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, rgba(col, 0.1)); g.addColorStop(0.5, rgba(col, 0.045)); g.addColorStop(1, rgba(col, 0));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      } else if (type === 'chalk') { // dusty, broken texture
        ctx.fillStyle = rgba(col, 0.07); ctx.beginPath(); ctx.arc(x, y, size * 0.45, 0, TAU); ctx.fill();
        ctx.fillStyle = rgba(col, 0.42);
        for (let j = 0; j < 16; j++) { const a = rnd() * TAU, r = Math.sqrt(rnd()) * size * 0.6, sz = 0.7 + rnd() * 1.3; ctx.fillRect(x + Math.cos(a) * r, y + Math.sin(a) * r, sz, sz); }
      } else if (type === 'charcoal') { // dark, grainy, streaked along the stroke
        ctx.fillStyle = rgba(col, 0.2); ctx.beginPath(); ctx.arc(x, y, size * 0.34, 0, TAU); ctx.fill();
        ctx.strokeStyle = rgba(col, 0.62); ctx.lineWidth = 1; ctx.beginPath();
        for (let j = 0; j < 10; j++) { const a = rnd() * TAU, r = Math.sqrt(rnd()) * size * 0.5, l = 1 + rnd() * 4; const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r; ctx.moveTo(px, py); ctx.lineTo(px + ux * l, py + uy * l); }
        ctx.stroke();
      } else if (type === 'ink') { // ink brush: pressure makes the line fat or thin
        const r = size * 0.5 * (0.22 + 0.9 * Math.min(1, p == null ? 0.5 : p));
        ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
        if (rnd() < 0.05) { ctx.fillStyle = rgba(col, 0.5); ctx.beginPath(); ctx.arc(x + (rnd() - 0.5) * r * 2.4, y + (rnd() - 0.5) * r * 2.4, 0.6 + rnd() * r * 0.3, 0, TAU); ctx.fill(); }
      } else if (type === 'neon') { // glowing tube with a white core
        ctx.fillStyle = rgba(col, 0.05); ctx.beginPath(); ctx.arc(x, y, size * 0.9, 0, TAU); ctx.fill();
        ctx.fillStyle = rgba(col, 0.28); ctx.beginPath(); ctx.arc(x, y, size * 0.42, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.beginPath(); ctx.arc(x, y, size * 0.15, 0, TAU); ctx.fill();
      } else if (type === 'rainbow') { // colour changes along the line
        st.hue = ((st.hue || 0) + step * 0.7) % 360;
        ctx.fillStyle = `hsl(${st.hue},90%,55%)`; ctx.beginPath(); ctx.arc(x, y, size * 0.45, 0, TAU); ctx.fill();
      } else if (type === 'stars') { // a trail of little stars
        st.n = (st.n || 0) + 1; if (st.n % 5) return;
        const R0 = size * (0.28 + rnd() * 0.3), rot = rnd() * TAU, sh = shade(col, (rnd() - 0.5) * 80);
        ctx.fillStyle = sh; ctx.beginPath();
        for (let k = 0; k < 10; k++) { const a = rot + (k * Math.PI) / 5, rr = k % 2 ? R0 * 0.45 : R0; ctx[k ? 'lineTo' : 'moveTo'](x + Math.cos(a) * rr, y + Math.sin(a) * rr); }
        ctx.closePath(); ctx.fill();
      } else { // crayon
        ctx.fillStyle = rgba(col, 0.78);
        for (let j = 0; j < 9; j++) { const a = rnd() * TAU, r = Math.sqrt(rnd()) * size * 0.5, sz = 1 + rnd() * 2.2; ctx.fillRect(x + Math.cos(a) * r, y + Math.sin(a) * r, sz, sz); }
      }
    });
    if (s.pts.length === 1 && !live) { ctx.fillStyle = rgba(col, 0.6); ctx.beginPath(); ctx.arc(s.pts[0][0], s.pts[0][1], size * 0.4, 0, TAU); ctx.fill(); }
    ctx.restore();
  }

  // ---------- shapes ----------
  const poly = {
    tri: [[.5, 0], [1, 1], [0, 1]], rtri: [[0, 0], [1, 1], [0, 1]], diamond: [[.5, 0], [1, .5], [.5, 1], [0, .5]],
    para: [[.2, 0], [1, 0], [.8, 1], [0, 1]], trap: [[.2, 0], [.8, 0], [1, 1], [0, 1]],
    plus: [[.35, 0], [.65, 0], [.65, .35], [1, .35], [1, .65], [.65, .65], [.65, 1], [.35, 1], [.35, .65], [0, .65], [0, .35], [.35, .35]],
    arrowR: [[0, .3], [.6, .3], [.6, 0], [1, .5], [.6, 1], [.6, .7], [0, .7]],
    bolt: [[.6, 0], [.15, .55], [.45, .55], [.35, 1], [.85, .4], [.55, .4]],
    bubble: [[0, 0], [1, 0], [1, .75], [.4, .75], [.2, 1], [.25, .75], [0, .75]],
  };
  const regular = (n, rot) => Array.from({ length: n }, (_, i) => { const a = rot + (i * TAU) / n; return [.5 + Math.cos(a) * .5, .5 + Math.sin(a) * .5]; });
  const star = (n, inner) => Array.from({ length: n * 2 }, (_, i) => { const a = -Math.PI / 2 + (i * Math.PI) / n, r = i % 2 ? inner * .5 : .5; return [.5 + Math.cos(a) * r, .5 + Math.sin(a) * r]; });
  poly.pent = regular(5, -Math.PI / 2); poly.hex = regular(6, 0); poly.oct = regular(8, Math.PI / 8);
  poly.star = star(5, .42); poly.star4 = star(4, .38);
  R.SHAPES = [
    ['line', 'Line'], ['arrow', 'Arrow'], ['darrow', 'Double arrow'], ['rect', 'Rectangle'], ['round', 'Rounded'], ['ellipse', 'Ellipse'],
    ['tri', 'Triangle'], ['rtri', 'Right tri.'], ['diamond', 'Diamond'], ['para', 'Parallelogram'], ['trap', 'Trapezoid'], ['pent', 'Pentagon'],
    ['hex', 'Hexagon'], ['oct', 'Octagon'], ['star', 'Star'], ['star4', '4-point star'], ['heart', 'Heart'], ['cloud', 'Cloud'],
    ['plus', 'Cross'], ['check', 'Check'], ['bubble', 'Speech'], ['arrowR', 'Block arrow'], ['moon', 'Crescent'], ['bolt', 'Lightning'],
  ];
  R.isLineShape = (k) => k === 'line' || k === 'arrow' || k === 'darrow';

  function shapePath(ctx, o) {
    const x = Math.min(o.x1, o.x2), y = Math.min(o.y1, o.y2), w = Math.abs(o.x2 - o.x1), h = Math.abs(o.y2 - o.y1);
    const P = (u, v) => [x + u * w, y + v * h];
    const k = o.kind; ctx.beginPath();
    if (k === 'rect') ctx.rect(x, y, w, h);
    else if (k === 'round') { const r = Math.min(w, h) * 0.2; ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
    else if (k === 'ellipse') ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, TAU);
    else if (k === 'heart') {
      const m = (a, b) => P(a, b);
      ctx.moveTo(...m(.5, .95)); ctx.bezierCurveTo(...m(.1, .62), ...m(0, .4), ...m(0, .27)); ctx.bezierCurveTo(...m(0, .1), ...m(.15, 0), ...m(.3, 0));
      ctx.bezierCurveTo(...m(.4, 0), ...m(.47, .06), ...m(.5, .16)); ctx.bezierCurveTo(...m(.53, .06), ...m(.6, 0), ...m(.7, 0));
      ctx.bezierCurveTo(...m(.85, 0), ...m(1, .1), ...m(1, .27)); ctx.bezierCurveTo(...m(1, .4), ...m(.9, .62), ...m(.5, .95)); ctx.closePath();
    } else if (k === 'cloud') {
      const m = (a, b) => P(a, b);
      ctx.moveTo(...m(.25, .85)); ctx.bezierCurveTo(...m(.05, .85), ...m(0, .55), ...m(.2, .5)); ctx.bezierCurveTo(...m(.15, .25), ...m(.4, .15), ...m(.5, .3));
      ctx.bezierCurveTo(...m(.6, .05), ...m(.9, .15), ...m(.85, .45)); ctx.bezierCurveTo(...m(1.05, .5), ...m(1, .85), ...m(.78, .85)); ctx.closePath();
    } else if (k === 'moon') {
      const m = (a, b) => P(a, b);
      ctx.moveTo(...m(.7, .05)); ctx.bezierCurveTo(...m(.1, .1), ...m(.1, .9), ...m(.7, .95)); ctx.bezierCurveTo(...m(.4, .75), ...m(.4, .25), ...m(.7, .05)); ctx.closePath();
    } else if (k === 'check') { const a = [[.05, .55], [.38, .9], [.95, .12]]; a.forEach((p, i) => ctx[i ? 'lineTo' : 'moveTo'](...P(p[0], p[1]))); }
    else if (poly[k]) { poly[k].forEach((p, i) => ctx[i ? 'lineTo' : 'moveTo'](...P(p[0], p[1]))); ctx.closePath(); }
  }

  R.PT = 1240 / 595.28;
  function drawShape(ctx, o) {
    ctx.save();
    ctx.globalAlpha = o.op == null ? 1 : o.op;
    ctx.strokeStyle = o.color; ctx.fillStyle = o.fillColor || o.color; ctx.lineWidth = o.bw; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    const dash = o.dash === 'dashed' ? [o.bw * 3, o.bw * 2.2] : o.dash === 'dotted' ? [0.01, o.bw * 2.4] : [];
    if (R.isLineShape(o.kind)) {
      ctx.setLineDash(dash);
      ctx.beginPath(); ctx.moveTo(o.x1, o.y1); ctx.lineTo(o.x2, o.y2); ctx.stroke(); ctx.setLineDash([]);
      const head = (ax, ay, bx, by) => {
        const a = Math.atan2(by - ay, bx - ax), L = Math.max(14, o.bw * 4.5);
        ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx - L * Math.cos(a - 0.5), by - L * Math.sin(a - 0.5));
        ctx.moveTo(bx, by); ctx.lineTo(bx - L * Math.cos(a + 0.5), by - L * Math.sin(a + 0.5)); ctx.stroke();
      };
      if (o.kind !== 'line') head(o.x1, o.y1, o.x2, o.y2);
      if (o.kind === 'darrow') head(o.x2, o.y2, o.x1, o.y1);
    } else {
      shapePath(ctx, o);
      if (o.fill && o.kind !== 'check') { const ga = ctx.globalAlpha; ctx.globalAlpha = ga * 0.9; ctx.fill(); ctx.globalAlpha = ga; }
      ctx.setLineDash(dash); ctx.stroke();
    }
    ctx.restore();
  }

  // al = alpha per point (the tail of a trail fades first), o.taper thins the faded part, o.head draws the glowing pointer dot.
  R.drawLaser = function (ctx, pts, al, color, size, o) {
    o = o || {}; const n = pts.length; if (!n && !o.head) return;
    const A = (i) => (al ? al[i] : (o.alpha == null ? 1 : o.alpha));
    ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    const BK = o.fast ? 6 : 14; // fewer opacity steps = fewer strokes per frame (real-time laser)
    if (!o.dot && n > 1) {
      const buckets = new Map(), mid = (i, j) => [(pts[i].x + pts[j].x) / 2, (pts[i].y + pts[j].y) / 2];
      for (let i = 0; i < n; i++) {
        const a = A(i); if (a <= 0.03) continue; let seg;
        if (i === 0) { const m = mid(0, 1); seg = [pts[0].x, pts[0].y, null, null, m[0], m[1]]; }
        else if (i === n - 1) { const m = mid(n - 2, n - 1); seg = [m[0], m[1], null, null, pts[i].x, pts[i].y]; }
        else { const m0 = mid(i - 1, i), m1 = mid(i, i + 1); seg = [m0[0], m0[1], pts[i].x, pts[i].y, m1[0], m1[1]]; }
        const k = Math.max(1, Math.round(a * BK)); let l = buckets.get(k); if (!l) buckets.set(k, (l = [])); l.push(seg);
      }
      for (const [wm, pa, col] of (o.fast ? [[3, 0.13, color], [1, 1, color], [0.42, 0.95, '#fff']] : [[3.4, 0.1, color], [2.0, 0.22, color], [1, 1, color], [0.42, 0.95, '#fff']])) {
        ctx.strokeStyle = col; ctx.lineCap = wm >= 2 ? 'butt' : 'round'; // butt on the soft glow avoids visible beads where alpha levels meet
        for (const [k, segs] of buckets) {
          const a = k / BK, sc = o.taper ? 0.35 + 0.65 * a : 1; ctx.globalAlpha = a * pa; ctx.lineWidth = Math.max(1, size * wm * sc); ctx.beginPath();
          for (const g of segs) { ctx.moveTo(g[0], g[1]); if (g[2] == null) ctx.lineTo(g[4], g[5]); else ctx.quadraticCurveTo(g[2], g[3], g[4], g[5]); }
          ctx.stroke();
        }
      }
    }
    const hd = o.head || (n === 1 ? { x: pts[0].x, y: pts[0].y, a: A(0) } : null);
    if (hd && hd.a > 0.02) {
      const r = size * 0.95, gr = ctx.createRadialGradient(hd.x, hd.y, 0, hd.x, hd.y, r * 2.7);
      gr.addColorStop(0, rgba(color, 0.85)); gr.addColorStop(0.4, rgba(color, 0.45)); gr.addColorStop(1, rgba(color, 0));
      ctx.globalAlpha = hd.a; ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(hd.x, hd.y, r * 2.7, 0, TAU); ctx.fill();
      ctx.fillStyle = color; ctx.beginPath(); ctx.arc(hd.x, hd.y, r, 0, TAU); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(hd.x, hd.y, r * 0.4, 0, TAU); ctx.fill();
    }
    ctx.restore();
  };
  R.drawNeon = function (ctx, pts, color, size, glow, alpha, dot) { R.drawLaser(ctx, pts, null, color, size, { alpha, dot, head: dot ? { x: pts[pts.length - 1].x, y: pts[pts.length - 1].y, a: alpha } : null }); };

  // pictures placed on the page (loaded once, shared by copies of the same picture)
  const imgs = new Map();
  R.onImage = null;
  const getImg = (o) => {
    let e = imgs.get(o.iid);
    if (!e) { e = { img: new Image(), ready: false }; imgs.set(o.iid, e); e.img.onload = () => { e.ready = true; if (R.onImage) R.onImage(); }; e.img.src = o.src; }
    return e;
  };
  R.imagesReady = () => Promise.all([...imgs.values()].map((e) => (e.ready ? 1 : new Promise((r) => { e.img.addEventListener('load', r); e.img.addEventListener('error', r); }))));
  R.preload = (objs) => { objs.forEach((o) => { if (o.t === 'img') getImg(o); }); return R.imagesReady(); };
  R.drawObj = function (ctx, o) {
    if (o.t === 's') R.drawStroke(ctx, o, 0, null, false);
    else if (o.t === 'shape') drawShape(ctx, o);
    else if (o.t === 'img') { const e = getImg(o); if (e.ready) { ctx.save(); ctx.globalAlpha = o.op == null ? 1 : o.op; ctx.drawImage(e.img, o.x, o.y, o.w, o.h); ctx.restore(); } }
  };
  R.isHl = (o) => o.t === 's' && o.tool === 'hl';
  R.bbox = function (o) {
    if (o.t === 's') {
      let a = 1e9, b = 1e9, c = -1e9, d = -1e9;
      for (const p of o.pts) { if (p[0] < a) a = p[0]; if (p[1] < b) b = p[1]; if (p[0] > c) c = p[0]; if (p[1] > d) d = p[1]; }
      const r = o.size / 2 + 1; return { x: a - r, y: b - r, w: c - a + 2 * r, h: d - b + 2 * r };
    }
    if (o.t === 'img') return { x: o.x, y: o.y, w: o.w, h: o.h };
    const p = o.bw / 2 + 2; return { x: Math.min(o.x1, o.x2) - p, y: Math.min(o.y1, o.y2) - p, w: Math.abs(o.x2 - o.x1) + 2 * p, h: Math.abs(o.y2 - o.y1) + 2 * p };
  };
  // scale about (ox,oy) then translate; returns a new object
  R.transform = function (o, ox, oy, sx, sy, dx, dy) {
    const X = (v) => ox + (v - ox) * sx + dx, Y = (v) => oy + (v - oy) * sy + dy;
    const n = Object.assign({}, o);
    if (o.t === 's') { n.pts = o.pts.map((p) => [X(p[0]), Y(p[1]), p[2]]); n.size = Math.max(0.5, o.size * (Math.abs(sx) + Math.abs(sy)) / 2); }
    else if (o.t === 'img') { n.x = X(o.x); n.y = Y(o.y); n.w = o.w * sx; n.h = o.h * sy; }
    else { n.x1 = X(o.x1); n.y1 = Y(o.y1); n.x2 = X(o.x2); n.y2 = Y(o.y2); }
    return n;
  };

  function segDist(px, py, ax, ay, bx, by) {
    const dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
    let t = l2 ? ((px - ax) * dx + (py - ay) * dy) / l2 : 0; t = Math.max(0, Math.min(1, t));
    return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
  }
  R.segDist = segDist;
  R.hit = function (o, x, y, r) {
    if (o.t === 's') {
      const lim = o.size / 2 + r, p = o.pts;
      if (p.length === 1) return Math.hypot(x - p[0][0], y - p[0][1]) <= lim;
      for (let i = 1; i < p.length; i++) if (segDist(x, y, p[i - 1][0], p[i - 1][1], p[i][0], p[i][1]) <= lim) return true;
      return false;
    }
    const b = R.bbox(o);
    if (o.t === 'shape' && R.isLineShape(o.kind)) return segDist(x, y, o.x1, o.y1, o.x2, o.y2) <= o.bw / 2 + r + 6;
    return x >= b.x - r && x <= b.x + b.w + r && y >= b.y - r && y <= b.y + b.h + r;
  };

  /* Hold-to-draw shapes: turns a rough hand-drawn line, circle, triangle, rectangle or polygon into a clean one.
     Returns new points for the same stroke (so the pen / brush / highlighter look is kept) or null. */
  const dp = (P, eps) => { // Douglas-Peucker
    if (P.length < 3) return P;
    let m = 0, k = 0; const a = P[0], b = P[P.length - 1], L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
    for (let i = 1; i < P.length - 1; i++) { const d = Math.abs((b[0] - a[0]) * (a[1] - P[i][1]) - (a[0] - P[i][0]) * (b[1] - a[1])) / L; if (d > m) { m = d; k = i; } }
    if (m <= eps) return [a, b];
    const l = dp(P.slice(0, k + 1), eps), r = dp(P.slice(k), eps); return l.slice(0, -1).concat(r);
  };
  const densify = (V, gap) => { const out = []; for (let i = 0; i < V.length - 1; i++) { const a = V[i], b = V[i + 1], n = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / gap)); for (let j = 0; j < n; j++) out.push([a[0] + (b[0] - a[0]) * j / n, a[1] + (b[1] - a[1]) * j / n, 0.5]); } out.push([V[V.length - 1][0], V[V.length - 1][1], 0.5]); return out; };
  R.linePts = (a, b) => densify([a, b], 6);
  /* An arrow drawn in one stroke: a shaft, then the head. Two kinds are recognised:
       'arrow2'   : head of two arms (an open V)            shaft, tip, arm 1, back to the tip, arm 2
       'arrowTri' : head that is a closed triangle          shaft, tip, arm 1, arm 2, back to the tip
     The result is a clean arrow with equal arms. */
  const arrowOf = (P) => {
    const n = P.length; if (n < 8) return null;
    const a = P[0]; let md = 0;
    for (const p of P) md = Math.max(md, Math.hypot(p[0] - a[0], p[1] - a[1]));
    if (md < 70) return null;
    let ti = 0; for (let i = 0; i < n; i++) if (Math.hypot(P[i][0] - a[0], P[i][1] - a[1]) >= 0.96 * md) { ti = i; break; }   // first arrival at the tip
    const tip = P[ti]; if (ti < 2 || n - ti < 5) return null;
    // the shaft must be straight
    const sl = Math.hypot(tip[0] - a[0], tip[1] - a[1]), ux = (tip[0] - a[0]) / sl, uy = (tip[1] - a[1]) / sl;
    let dev = 0; for (let i = 0; i <= ti; i++) dev = Math.max(dev, Math.abs((P[i][0] - a[0]) * uy - (P[i][1] - a[1]) * ux));
    if (dev > 0.09 * sl) return null;
    // the head: two excursions away from the tip
    const R2 = P.slice(ti);
    const hv = dp(R2, Math.max(4, 0.07 * sl));
    if (hv.length < 4 || hv.length > 5) return null;
    let ad = 0; for (const p of R2) ad = Math.max(ad, Math.hypot(p[0] - tip[0], p[1] - tip[1]));
    const near = (p) => Math.hypot(p[0] - tip[0], p[1] - tip[1]) < 0.3 * ad; // 'back at the tip' is measured against the size of the head
    let a1, a2, kind;
    if (hv.length === 4 && near(hv[0]) && !near(hv[1]) && near(hv[2]) && !near(hv[3])) { a1 = hv[1]; a2 = hv[3]; kind = 'arrow2'; }
    else if (hv.length === 4 && near(hv[0]) && !near(hv[1]) && !near(hv[2]) && near(hv[3])) { a1 = hv[1]; a2 = hv[2]; kind = 'arrowTri'; }
    else if (hv.length === 5 && near(hv[0]) && !near(hv[1]) && near(hv[2]) && !near(hv[3])) { a1 = hv[1]; a2 = hv[3]; kind = 'arrow2'; }
    else if (hv.length === 5 && near(hv[0]) && !near(hv[1]) && !near(hv[2]) && near(hv[hv.length - 1])) { a1 = hv[1]; a2 = hv[2]; kind = 'arrowTri'; }
    else return null;
    // both arms point backwards, on opposite sides of the shaft, and are a sensible length
    const side = (p) => (p[0] - tip[0]) * uy - (p[1] - tip[1]) * ux, back = (p) => -((p[0] - tip[0]) * ux + (p[1] - tip[1]) * uy);
    const la = Math.hypot(a1[0] - tip[0], a1[1] - tip[1]), lb = Math.hypot(a2[0] - tip[0], a2[1] - tip[1]);
    if (side(a1) * side(a2) >= 0 || back(a1) <= 0 || back(a2) <= 0) return null;
    const L = (la + lb) / 2; if (L < 0.07 * sl || L > 0.6 * sl) return null;
    const ang = Math.min(0.75, Math.max(0.35, (Math.atan2(Math.abs(side(a1)), back(a1)) + Math.atan2(Math.abs(side(a2)), back(a2))) / 2));
    // snap the shaft to a straight angle when it is nearly one
    let dx = ux, dy = uy; const sa = Math.atan2(uy, ux), q = Math.PI / 4, k = Math.round(sa / q); if (Math.abs(sa - k * q) < 0.09) { dx = Math.cos(k * q); dy = Math.sin(k * q); }
    const t = [a[0] + dx * sl, a[1] + dy * sl];
    const arm = (sgn) => { const c = Math.cos(Math.PI - sgn * ang), s2 = Math.sin(Math.PI - sgn * ang); return [t[0] + (dx * c - dy * s2) * L, t[1] + (dx * s2 + dy * c) * L]; };
    const e1 = arm(1), e2 = arm(-1);
    const V = kind === 'arrow2' ? [a, t, e1, t, e2] : [a, t, e1, e2, t];
    return { kind, pts: densify(V, 6) };
  };
  R.arrowOf = arrowOf;
  R.recognize = function (pts) {
    const n = pts.length; if (n < 5) return null;
    const P = pts.map((p) => [p[0], p[1]]);
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9, len = 0;
    for (let i = 0; i < n; i++) { const p = P[i]; if (p[0] < x0) x0 = p[0]; if (p[1] < y0) y0 = p[1]; if (p[0] > x1) x1 = p[0]; if (p[1] > y1) y1 = p[1]; if (i) len += Math.hypot(p[0] - P[i - 1][0], p[1] - P[i - 1][1]); }
    const w = x1 - x0, h = y1 - y0, diag = Math.hypot(w, h); if (diag < 40) return null;
    const a = P[0], b = P[n - 1], chord = Math.hypot(b[0] - a[0], b[1] - a[1]);
    if (chord > 0.2 * len) { // open: an arrow (shaft + head) or a straight line is recognised
      const ar = arrowOf(P); if (ar) return ar;
      let m = 0; for (const p of P) m = Math.max(m, Math.abs((b[0] - a[0]) * (a[1] - p[1]) - (a[0] - p[0]) * (b[1] - a[1])) / (chord || 1));
      if (m > 0.07 * chord) return null;
      let e = b; const ang = Math.atan2(b[1] - a[1], b[0] - a[0]), q = Math.PI / 4, k = Math.round(ang / q);
      if (Math.abs(ang - k * q) < 0.09) e = [a[0] + chord * Math.cos(k * q), a[1] + chord * Math.sin(k * q)];
      return { kind: 'line', pts: densify([a, e], 6) };
    }
    // closed: circle / ellipse, triangle, rectangle, or a polygon
    let area = 0; for (let i = 0; i < n; i++) { const p = P[i], q = P[(i + 1) % n]; area += p[0] * q[1] - q[0] * p[1]; }
    const circ = (4 * Math.PI * Math.abs(area / 2)) / (len * len);
    let far = 0, fd = 0; for (let i = 1; i < n; i++) { const d = Math.hypot(P[i][0] - P[0][0], P[i][1] - P[0][1]); if (d > fd) { fd = d; far = i; } }
    const h1 = dp(P.slice(0, far + 1), 0.05 * diag), h2 = dp(P.slice(far).concat([P[0]]), 0.05 * diag);
    let V = h1.slice(0, -1).concat(h2.slice(0, -1)); // closed outline: split at the point farthest from the start, simplify both halves
    if (circ > 0.8 && V.length >= 5) {
      const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2; let rx = w / 2, ry = h / 2; if (Math.abs(rx - ry) / Math.max(rx, ry) < 0.14) rx = ry = (rx + ry) / 2;
      return { kind: 'ellipse', pts: Array.from({ length: 73 }, (_, i) => { const t = (i / 72) * TAU - Math.PI / 2; return [cx + Math.cos(t) * rx, cy + Math.sin(t) * ry, 0.5]; }) };
    }
    if (V.length < 3 || V.length > 8) return null;
    if (V.length === 4) { // a rectangle when the corners are about square: lined up with the page when close to it
      const ex = [0, 1, 2, 3].map((i) => { const p = V[i], q = V[(i + 1) % 4]; return Math.atan2(q[1] - p[1], q[0] - p[0]); });
      const sq = [0, 1, 2, 3].every((i) => { let d = Math.abs(ex[(i + 1) % 4] - ex[i]) % Math.PI; d = Math.abs(d - Math.PI / 2); return d < 0.35; });
      if (sq && ex.every((e) => { const d = Math.abs(((e % (Math.PI / 2)) + Math.PI / 2) % (Math.PI / 2)); return Math.min(d, Math.PI / 2 - d) < 0.14; })) V = [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
    }
    return { kind: V.length === 3 ? 'triangle' : V.length === 4 ? 'quad' : 'polygon', pts: densify(V.concat([V[0]]), 6) };
  };

export default R;
export { R };
