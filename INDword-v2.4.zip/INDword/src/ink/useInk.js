import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import { InkEngine, loadInkPrefs, saveInkPrefs, PALETTE, HL_PALETTE } from './engine.js';

/**
 * Everything the app needs to know about ink:
 *  tool       active drawing tool ('pen' | 'brush' | 'highlighter' | 'laser' | 'eraser' | 'select' | 'shapes') or null = typing
 *  engine     the drawing of the open document (save with engine.toJSON(), open with engine.load())
 */
export default function useInk({ onChange }) {
  const engineRef = useRef(null);
  if (!engineRef.current) engineRef.current = new InkEngine();
  const engine = engineRef.current;
  const [prefs, setPrefs] = useState(loadInkPrefs);
  const [tool, setToolState] = useState(null);
  const [, tick] = useReducer((x) => x + 1, 0);
  const changeRef = useRef(onChange); changeRef.current = onChange;

  useEffect(() => engine.subscribe((k) => {
    tick();
    if (k === 'draw' || k === 'add' || k === 'undo' || k === 'layout') changeRef.current?.();
  }), [engine]);

  useEffect(() => { saveInkPrefs(prefs); }, [prefs]);

  const setTool = useCallback((t) => {
    setToolState(t);
    if (t) { try { document.activeElement?.blur?.(); } catch { /* ignore */ } setPrefs((p) => (p.tool === t ? p : { ...p, tool: t })); }
  }, []);
  const setCfg = useCallback((name, patch) => setPrefs((p) => ({ ...p, cfg: { ...p.cfg, [name]: { ...p.cfg[name], ...patch } } })), []);
  const setPref = useCallback((patch) => setPrefs((p) => ({ ...p, ...patch })), []);

  return useMemo(() => ({
    engine, tool, setTool, cfg: prefs.cfg, setCfg, setPref,
    lastTool: prefs.tool || 'pen',
    fingerDraw: !!prefs.fingerDraw, dock: prefs.dock || 'bottom', hold: prefs.hold !== false,
    palette: prefs.palette || PALETTE, hlPalette: prefs.hlPalette || HL_PALETTE,
    canUndo: engine.canUndo, canRedo: engine.canRedo,
    undo: () => engine.undo(), redo: () => engine.redo(),
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [engine, tool, prefs, setTool, setCfg, setPref, engine.version]);
}
