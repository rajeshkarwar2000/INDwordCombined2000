import { useEffect, useLayoutEffect, useReducer, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Copy, ArrowUpToLine, ArrowDownToLine, Trash2, Crop, RotateCcw, RotateCw, RefreshCw, Download, Lock, Unlock, Undo2, FlipHorizontal2, Contrast } from 'lucide-react';
import R, { UNIT } from './render.js';
import { uid } from './engine.js';
import { pickPicture, imageSize, flipDataUrl } from './picture.js';
import { CropDialog, rotateDataUrl } from '../components/ImageView.jsx';
import { saveBlob } from '../services/exporters.js';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const say = (m) => window.dispatchEvent(new CustomEvent('indword:toast', { detail: m }));
const bboxCache = new WeakMap();
const bboxOf = (o) => { let b = bboxCache.get(o); if (!b) { b = R.bbox(o); bboxCache.set(o, b); } return b; };

/* ---------------------------------------------------------------- one square drawing tile */
// The ink is cut into small tiles that are drawn at the exact screen resolution and only for the part of the page on screen.
// So the lines stay sharp when zoomed far in, and memory and time stay small.
// kind 'base': pen, brush, shapes, pictures.   kind 'hl': highlighter strokes (their layer is multiplied onto the text underneath)
function Tile({ engine, kind, x0, y0, w, h, sc, reg, eager, id }) {
  const cv = useRef(null), raf = useRef(0);
  const [, force] = useReducer((x) => x + 1, 0);
  const [has, setHas] = useState(kind === 'base');
  const pw = Math.max(1, Math.round(w * sc)), ph = Math.max(1, Math.round(h * sc));
  const on = has || !!eager;
  const hit = (o) => { const b = bboxOf(o); return !(b.x > (x0 + w) / UNIT + 40 || b.x + b.w < x0 / UNIT - 40 || b.y > (y0 + h) / UNIT + 40 || b.y + b.h < y0 / UNIT - 40); };
  const setup = (ctx, c) => { const cx = c.width / w, cy = c.height / h; ctx.setTransform(cx * UNIT, 0, 0, cy * UNIT, -x0 * cx, -y0 * cy); ctx.imageSmoothingQuality = 'high'; };

  const paint = () => {
    raf.current = 0;
    const c = cv.current; if (!c) return;
    const pv = engine.preview; const items = [];
    for (const o0 of engine.objs) { const o = pv && pv.id === o0.id ? pv.o : o0; if (R.isHl(o) !== (kind === 'hl')) continue; if (hit(o)) items.push(o); }
    if (kind === 'hl') { const any = items.length > 0; if (any !== has) { setHas(any); if (!has && !eager) return; } }
    const ctx = c.getContext('2d'); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, c.width, c.height);
    if (c.width <= 1) return;
    setup(ctx, c);
    for (const o of items) { if (kind === 'hl') R.drawStroke(ctx, o, 0, null, true); else R.drawObj(ctx, o); }
  };
  const sched = () => { if (!raf.current) raf.current = requestAnimationFrame(paint); };
  // draw one new object on top of what is already there (no repaint of the whole tile)
  const add = (o) => {
    const c = cv.current; if (!c || R.isHl(o) !== (kind === 'hl') || !hit(o)) return;
    if (c.width <= 1) { paint(); return; }
    const ctx = c.getContext('2d'); setup(ctx, c);
    if (kind === 'hl') R.drawStroke(ctx, o, 0, null, true); else R.drawObj(ctx, o);
  };
  const paintRef = useRef(paint); paintRef.current = paint;
  const addRef = useRef(add); addRef.current = add;
  useEffect(() => {
    const un = engine.subscribe((k) => { if (k === 'force') force(); else if (k !== 'add') sched(); });
    reg.set(id, { paint: () => { if (raf.current) { cancelAnimationFrame(raf.current); raf.current = 0; } paintRef.current(); }, add: (o) => addRef.current(o) });
    return () => { un(); reg.delete(id); cancelAnimationFrame(raf.current); raf.current = 0; };
  }, [engine, id]); // eslint-disable-line react-hooks/exhaustive-deps
  useLayoutEffect(() => { paint(); }, [pw, ph, has, eager]); // eslint-disable-line react-hooks/exhaustive-deps
  return <canvas ref={cv} width={on ? pw : 1} height={on ? ph : 1} style={{ position: 'absolute', left: x0, top: y0, width: w, height: h, pointerEvents: 'none' }} />;
}

/* ---------------------------------------------------------------- the layer */
export default function InkLayer({ engine, tool, cfg, fingerDraw, holdShape = true, W, H, gap, pageCount, zoom, scroller, hlBlend = 'multiply', onFlash, onPickColor }) {
  const pitch = H + gap, totalH = pageCount * pitch - gap;
  const layer = useRef(null), live = useRef(null), liveHl = useRef(null), liveTail = useRef(null), laserCv = useRef(null), lastU = useRef(1);
  const [, bump] = useReducer((x) => x + 1, 0);
  const [selId, setSelId] = useState(null);
  const [dlg, setDlg] = useState(null);
  const [rng, setRng] = useState({ r0: 0, r1: 1, c0: 0, c1: 0 });
  const reg = useRef(new Map()).current;
  const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  const sc = Math.round(Math.max(1, Math.min(dpr * zoom, 12)) * 4) / 4;        // screen pixels per page pixel (zoom up to 6x on a 2x screen)
  const T = clamp(Math.floor(1280 / sc / 4) * 4, 96, 1024);                       // tile side in page pixels: each tile is at most about 1280 screen pixels wide

  const S = useRef({}); S.current = { tool, cfg, fingerDraw, holdShape, W, H, pitch, totalH, zoom, selId, hlBlend, sc, T };

  useEffect(() => { engine.relayout(pitch); }, [engine, pitch]);
  useEffect(() => engine.subscribe(() => { const id = S.current.selId; if (id) { if (!engine.objs.some((o) => o.id === id)) setSelId(null); bump(); } }), [engine]);
  useEffect(() => { if (tool !== 'select') setSelId(null); else if (engine.pendingSelect) { setSelId(engine.pendingSelect); engine.pendingSelect = null; } }, [tool, engine]);

  /* which tiles are on screen (plus a margin) */
  const calc = () => {
    const el = layer.current, sv = scroller?.current; if (!el || !sv) return;
    const r = el.getBoundingClientRect(), v = sv.getBoundingClientRect(), u = r.width / S.current.W; if (!u) return;
    const vw = v.width / u, vh = v.height / u, mx = vw * 0.3, my = vh * 0.3, t = S.current.T;
    const x0 = (v.left - r.left) / u - mx, x1 = (v.right - r.left) / u + mx, y0 = (v.top - r.top) / u - my, y1 = (v.bottom - r.top) / u + my;
    const maxC = Math.max(0, Math.ceil(S.current.W / t) - 1), maxR = Math.max(0, Math.ceil(S.current.totalH / t) - 1);
    const n = { c0: clamp(Math.floor(x0 / t), 0, maxC), c1: clamp(Math.floor(x1 / t), 0, maxC), r0: clamp(Math.floor(y0 / t), 0, maxR), r1: clamp(Math.floor(y1 / t), 0, maxR) };
    setRng((p) => (p.c0 === n.c0 && p.c1 === n.c1 && p.r0 === n.r0 && p.r1 === n.r1 ? p : n));
  };
  useLayoutEffect(() => { calc(); }, [zoom, W, totalH, T, sc]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const sv = scroller?.current; if (!sv) return undefined;
    let raf = 0; const f = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; calc(); }); };
    sv.addEventListener('scroll', f, { passive: true }); window.addEventListener('resize', f);
    return () => { sv.removeEventListener('scroll', f); window.removeEventListener('resize', f); cancelAnimationFrame(raf); };
  }, [scroller]); // eslint-disable-line react-hooks/exhaustive-deps

  /* the centre of the screen in page coordinates (where a new picture is placed) */
  useEffect(() => {
    engine.getCenter = () => {
      const el = layer.current, sv = scroller?.current; if (!el || !sv) return { x: 300, y: 300, wInk: 1240 };
      const r = el.getBoundingClientRect(), v = sv.getBoundingClientRect(), u = r.width / S.current.W;
      return { x: ((v.left + v.width / 2 - r.left) / u) / UNIT, y: ((v.top + v.height / 2 - r.top) / u) / UNIT, wInk: S.current.W / UNIT };
    };
    return () => { engine.getCenter = null; };
  }, [engine, scroller]);

  /* ---------- coordinates ---------- */
  const rectRef = useRef(null);
  const toInk = (e) => {
    const r = (st.cur && rectRef.current) || layer.current.getBoundingClientRect(), cssU = r.width / S.current.W;
    return { x: (e.clientX - r.left) / cssU / UNIT, y: (e.clientY - r.top) / cssU / UNIT, u: cssU * UNIT, cssU };
  };
  const pres = (e) => (e.pointerType === 'pen' && e.pressure > 0 ? e.pressure : 0.5);

  /* ---------- live canvases (the stroke being drawn): they cover only the part of the page on screen, at screen resolution ---------- */
  const lv = useRef({ left: 0, top: 0, cpp: 1, cv: null, idle: 0 });
  const openLive = (hl) => {
    const cv = hl ? liveHl.current : live.current, tail = liveTail.current; if (!cv) return null;
    clearTimeout(lv.current.idle);
    const { W: w0, totalH: tot } = S.current;
    const r = layer.current.getBoundingClientRect(), v = (scroller?.current || document.documentElement).getBoundingClientRect(), u = r.width / w0;
    let x0 = (v.left - r.left) / u, x1 = (v.right - r.left) / u, y0 = (v.top - r.top) / u, y1 = (v.bottom - r.top) / u;
    const mx = (x1 - x0) * 0.25, my = (y1 - y0) * 0.25;
    x0 = Math.max(0, x0 - mx); y0 = Math.max(0, y0 - my); x1 = Math.min(w0, x1 + mx); y1 = Math.min(tot, y1 + my);
    const w = Math.max(50, x1 - x0), h = Math.max(50, y1 - y0), cpp = Math.min(S.current.sc, Math.sqrt(9e6 / (w * h)));
    const pw = Math.round(w * cpp), ph = Math.round(h * cpp);
    [cv, tail].forEach((c) => { if (!c) return; if (c.width !== pw || c.height !== ph) { c.width = pw; c.height = ph; } else c.getContext('2d').clearRect(0, 0, c.width, c.height); Object.assign(c.style, { left: `${x0}px`, top: `${y0}px`, width: `${w}px`, height: `${h}px` }); });
    lv.current = { ...lv.current, left: x0, top: y0, cpp, cv };
    return cv.getContext('2d');
  };
  const setT = (c) => { const { left, top, cpp } = lv.current, x = c.getContext('2d'); x.setTransform(cpp * UNIT, 0, 0, cpp * UNIT, -left * cpp, -top * cpp); return x; };
  const liveCtx = () => setT(lv.current.cv);
  const tailCtx = () => setT(liveTail.current);
  const wipe = (c) => { if (c && c.width > 1) { const x = c.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, c.width, c.height); } };
  const closeLive = () => {
    [live.current, liveHl.current, liveTail.current].forEach(wipe);
    clearTimeout(lv.current.idle);
    lv.current.idle = setTimeout(() => { [live.current, liveHl.current, liveTail.current].forEach((c) => { if (c) { c.width = 1; c.height = 1; } }); }, 20000);
  };
  const paintAll = () => reg.forEach((e) => e.paint());
  const addAll = (o) => reg.forEach((e) => e.add(o));

  /* ---------- input ---------- */
  const st = useRef({ cur: null, touches: new Map(), pinch: false, lastPen: 0, raf: 0, vel: { vx: 0, vy: 0, t: 0 }, pan: { x: 0, y: 0, raf: 0 }, fling: 0, lastTap: 0, laser: { strokes: [], cur: null, raf: 0 } }).current;

  useEffect(() => {
    const el = layer.current; if (!el || !tool) return undefined;
    const sc0 = () => scroller?.current;
    if (['pen', 'brush', 'highlighter', 'eraser', 'shapes'].includes(tool)) { openLive(tool === 'highlighter'); closeLive(); } // allocate the live canvases now, so the first stroke starts without delay
    const cap = (id) => { try { el.setPointerCapture(id); } catch { /* released pointer */ } };

    const applyPan = () => { st.pan.raf = 0; const s = sc0(); if (s) { s.scrollLeft -= st.pan.x; s.scrollTop -= st.pan.y; } st.pan.x = st.pan.y = 0; };
    const flingStop = () => { if (st.fling) { cancelAnimationFrame(st.fling); st.fling = 0; } };
    const doFling = () => {
      flingStop(); let last = performance.now();
      const tick = (t) => {
        const dt = Math.min(40, t - last); last = t; const s = sc0(); if (!s) return;
        s.scrollLeft -= st.vel.vx * dt; s.scrollTop -= st.vel.vy * dt;
        const f = Math.exp(-dt / 330); st.vel.vx *= f; st.vel.vy *= f;
        st.fling = Math.hypot(st.vel.vx, st.vel.vy) > 0.02 ? requestAnimationFrame(tick) : 0;
      };
      st.fling = requestAnimationFrame(tick);
    };

    /* ===== pointer down ===== */
    const down = (e) => {
      if (e.target.closest && e.target.closest('[data-inkui]')) return;
      flingStop();
      const { fingerDraw: fd } = S.current;
      if (e.pointerType === 'pen') st.lastPen = performance.now();
      if (e.pointerType === 'touch') {
        if (!fd && performance.now() - st.lastPen < 700) return; // palm rejection
        st.touches.set(e.pointerId, { x: e.clientX, y: e.clientY }); st.vel.vx = st.vel.vy = 0; st.vel.t = 0;
        if (st.touches.size >= 2) { cancelDraw(); st.pinch = true; return; }
        if (!fd) { cap(e.pointerId); return; }
      }
      if (st.touches.size >= 2) return;
      let t = S.current.tool;
      if (e.pointerType === 'pen' && (e.buttons & 32 || e.button === 5)) t = 'eraser';
      cap(e.pointerId);
      if (t === 'laser') { beginLaser(e); return; }
      begin(t, e);
    };

    const begin = (t, e) => {
      const p = toInk(e), c = S.current.cfg[t] || {};
      st.cur = { tool: t, id: e.pointerId, u: p.u, x0: p.x, y0: p.y, moved: false, q: [] };
      rectRef.current = layer.current.getBoundingClientRect();
      const cur = st.cur;
      if (t === 'pen' || t === 'brush' || t === 'highlighter') {
        const kind = t === 'highlighter' ? 'hl' : t;
        const s = { id: uid(), t: 's', tool: kind, pts: [[p.x, p.y, pres(e)]], size: c.size, color: c.color, seed: (Math.random() * 1e9) | 0 };
        if (t === 'pen') Object.assign(s, { pen: c.pen, line: c.line, space: c.space, nib: c.nib, angle: c.angle });
        if (t === 'brush') s.brush = c.brush;
        if (t === 'highlighter') { s.alpha = c.alpha; s.tip = c.tip || 'round'; s.straight = !!c.straight; }
        cur.s = s; cur.st = R.newStrokeState(s); cur.drawn = 0; cur.hx = p.x; cur.hy = p.y;
        openLive(t === 'highlighter');
        liveStroke(); armHold();
      } else if (t === 'eraser') {
        openLive(false); cur.pushed = false; eraseAt(p); drawEraserCursor(p);
      } else if (t === 'select') selectDown(p);
      else if (t === 'shapes') { cur.x1 = p.x; cur.y1 = p.y; cur.x2 = p.x; cur.y2 = p.y; openLive(false); }
    };

    /* ===== move ===== */
    const move = (e) => {
      if (e.pointerType === 'touch' && st.touches.has(e.pointerId)) {
        const prev = st.touches.get(e.pointerId); st.touches.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (st.pinch || st.touches.size >= 2) return;
        if (!st.cur) {
          const dx = e.clientX - prev.x, dy = e.clientY - prev.y, now = performance.now(), dt = Math.max(1, now - (st.vel.t || now - 16));
          st.pan.x += dx; st.pan.y += dy; if (!st.pan.raf) st.pan.raf = requestAnimationFrame(applyPan);
          st.vel.vx = st.vel.vx * 0.55 + (dx / dt) * 0.45; st.vel.vy = st.vel.vy * 0.55 + (dy / dt) * 0.45; st.vel.t = now; return;
        }
      }
      const cur = st.cur; if (!cur || cur.id !== e.pointerId) return;
      const evs = (e.getCoalescedEvents && e.getCoalescedEvents()) || [], list = evs.length ? evs : [e];
      if (cur.tool === 'laser') {
        const ls = st.laser.cur, now = performance.now();
        if (ls) {
          for (const ev of list) {
            const q = { x: ev.clientX, y: ev.clientY, t: now };
            if (ls.mode === 'dot') ls.pts = [q]; else { const l = ls.pts[ls.pts.length - 1]; if (Math.hypot(q.x - l.x, q.y - l.y) >= 1) ls.pts.push(q); }
          }
          const pe = e.getPredictedEvents && e.getPredictedEvents(), pp = pe && pe.length ? pe[pe.length - 1] : null; // where the pen is about to be: hides the display delay
          ls.pred = pp ? { x: pp.clientX, y: pp.clientY } : null;
        }
        if (now - (st.laser.syncT || 0) > 6) { st.laser.syncT = now; laserRender(); } // draw right now, not on the next frame
        laserLoop(); return;
      }
      for (const ev of list) step(ev);
    };
    const step = (ev) => {
      const cur = st.cur, p = toInk(ev), t = cur.tool;
      if (!cur.moved && Math.hypot(p.x - cur.x0, p.y - cur.y0) * cur.u > 4) cur.moved = true;
      if (cur.s) {
        const s = cur.s;
        if (cur.frozen) return;
        if (cur.snapped === 'line') { // a snapped line keeps following the pen until it is lifted
          const a = s.pts[0]; let x = p.x, y = p.y; const dx = x - a[0], dy = y - a[1], L = Math.hypot(dx, dy), ang = Math.atan2(dy, dx), q = Math.PI / 4, k = Math.round(ang / q);
          if (L && Math.abs(ang - k * q) < 0.09) { x = a[0] + L * Math.cos(k * q); y = a[1] + L * Math.sin(k * q); }
          s.pts = R.linePts(a, [x, y]); sched(); return;
        }
        if (s.straight) {
          let x = p.x, y = p.y; const a = s.pts[0], dx = x - a[0], dy = y - a[1], L = Math.hypot(dx, dy);
          if (L > 8 / cur.u) { const ang = Math.abs(Math.atan2(dy, dx)); if (ang < 0.07 || ang > Math.PI - 0.07) y = a[1]; else if (Math.abs(ang - Math.PI / 2) < 0.07) x = a[0]; }
          s.pts = [a, [x, y, 0.5]];
        } else { const l = s.pts[s.pts.length - 1]; if (s.pts.length < 2 || Math.hypot(p.x - l[0], p.y - l[1]) * cur.u >= 1.4) s.pts.push([p.x, p.y, pres(ev)]); }
        if (Math.hypot(p.x - cur.hx, p.y - cur.hy) * cur.u > 3) { cur.hx = p.x; cur.hy = p.y; armHold(); } // still moving: restart the hold timer
        sched();
      } else if (t === 'eraser') { cur.q.push(p); sched(); }
      else if (t === 'select') { cur.last = p; sched(); }
      else if (t === 'shapes') { cur.x2 = p.x; cur.y2 = p.y; sched(); }
    };
    const sched = () => { if (!st.raf) st.raf = requestAnimationFrame(frame); };
    const frame = () => {
      st.raf = 0; const cur = st.cur; if (!cur) return; const t = cur.tool;
      if (t !== 'laser') rectRef.current = layer.current.getBoundingClientRect();
      if (cur.s) { if (cur.snapped) redrawFull(); else liveStroke(); }
      else if (t === 'eraser') { const q = cur.q; cur.q = []; for (const p of q) eraseAt(p); if (q.length) drawEraserCursor(q[q.length - 1]); }
      else if (t === 'select') { if (cur.last) selectMove(cur.last); }
      else if (t === 'shapes') drawCreating();
    };

    /* ===== up ===== */
    const up = (e) => {
      if (e.pointerType === 'touch') {
        st.touches.delete(e.pointerId);
        if (st.touches.size < 2) st.pinch = st.touches.size > 0 ? st.pinch : false;
        if (!st.cur && st.touches.size === 0 && performance.now() - st.vel.t < 90 && Math.hypot(st.vel.vx, st.vel.vy) > 0.25) doFling();
      }
      const cur = st.cur; if (!cur || cur.id !== e.pointerId) return;
      if (st.raf) { cancelAnimationFrame(st.raf); st.raf = 0; }
      frame();
      st.cur = null;
      const t = cur.tool;
      if (cur.s) { clearTimeout(cur.ht); commitStroke(cur); }
      else if (t === 'eraser') { closeLive(); }
      else if (t === 'laser') { if (st.laser.cur) { st.laser.cur.end = performance.now(); st.laser.cur = null; } }
      else if (t === 'select') selectUp(cur);
      else if (t === 'shapes') commitShape(cur);
    };
    const cancelDraw = () => {
      const cur = st.cur; if (!cur) return; st.cur = null; clearTimeout(cur.ht);
      if (cur.tool === 'laser') { if (st.laser.cur) { st.laser.cur.end = performance.now(); st.laser.cur = null; } return; }
      if (cur.tool === 'select') { engine.preview = null; paintAll(); }
      closeLive();
    };

    /* ===== strokes ===== */
    function liveBall() {
      const cur = st.cur, s = cur.s, pts = s.pts, n = pts.length, ctx = liveCtx(), tc = tailCtx();
      if (cur.bx == null) { cur.bx = pts[0][0]; cur.by = pts[0][1]; cur.ni = 1; }
      // the finished part of the curve (quadratic pieces through the midpoints: they never change once drawn)
      if (n > cur.ni) {
        ctx.save(); ctx.strokeStyle = s.color; ctx.lineWidth = s.size; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.beginPath(); ctx.moveTo(cur.bx, cur.by);
        for (let i = cur.ni; i < n; i++) { const a = pts[i - 1], b = pts[i], mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2; ctx.quadraticCurveTo(a[0], a[1], mx, my); cur.bx = mx; cur.by = my; }
        ctx.stroke(); ctx.restore(); cur.ni = n;
      }
      // the unfinished last half-segment lives on its own canvas and is wiped every frame
      const pad = s.size + 4, last = pts[n - 1], bb = [Math.min(cur.bx, last[0]) - pad, Math.min(cur.by, last[1]) - pad, Math.max(cur.bx, last[0]) + pad, Math.max(cur.by, last[1]) + pad];
      const pv = cur.tb || bb; cur.tb = bb;
      tc.clearRect(Math.min(pv[0], bb[0]) - 2, Math.min(pv[1], bb[1]) - 2, Math.max(pv[2], bb[2]) - Math.min(pv[0], bb[0]) + 4, Math.max(pv[3], bb[3]) - Math.min(pv[1], bb[1]) + 4);
      tc.save(); tc.strokeStyle = tc.fillStyle = s.color; tc.lineWidth = s.size; tc.lineCap = 'round'; tc.lineJoin = 'round';
      if (n === 1) { tc.beginPath(); tc.arc(last[0], last[1], s.size / 2, 0, Math.PI * 2); tc.fill(); } else { tc.beginPath(); tc.moveTo(cur.bx, cur.by); tc.lineTo(last[0], last[1]); tc.stroke(); }
      tc.restore();
    }
    function redrawFull() { // whole stroke again on a clean live canvas (used after a shape snap)
      const cur = st.cur, s = cur.s; if (!cur || !s) return;
      [live.current, liveHl.current, liveTail.current].forEach(wipe);
      R.drawStroke(liveCtx(), s, 0, null, true); cur.drawn = s.pts.length;
    }
    function snapNow() { // the pen rested: turn the rough line / circle / triangle / rectangle into a clean one, in the same pen style
      const cur = st.cur; if (!cur || !cur.s || cur.snapped || !S.current.holdShape) return;
      const s = cur.s; if (s.straight || s.pts.length < 5) return;
      const rec = R.recognize(s.pts); if (!rec) return;
      s.pts = rec.pts; cur.snapped = rec.kind; cur.frozen = rec.kind !== 'line';
      redrawFull(); try { if (navigator.vibrate) navigator.vibrate(12); } catch { /* no vibration */ }
    }
    function armHold() {
      const cur = st.cur; if (!cur || !cur.s) return; clearTimeout(cur.ht);
      if (S.current.holdShape && !cur.snapped && !cur.s.straight) cur.ht = setTimeout(snapNow, 480);
    }
    function liveRibbon() { // natural / calligraphy pen: finished curve on the live canvas, the unfinished last bit on the tail canvas (wiped every frame)
      const cur = st.cur, s = cur.s, n = s.pts.length, ctx = liveCtx(), tc = tailCtx();
      R.drawStroke(ctx, s, cur.drawn, cur.st, true, 'body'); cur.drawn = n;
      const last = s.pts[n - 1], m = cur.st.m, mx = m ? m[0] : last[0], my = m ? m[1] : last[1], pad = s.size * 1.6 + 6;
      const bb = [Math.min(mx, last[0]) - pad, Math.min(my, last[1]) - pad, Math.max(mx, last[0]) + pad, Math.max(my, last[1]) + pad];
      const pv = cur.tb || bb; cur.tb = bb;
      tc.clearRect(Math.min(pv[0], bb[0]) - 2, Math.min(pv[1], bb[1]) - 2, Math.max(pv[2], bb[2]) - Math.min(pv[0], bb[0]) + 4, Math.max(pv[3], bb[3]) - Math.min(pv[1], bb[1]) + 4);
      R.drawStroke(tc, s, 0, cur.st, true, 'tail');
    }
    function liveStroke() {
      const cur = st.cur, s = cur.s;
      if (s.tool === 'pen' && (!s.line || s.line === 'solid') && (s.pen === 'natural' || s.pen === 'calligraphy' || s.pen === 'fountain')) { liveRibbon(); return; }
      if (s.tool === 'brush' && s.pts.length < 2) return; // no blob at pen-down: the brush starts drawing when the pen moves
      if (s.tool === 'pen' && (s.pen || 'ball') === 'ball' && (!s.line || s.line === 'solid')) { liveBall(); return; }
      const ctx = liveCtx();
      if (s.tool === 'hl' || (s.tool === 'pen' && s.line && s.line !== 'solid')) {
        const bb = cur.bb || (cur.bb = [1e9, 1e9, -1e9, -1e9]), pad = s.size + 4;
        for (let i = cur.drawn || 0; i < s.pts.length; i++) { const q = s.pts[i]; if (q[0] < bb[0]) bb[0] = q[0]; if (q[1] < bb[1]) bb[1] = q[1]; if (q[0] > bb[2]) bb[2] = q[0]; if (q[1] > bb[3]) bb[3] = q[1]; }
        const pv = cur.pb || bb; cur.pb = bb.slice();
        const x0 = Math.min(pv[0], bb[0]) - pad, y0 = Math.min(pv[1], bb[1]) - pad, x1 = Math.max(pv[2], bb[2]) + pad, y1 = Math.max(pv[3], bb[3]) + pad;
        ctx.clearRect(x0 - pad * 2, y0 - pad * 2, x1 - x0 + pad * 4, y1 - y0 + pad * 4);
        cur.drawn = s.pts.length; R.drawStroke(ctx, s, 0, null, true); return;
      }
      R.drawStroke(ctx, s, cur.drawn, cur.st, true); cur.drawn = s.pts.length;
    }
    function commitStroke(c) {
      const s = c.s;
      if (s.pts.length === 1 && s.pen) s.pts.push([s.pts[0][0] + 0.01, s.pts[0][1], s.pts[0][2]]);
      engine.push(); engine.set([...engine.objs, s], 'add'); addAll(s); closeLive(); // only the new stroke is drawn onto the tiles, then the live canvases are wiped in the same frame: no lag, no blink
    }

    /* ===== eraser ===== */
    const densify = (pts, gapU) => {
      const out = [pts[0]];
      for (let i = 1; i < pts.length; i++) {
        const a = pts[i - 1], b = pts[i], d = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.ceil(d / gapU);
        for (let k = 1; k <= n; k++) { const f = k / n; out.push([a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, (a[2] ?? 0.5) + ((b[2] ?? 0.5) - (a[2] ?? 0.5)) * f]); }
      }
      return out;
    };
    function eraseAt(p) {
      const ec = S.current.cfg.eraser, r = ec.size / 2, out = []; let changed = false;
      for (const o of engine.objs) {
        if (!R.hit(o, p.x, p.y, r)) { out.push(o); continue; }
        if (ec.mode === 'pixel' && o.t === 's') {
          const lim = r + o.size / 2, dp = densify(o.pts, Math.max(2, o.size / 3)), runs = []; let run = [];
          for (const q of dp) { if (Math.hypot(q[0] - p.x, q[1] - p.y) <= lim) { if (run.length) runs.push(run); run = []; } else run.push(q); }
          if (run.length) runs.push(run);
          if (runs.length === 1 && runs[0].length === dp.length) { out.push(o); continue; }
          runs.forEach((rn) => out.push({ ...o, id: uid(), pts: rn }));
          changed = true;
        } else changed = true;
      }
      if (changed) { if (!st.cur.pushed) { engine.push(); st.cur.pushed = true; } engine.set(out); }
    }
    function drawEraserCursor(p) {
      const cur = st.cur, ctx = liveCtx(), rr = S.current.cfg.eraser.size / 2 + 6;
      if (cur.ec) ctx.clearRect(cur.ec.x - rr, cur.ec.y - rr, rr * 2, rr * 2); else ctx.clearRect(0, 0, 1e5, 1e5);
      cur.ec = { x: p.x, y: p.y };
      ctx.save(); ctx.strokeStyle = 'rgba(60,70,90,.85)'; ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.lineWidth = 2 / (lv.current.cpp * UNIT);
      ctx.beginPath(); ctx.arc(p.x, p.y, S.current.cfg.eraser.size / 2, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); ctx.restore();
    }

    /* ===== laser pointer (screen-space canvas, never saved) ===== */
    const decimate = (pts, gap) => { // a slow swipe adds a point every pixel: draw only every few pixels (same look, far less work)
      if (pts.length < 4) return pts; const out = [pts[0]];
      for (let i = 1; i < pts.length - 1; i++) { const p = pts[i], l = out[out.length - 1]; if (Math.hypot(p.x - l.x, p.y - l.y) >= gap) out.push(p); }
      out.push(pts[pts.length - 1]); return out;
    };
    const lctx = () => { const cv = laserCv.current; if (!cv) return null; if (!cv.__c) cv.__c = cv.getContext('2d', { desynchronized: true }); return cv.__c; }; // low-latency canvas
    function beginLaser(e) {
      const lc = S.current.cfg.laser, now = performance.now();
      st.cur = { tool: 'laser', id: e.pointerId };
      const ls = { pts: [{ x: e.clientX, y: e.clientY, t: now }], pred: null, end: 0, mode: lc.mode === 'delay' ? 'hold' : lc.mode === 'line' ? 'trail' : lc.mode, color: lc.color, size: lc.size, delay: lc.delay, trail: lc.trail || 650 };
      st.laser.strokes.push(ls); st.laser.cur = ls; laserRender(); laserLoop();
    }
    function laserRender() { // draws every laser mark now; only the area used by the marks is cleared and redrawn
      const L = st.laser, cv = laserCv.current, ctx = lctx(); if (!cv || !ctx) return false;
      const d = Math.min(window.devicePixelRatio || 1, 1.25), w = window.innerWidth, hh = window.innerHeight;
      if (cv.width !== Math.round(w * d) || cv.height !== Math.round(hh * d)) { cv.width = Math.round(w * d); cv.height = Math.round(hh * d); L.box = null; }
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      if (L.box) ctx.clearRect(Math.floor(L.box[0] * d) - 2, Math.floor(L.box[1] * d) - 2, Math.ceil((L.box[2] - L.box[0]) * d) + 4, Math.ceil((L.box[3] - L.box[1]) * d) + 4); else ctx.clearRect(0, 0, cv.width, cv.height);
      ctx.setTransform(d, 0, 0, d, 0, 0);
      const now = performance.now(), keep = []; let bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9;
      const grow = (x, y, p) => { if (x - p < bx0) bx0 = x - p; if (y - p < by0) by0 = y - p; if (x + p > bx1) bx1 = x + p; if (y + p > by1) by1 = y + p; };
      for (const s of L.strokes) {
        const isDown = !s.end, since = now - s.end, sz = s.size * 0.8, last = s.pts[s.pts.length - 1], hx = isDown && s.pred ? s.pred : last, pad = sz * 4 + 10;
        if (s.mode === 'dot') {
          if (!isDown && since > 220) continue; keep.push(s);
          R.drawLaser(ctx, [], null, s.color, sz, { head: { x: hx.x, y: hx.y, a: isDown ? 1 : 1 - since / 220 } }); grow(hx.x, hx.y, pad);
        } else if (s.mode === 'hold') {
          const fade = isDown ? 1 : (since - s.delay * 1000 <= 0 ? 1 : 1 - (since - s.delay * 1000) / 650);
          if (fade <= 0) continue; keep.push(s);
          R.drawLaser(ctx, decimate(s.pts, 3), null, s.color, sz, { alpha: fade, fast: true, head: isDown ? { x: hx.x, y: hx.y, a: 1 } : null });
          for (const q of s.pts) grow(q.x, q.y, pad); if (isDown) grow(hx.x, hx.y, pad);
        } else {
          const TR = s.trail; if (!isDown && since > TR + 60) continue; keep.push(s);
          while (s.pts.length > 2 && now - s.pts[0].t > TR + 60) s.pts.shift();
          const dpts = decimate(s.pts, 3), al = dpts.map((q) => { const a = 1 - (now - q.t) / TR; return a <= 0 ? 0 : Math.pow(a, 1.25); });
          R.drawLaser(ctx, dpts, al, s.color, sz, { taper: true, fast: true, head: isDown ? { x: hx.x, y: hx.y, a: 1 } : (since < 150 ? { x: last.x, y: last.y, a: 1 - since / 150 } : null) });
          for (const q of s.pts) grow(q.x, q.y, pad); if (isDown) grow(hx.x, hx.y, pad);
        }
      }
      L.box = keep.length ? [Math.max(0, bx0), Math.max(0, by0), Math.min(w, bx1), Math.min(hh, by1)] : null;
      L.strokes = keep; return keep.length > 0;
    }
    function laserLoop() {
      const L = st.laser; if (L.raf) return;
      const tick = () => { L.raf = 0; const t = performance.now(); if (t - (L.syncT || 0) < 4) { L.raf = requestAnimationFrame(tick); return; } if (laserRender()) L.raf = requestAnimationFrame(tick); };
      L.raf = requestAnimationFrame(tick);
    }

    /* ===== shapes ===== */
    const snapLine = (c) => {
      const dx = c.x2 - c.x1, dy = c.y2 - c.y1, L = Math.hypot(dx, dy); if (!L) return;
      const a = Math.atan2(dy, dx), q = Math.PI / 4, n = Math.round(a / q);
      if (Math.abs(a - n * q) < 0.09) { c.x2 = c.x1 + L * Math.cos(n * q); c.y2 = c.y1 + L * Math.sin(n * q); }
    };
    const shapeObj = (c, id) => { const k = S.current.cfg.shapes; return { id, t: 'shape', kind: k.kind, x1: c.x1, y1: c.y1, x2: c.x2, y2: c.y2, color: k.color, bw: k.bw, fill: k.fill, fillColor: k.fillColor || null, dash: k.dash, op: k.op }; };
    function drawCreating() {
      const ctx = liveCtx(), c = st.cur; ctx.clearRect(0, 0, 1e5, 1e5);
      if (R.isLineShape(S.current.cfg.shapes.kind)) snapLine(c);
      R.drawObj(ctx, shapeObj(c));
    }
    function commitShape(c) {
      closeLive();
      if (Math.hypot(c.x2 - c.x1, c.y2 - c.y1) * c.u < 10) { // a tap places a default-size shape
        const d = 220, k = S.current.cfg.shapes.kind, line = R.isLineShape(k);
        c.x1 = Math.max(10, c.x0 - d / 2); c.y1 = c.y0 - d / 2 + (line ? d / 2 : 0); c.x2 = c.x1 + d; c.y2 = line ? c.y1 : c.y1 + d * 0.7;
      } else if (R.isLineShape(S.current.cfg.shapes.kind)) snapLine(c);
      const o = shapeObj(c, uid()); engine.push(); engine.set([...engine.objs, o], 'add'); addAll(o);
    }

    /* ===== select / move / resize ===== */
    const handles = (o) => {
      const b = R.bbox(o), r = Math.max(22, 20 / (lastU.current || 1));
      const line = o.t === 'shape' && R.isLineShape(o.kind);
      return { b, r, del: [b.x + b.w + 8, b.y - 8], size: [b.x + b.w, b.y + b.h], ep: line ? [[o.x1, o.y1], [o.x2, o.y2]] : null };
    };
    function selectDown(p) {
      lastU.current = p.u;
      const cur = st.cur, selO = engine.objs.find((o) => o.id === S.current.selId);
      if (selO) {
        const hd = handles(selO);
        if (Math.hypot(p.x - hd.del[0], p.y - hd.del[1]) <= hd.r) { cur.mode = 'delete'; return; }
        if (hd.ep) for (let i = 0; i < 2; i++) if (Math.hypot(p.x - hd.ep[i][0], p.y - hd.ep[i][1]) <= hd.r) { cur.mode = 'endpoint'; cur.ei = i; cur.o0 = selO; return; }
        if (Math.hypot(p.x - hd.size[0], p.y - hd.size[1]) <= hd.r) { cur.mode = 'resize'; cur.o0 = selO; cur.b0 = R.bbox(selO); return; }
      }
      let hit = null;
      for (let i = engine.objs.length - 1; i >= 0; i--) if (R.hit(engine.objs[i], p.x, p.y, 10 / p.u)) { hit = engine.objs[i]; break; }
      if (!hit) { cur.mode = 'none'; setSelId(null); return; }
      setSelId(hit.id); S.current.selId = hit.id; cur.mode = 'move'; cur.o0 = hit;
    }
    function selectMove(p) {
      const cur = st.cur, m = cur.mode; if (m !== 'move' && m !== 'resize' && m !== 'endpoint') return;
      if (!cur.moved) return;
      const o0 = cur.o0; let o;
      if (m === 'move') o = R.transform(o0, 0, 0, 1, 1, p.x - cur.x0, p.y - cur.y0);
      else if (m === 'endpoint') {
        o = { ...o0 }; const k = cur.ei ? ['x2', 'y2'] : ['x1', 'y1']; o[k[0]] = p.x; o[k[1]] = p.y;
        const dx = o.x2 - o.x1, dy = o.y2 - o.y1, L = Math.hypot(dx, dy), q = Math.PI / 4, n = Math.round(Math.atan2(dy, dx) / q);
        if (L && Math.abs(Math.atan2(dy, dx) - n * q) < 0.09) { if (cur.ei) { o.x2 = o.x1 + L * Math.cos(n * q); o.y2 = o.y1 + L * Math.sin(n * q); } else { o.x1 = o.x2 - L * Math.cos(n * q); o.y1 = o.y2 - L * Math.sin(n * q); } }
      } else {
        const b = cur.b0; let sx = Math.max(0.1, (p.x - b.x) / b.w), sy = Math.max(0.1, (p.y - b.y) / b.h);
        if (o0.t === 's' || (o0.t === 'img' && o0.lock !== false)) sx = sy = Math.max(0.1, (sx + sy) / 2);
        o = R.transform(o0, b.x, b.y, sx, sy, 0, 0);
      }
      cur.cur = o; engine.preview = { id: o0.id, o }; paintAll(); bump();
    }
    function selectUp(c) {
      if (c.mode === 'delete') { if (S.current.selId) engine.remove([S.current.selId]); setSelId(null); paintAll(); return; }
      engine.preview = null;
      if (c.mode === 'none') { paintAll(); return; }
      if (c.moved && c.cur) { engine.replace(c.o0.id, c.cur); paintAll(); bump(); return; }
      paintAll(); bump();
    }

    el.addEventListener('pointerdown', down);
    el.addEventListener('pointermove', move);
    const raw = (e) => { if (st.cur && st.cur.tool === 'laser' && e.pointerId === st.cur.id) move(e); };
    if (tool === 'laser' && 'onpointerrawupdate' in window) el.addEventListener('pointerrawupdate', raw); // un-throttled pen samples
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    const noMenu = (e) => e.preventDefault();
    el.addEventListener('contextmenu', noMenu);
    return () => {
      el.removeEventListener('pointerdown', down); el.removeEventListener('pointermove', move); el.removeEventListener('pointerrawupdate', raw);
      el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', up); el.removeEventListener('contextmenu', noMenu);
      cancelAnimationFrame(st.raf); st.raf = 0; st.cur = null; st.touches.clear(); st.pinch = false; flingStop();
      cancelAnimationFrame(st.pan.raf); st.pan.raf = 0;
      st.laser.strokes = []; st.laser.cur = null; cancelAnimationFrame(st.laser.raf); st.laser.raf = 0;
      const lc = laserCv.current; if (lc) { const c = lc.getContext('2d'); c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, lc.width, lc.height); }
      engine.preview = null; closeLive(); clearTimeout(lv.current.idle);
      [live.current, liveHl.current, liveTail.current].forEach((c) => { if (c) { c.width = 1; c.height = 1; } });
    };
  }, [tool, engine, scroller]); // eslint-disable-line react-hooks/exhaustive-deps

  /* keyboard: Delete removes the selected object */
  useEffect(() => {
    if (tool !== 'select') return undefined;
    const k = (e) => { if ((e.key === 'Delete' || e.key === 'Backspace') && S.current.selId && !/INPUT|TEXTAREA/.test((e.target || {}).tagName || '')) { engine.remove([S.current.selId]); setSelId(null); } };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [tool, engine]);

  /* ---------- picture options (the same ones the Word picture tool has) ---------- */
  const picture = (() => {
    const cur = () => engine.objs.find((o) => o.id === selId);
    const put = (o, patch) => { const n = { ...o, ...patch }; R.preload([n]); engine.replace(o.id, n); };
    const newSource = async (o, src, how) => { // a changed picture: new source, same place and width (turned pictures keep their on-screen size)
      try {
        const d = await imageSize(src), cx = o.x + o.w / 2, cy = o.y + o.h / 2;
        let w = o.w, h = (w * d.h) / d.w; if (how === 'turn') { w = o.h; h = o.w; }
        put(o, { src, iid: uid(), nw: d.w, nh: d.h, x: cx - w / 2, y: cy - h / 2, w, h });
      } catch (e) { say(e.message); }
    };
    return {
      size: (p) => { const o = cur(); if (!o) return; const nw = (S.current.W / UNIT) * (p / 100), nh = nw * (o.h / o.w), cx = o.x + o.w / 2, cy = o.y + o.h / 2; put(o, { x: cx - nw / 2, y: cy - nh / 2, w: nw, h: nh }); },
      lock: () => { const o = cur(); if (o) put(o, { lock: o.lock === false }); },
      reset: () => { const o = cur(); if (!o) return; const ratio = o.nh && o.nw ? o.nh / o.nw : o.h / o.w, cx = o.x + o.w / 2, cy = o.y + o.h / 2, w = o.w, h = w * ratio; put(o, { x: cx - w / 2, y: cy - h / 2, h }); },
      rotate: async (deg) => { const o = cur(); if (o) newSource(o, await rotateDataUrl(o.src, deg), 'turn'); },
      flip: async () => { const o = cur(); if (o) newSource(o, await flipDataUrl(o.src), 'keep'); },
      replace: async () => { const o = cur(), pic = await pickPicture(); if (o && pic) newSource(o, pic.url, 'keep'); },
      crop: (url) => { const o = cur(); if (o) newSource(o, url, 'keep'); },
      opacity: () => { const o = cur(); if (!o) return; const l = [1, 0.75, 0.5, 0.25], i = l.findIndex((v) => Math.abs(v - (o.op == null ? 1 : o.op)) < 0.01); put(o, { op: l[(i + 1) % l.length] }); },
      download: async () => { const o = cur(); if (!o) return; try { const blob = await (await fetch(o.src)).blob(); saveBlob(`picture.${(blob.type.split('/')[1] || 'png').replace('svg+xml', 'svg')}`, blob); } catch (e) { say('Could not save the picture'); } },
    };
  })();

  /* ---------- selection visuals ---------- */
  const selObj = tool === 'select' && selId ? (engine.preview && engine.preview.id === selId ? engine.preview.o : engine.objs.find((o) => o.id === selId)) : null;
  let selUi = null;
  if (selObj) {
    const b = R.bbox(selObj), k = UNIT, px = (v) => v * k;
    const line = selObj.t === 'shape' && R.isLineShape(selObj.kind);
    const dot = (x, y, bg, key, ch) => <span key={key} style={{ position: 'absolute', left: px(x) - 11, top: px(y) - 11, width: 22, height: 22, borderRadius: 11, background: bg, border: '2px solid #fff', boxShadow: '0 1px 4px rgba(0,0,0,.4)', color: '#fff', fontSize: 14, lineHeight: '18px', textAlign: 'center', fontWeight: 700 }}>{ch}</span>;
    const barTop = px(b.y + b.h) + 20, flip = barTop + 56 > totalH;
    selUi = (<>
      <div style={{ position: 'absolute', left: px(b.x), top: px(b.y), width: px(b.w), height: px(b.h), border: '2px dashed #0a84ff', borderRadius: 4, pointerEvents: 'none' }} className="ink-ui" />
      <div className="ink-ui" style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        {dot(b.x + b.w + 8, b.y - 8, '#ef4444', 'd', '×')}
        {dot(b.x + b.w, b.y + b.h, '#0a84ff', 'r', '')}
        {line && [[selObj.x1, selObj.y1], [selObj.x2, selObj.y2]].map((q, i) => dot(q[0], q[1], '#fff', `e${i}`, ''))}
      </div>
      <div data-inkui="1" className="ink-ui glass glass-menu" style={{ position: 'absolute', left: clamp(px(b.x), 4, W - (selObj.t === 'img' ? 350 : 190)), top: flip ? Math.max(4, px(b.y) - (selObj.t === 'img' ? 112 : 60)) : barTop, display: 'flex', flexWrap: 'wrap', maxWidth: selObj.t === 'img' ? 340 : 200, gap: 2, padding: 4, borderRadius: 16, pointerEvents: 'auto', zIndex: 5 }}>
        {selObj.t === 'img' && (<>
          {[25, 50, 75, 100].map((p) => <button key={p} type="button" title={`${p}% of the page width`} onClick={() => picture.size(p)} className="rbtn !min-h-[40px] !min-w-[44px] text-xs font-semibold">{p}%</button>)}
          <button type="button" title={selObj.lock === false ? 'Free resize (ratio unlocked)' : 'Lock aspect ratio'} onClick={picture.lock} className={`rbtn !min-h-[40px] !min-w-[40px] ${selObj.lock === false ? 'rbtn-on' : ''}`}>{selObj.lock === false ? <Unlock size={18} /> : <Lock size={18} />}</button>
          <button type="button" title="Reset the proportions" onClick={picture.reset} className="rbtn !min-h-[40px] !min-w-[40px]"><Undo2 size={18} /></button>
          <button type="button" title="Crop" onClick={() => setDlg('crop')} className="rbtn !min-h-[40px] !min-w-[40px]"><Crop size={18} /></button>
          <button type="button" title="Rotate left" onClick={() => picture.rotate(-90)} className="rbtn !min-h-[40px] !min-w-[40px]"><RotateCcw size={18} /></button>
          <button type="button" title="Rotate right" onClick={() => picture.rotate(90)} className="rbtn !min-h-[40px] !min-w-[40px]"><RotateCw size={18} /></button>
          <button type="button" title="Flip" onClick={picture.flip} className="rbtn !min-h-[40px] !min-w-[40px]"><FlipHorizontal2 size={18} /></button>
          <button type="button" title="Transparency" onClick={picture.opacity} className="rbtn !min-h-[40px] !min-w-[40px]"><Contrast size={18} /></button>
          <button type="button" title="Replace picture" onClick={picture.replace} className="rbtn !min-h-[40px] !min-w-[40px]"><RefreshCw size={18} /></button>
          <button type="button" title="Save picture" onClick={picture.download} className="rbtn !min-h-[40px] !min-w-[40px]"><Download size={18} /></button>
        </>)}
        {[[Copy, 'Duplicate', () => { const n = engine.dup(selId); if (n) setSelId(n.id); }], [ArrowUpToLine, 'Bring to front', () => engine.order(selId, true)], [ArrowDownToLine, 'Send to back', () => engine.order(selId, false)], [Trash2, 'Delete', () => { engine.remove([selId]); setSelId(null); }]].map(([I, t, fn]) => (
          <button key={t} type="button" title={t} aria-label={t} onClick={fn} className="rbtn !min-h-[40px] !min-w-[40px]"><I size={18} /></button>
        ))}
        {onPickColor && selObj.t !== 'img' && <label title="Colour" className="rbtn !min-h-[40px] !min-w-[40px] cursor-pointer"><span style={{ width: 20, height: 20, borderRadius: 10, background: selObj.color, border: '2px solid rgba(0,0,0,.25)', display: 'block' }} /><input type="color" value={selObj.color && selObj.color.length === 7 ? selObj.color : '#111827'} onChange={(e) => engine.update(selId, { color: e.target.value })} style={{ position: 'absolute', opacity: 0, width: 1, height: 1 }} /></label>}
      </div>
    </>);
  }

  const tl = [];
  for (let r = rng.r0; r <= rng.r1; r++) for (let c = rng.c0; c <= rng.c1; c++) {
    const x0 = c * T, y0 = r * T, w = Math.min(T, W - x0), h = Math.min(T, totalH - y0); if (w <= 0 || h <= 0) continue;
    tl.push({ r, c, x0, y0, w, h });
  }
  const box = { position: 'absolute', left: 0, top: 0, width: W, height: totalH, zIndex: 3, pointerEvents: 'none' };
  return (<>
    {/* highlighter layer: multiplied onto the text so the words stay readable (screen on dark pages) */}
    <div className="ink-layer-hl" style={{ ...box, mixBlendMode: hlBlend }}>
      {tl.map((t) => <Tile key={`h${t.r}:${t.c}:${sc}`} id={`h${t.r}:${t.c}`} kind="hl" engine={engine} x0={t.x0} y0={t.y0} w={t.w} h={t.h} sc={sc} reg={reg} eager={tool === 'highlighter' || tool === 'select'} />)}
      <canvas ref={liveHl} width={1} height={1} className="ink-ui" style={{ position: 'absolute', pointerEvents: 'none' }} />
    </div>
    <div ref={layer} className="ink-layer" data-ink-layer="1" style={{ ...box, pointerEvents: tool ? 'auto' : 'none', touchAction: tool ? 'none' : 'auto', cursor: tool ? 'crosshair' : 'auto' }}>
      {tl.map((t) => <Tile key={`b${t.r}:${t.c}:${sc}`} id={`b${t.r}:${t.c}`} kind="base" engine={engine} x0={t.x0} y0={t.y0} w={t.w} h={t.h} sc={sc} reg={reg} />)}
      <canvas ref={live} width={1} height={1} className="ink-ui" style={{ position: 'absolute', pointerEvents: 'none' }} />
      <canvas ref={liveTail} width={1} height={1} className="ink-ui" style={{ position: 'absolute', pointerEvents: 'none' }} />
      {selUi}
    </div>
    {dlg === 'crop' && selObj && selObj.t === 'img' && createPortal(<CropDialog src={selObj.src} onClose={() => setDlg(null)} onApply={(url) => { setDlg(null); picture.crop(url); }} />, document.body)}
    {tool === 'laser' && createPortal(<canvas ref={laserCv} className="ink-ui" style={{ position: 'fixed', left: 0, top: 0, width: '100vw', height: '100vh', pointerEvents: 'none', zIndex: 60 }} />, document.body)}
  </>);
}
