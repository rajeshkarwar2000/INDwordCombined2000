import { useEffect, useState } from 'react';

/**
 * A blinking text cursor drawn by the app. The browser's own caret can be too thin or hidden inside zoomed pages
 * (or when the page is scaled), so this one always shows at the exact position of the cursor, in the accent colour.
 * While it is shown the native caret is hidden (class on <html>); if it can't be placed the native one stays.
 */
export default function FakeCaret({ editor, enabled = true }) {
  const [r, setR] = useState(null);
  useEffect(() => {
    if (!editor) return undefined;
    let raf = 0;
    const upd = () => {
      raf = 0;
      try {
        const { state, view } = editor;
        if (!enabled || !editor.isEditable || !view.hasFocus() || !state.selection.empty) { setR(null); return; }
        const c = view.coordsAtPos(state.selection.head);
        const h = Math.max(12, c.bottom - c.top);
        if (!isFinite(c.left) || !isFinite(c.top)) { setR(null); return; }
        setR((p) => (p && Math.abs(p.x - c.left) < 0.3 && Math.abs(p.y - c.top) < 0.3 && Math.abs(p.h - h) < 0.3 ? p : { x: c.left, y: c.top, h }));
      } catch { setR(null); }
    };
    const q = () => { if (!raf) raf = requestAnimationFrame(upd); };
    editor.on('selectionUpdate', q); editor.on('transaction', q); editor.on('focus', q); editor.on('blur', () => setR(null));
    window.addEventListener('scroll', q, true); window.addEventListener('resize', q);
    const t = setInterval(q, 250); q();
    return () => {
      editor.off('selectionUpdate', q); editor.off('transaction', q); editor.off('focus', q);
      window.removeEventListener('scroll', q, true); window.removeEventListener('resize', q);
      clearInterval(t); cancelAnimationFrame(raf);
    };
  }, [editor, enabled]);
  useEffect(() => { document.documentElement.classList.toggle('fake-caret-on', !!r); return () => document.documentElement.classList.remove('fake-caret-on'); }, [r]);
  if (!r) return null;
  return <div key={`${Math.round(r.x)}:${Math.round(r.y)}`} className="fake-caret no-print" style={{ position: 'fixed', left: r.x - 1, top: r.y, width: 2.5, height: r.h, borderRadius: 1, background: 'var(--accent, #3b82f6)', zIndex: 35, pointerEvents: 'none' }} />;
}
