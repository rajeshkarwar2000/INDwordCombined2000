import { useEffect, useRef } from 'react';
import { flushSync } from 'react-dom';

const clamp = (z, min, max) => Math.min(max, Math.max(min, z));

/**
 * Fast two-finger pinch zoom (and Ctrl + mouse wheel) for a scrolling container.
 * While the fingers move, the page is scaled with a GPU transform: no re-layout, so it follows the fingers at full speed.
 * When the fingers lift, the real zoom is applied once and the scroll position is corrected so the pinched spot stays put.
 */
export default function usePinchZoom(ref, { zoom, setZoom, enabled = true, min = 0.25, max = 6, onLabel }) {
  const zoomRef = useRef(zoom);
  zoomRef.current = zoom;

  useEffect(() => {
    const el = ref.current;
    if (!el || !enabled) return undefined;
    let g = null;
    const target = () => el.firstElementChild;
    const dist = (t) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);

    const begin = (cx, cy, d) => {
      const r = el.getBoundingClientRect();
      const t = target(); if (!t) return;
      const w = el.querySelector('.zoomwrap'), wr = w ? w.getBoundingClientRect() : null;
      g = { d, z: zoomRef.current, cx: cx - r.left, cy: cy - r.top, ox: el.scrollLeft + cx - r.left, oy: el.scrollTop + cy - r.top, cur: zoomRef.current, raf: 0,
        w, px: cx, py: cy, mx: cx, my: cy, sx: cx, sy: cy, fx: wr ? (cx - wr.left) / Math.max(1, wr.width) : 0.5, fy: wr ? (cy - wr.top) / Math.max(1, wr.height) : 0.5 };
      t.style.transformOrigin = `${g.ox}px ${g.oy}px`;
      t.style.willChange = 'transform';
    };
    const paint = () => {
      if (!g) return;
      g.raf = 0;
      target().style.transform = `translate(${g.mx - g.sx}px, ${g.my - g.sy}px) scale(${g.cur / g.z})`; // two fingers: zoom and move the page together
      onLabel?.(Math.round(g.cur * 100));
    };
    const setCur = (z) => { if (!g) return; g.cur = z; if (!g.raf) g.raf = requestAnimationFrame(paint); };
    const finish = () => {
      if (!g) return;
      cancelAnimationFrame(g.raf);
      const g0 = g; const { cx, cy, ox, oy, z: z0 } = g;
      const gw = g.w, gfx = g.fx, gfy = g.fy, gpx = g.mx, gpy = g.my; // the pinched spot ends up under the fingers' current middle
      const z = Math.round(g.cur * 100) / 100;
      g = null;
      const t = target();
      flushSync(() => setZoom(z));                       // apply the real zoom immediately...
      if (t) { t.style.transform = ''; t.style.transformOrigin = ''; t.style.willChange = ''; }  // ...and drop the preview in the same frame
      const k = z / z0;
      if (gw) { // the page may be centred (narrower than the screen) so scroll maths from the corner drifts sideways: anchor on the page itself
        const nr = gw.getBoundingClientRect();
        el.scrollLeft += nr.left + gfx * nr.width - gpx;
        el.scrollTop += nr.top + gfy * nr.height - gpy;
      } else { el.scrollLeft = ox * k - cx - (g0.mx - g0.sx); el.scrollTop = oy * k - cy - (g0.my - g0.sy); }
      onLabel?.(null);
    };

    const onStart = (e) => {
      if (e.touches.length === 2) begin((e.touches[0].clientX + e.touches[1].clientX) / 2, (e.touches[0].clientY + e.touches[1].clientY) / 2, dist(e.touches));
    };
    const onMove = (e) => {
      if (!g || e.touches.length !== 2) return;
      e.preventDefault();
      g.mx = (e.touches[0].clientX + e.touches[1].clientX) / 2; g.my = (e.touches[0].clientY + e.touches[1].clientY) / 2;
      setCur(clamp((g.z * dist(e.touches)) / g.d, min, max));
    };
    const onEnd = (e) => { if (g && e.touches.length < 2) finish(); };

    let wheelTimer;
    const onWheel = (e) => {
      if (!e.ctrlKey) return;
      e.preventDefault();
      if (!g) begin(e.clientX, e.clientY, 1);
      setCur(clamp(g.cur * (e.deltaY < 0 ? 1.1 : 0.9), min, max));
      clearTimeout(wheelTimer);
      wheelTimer = setTimeout(finish, 220);
    };

    el.addEventListener('touchstart', onStart, { passive: true });
    el.addEventListener('touchmove', onMove, { passive: false });
    el.addEventListener('touchend', onEnd);
    el.addEventListener('touchcancel', onEnd);
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => {
      el.removeEventListener('touchstart', onStart);
      el.removeEventListener('touchmove', onMove);
      el.removeEventListener('touchend', onEnd);
      el.removeEventListener('touchcancel', onEnd);
      el.removeEventListener('wheel', onWheel);
      clearTimeout(wheelTimer);
      if (g) { cancelAnimationFrame(g.raf); const t = target(); if (t) { t.style.transform = ''; t.style.willChange = ''; } g = null; }
    };
  }, [ref, enabled, setZoom, min, max, onLabel]);
}
