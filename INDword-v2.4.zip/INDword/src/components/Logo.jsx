import logo from '../assets/logo.png';

/** INDword brand mark (the glass tile with the i-w pen mark). `tile` is kept for old callers; the picture already is the tile. */
export default function Logo({ size = 32, className = '' }) {
  return <img src={logo} width={size} height={size} alt="INDword logo" draggable={false} className={className} style={{ width: size, height: size, objectFit: 'contain' }} />;
}
