// PDF import. Two ways to open a PDF:
//   'text'  : the words become editable paragraphs, headings and bullet lists (headings found from the font size)
//   'pages' : every page becomes a picture, so you can write on it with the pen, highlighter and the other drawing tools
const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

async function openPdf(file) {
  const mod = await import('pdfjs-dist/build/pdf');
  const lib = mod.getDocument ? mod : mod.default;
  const worker = (await import('pdfjs-dist/build/pdf.worker.min.js?url')).default;
  lib.GlobalWorkerOptions.workerSrc = worker;
  const data = new Uint8Array(await file.arrayBuffer());
  return lib.getDocument({ data }).promise;
}

async function pageImages(doc, onProgress, width = 700) {
  const out = [];
  for (let i = 1; i <= doc.numPages; i++) {
    onProgress?.(i, doc.numPages);
    const page = await doc.getPage(i);
    const base = page.getViewport({ scale: 1 }), scale = Math.min(2.2, 1500 / base.width);
    const vp = page.getViewport({ scale }), c = document.createElement('canvas');
    c.width = Math.round(vp.width); c.height = Math.round(vp.height);
    const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
    await page.render({ canvasContext: ctx, viewport: vp }).promise;
    out.push(`<p><img src="${c.toDataURL('image/jpeg', 0.85)}" style="width:${width}px"></p>`);
    c.width = c.height = 0; page.cleanup();
  }
  return out.join('');
}

const BULLET = /^([•●▪■◦·‣○\-–—*]|\d{1,2}[.)]|[a-z][.)])\s+/;

async function pageLines(doc, onProgress) {
  const pages = [];
  for (let i = 1; i <= doc.numPages; i++) {
    onProgress?.(i, doc.numPages);
    const page = await doc.getPage(i), tc = await page.getTextContent();
    const its = tc.items.filter((t) => typeof t.str === 'string' && t.str.trim() !== '')
      .map((t) => ({ s: t.str, x: t.transform[4], y: t.transform[5], size: Math.hypot(t.transform[2], t.transform[3]) || t.height || 10, w: t.width || 0 }));
    its.sort((a, b) => b.y - a.y || a.x - b.x);
    const lines = [];
    for (const t of its) {
      const L = lines[lines.length - 1];
      if (L && Math.abs(L.y - t.y) <= 0.45 * Math.max(L.size, t.size)) { L.items.push(t); L.size = Math.max(L.size, t.size); }
      else lines.push({ y: t.y, size: t.size, items: [t] });
    }
    for (const L of lines) {
      L.items.sort((a, b) => a.x - b.x);
      let txt = '', end = null;
      for (const t of L.items) { if (end != null && t.x - end > t.size * 0.18 && !txt.endsWith(' ') && !t.s.startsWith(' ')) txt += ' '; txt += t.s; end = t.x + t.w; }
      L.text = txt.replace(/\s+/g, ' ').trim(); L.x = L.items[0].x; L.chars = L.text.length;
    }
    pages.push({ lines: lines.filter((l) => l.text), height: page.getViewport({ scale: 1 }).height });
    page.cleanup();
  }
  return pages;
}

function build(pages) {
  // running headers, footers and page numbers: repeated on many pages, or only digits
  const key = (t) => t.toLowerCase().replace(/\d+/g, '#').replace(/\s+/g, ' ');
  const seen = new Map();
  pages.forEach((p, pi) => { new Set(p.lines.filter((l, i) => i < 2 || i >= p.lines.length - 2).map((l) => key(l.text))).forEach((k) => seen.set(k, (seen.get(k) || 0) + 1)); });
  const junk = (l, p) => /^[\d\s\-–—.]*$/.test(l.text) && (l.y < p.height * 0.08 || l.y > p.height * 0.9) || (pages.length >= 3 && (seen.get(key(l.text)) || 0) >= Math.max(3, pages.length * 0.5) && (l.y < p.height * 0.1 || l.y > p.height * 0.88));
  // the usual (body) font size = the one carrying the most characters
  const weight = new Map();
  pages.forEach((p) => p.lines.forEach((l) => { const k = Math.round(l.size * 2) / 2; weight.set(k, (weight.get(k) || 0) + l.chars); }));
  const body = [...weight.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || 11;

  const blocks = []; let last = null;
  const push = (b) => { blocks.push(b); last = b; };
  pages.forEach((p) => {
    let prev = null;
    p.lines.forEach((l) => {
      if (junk(l, p)) return;
      const r = l.size / body, text = l.text, short = text.length < 130;
      const letters = text.replace(/[^A-Za-z]/g, '');
      let level = 0;
      if (short && r >= 1.55) level = 1; else if (short && r >= 1.3) level = 2; else if (short && r >= 1.12) level = 3;
      else if (short && letters.length >= 4 && text === text.toUpperCase() && text.length <= 80) level = 3;
      const gap = prev && !prev.page ? prev.y - l.y : 0;
      if (level) {
        if (last && last.h === level && prev && gap < l.size * 1.6) last.text += ` ${text}`; else push({ h: level, text });
      } else if (BULLET.test(text)) {
        push({ li: /^\d|^[a-z][.)]/.test(text) ? 'ol' : 'ul', text: text.replace(BULLET, '') });
      } else {
        const sameFlow = last && last.p && prev && Math.abs(prev.size - l.size) / l.size < 0.15 && gap > 0 && gap <= l.size * 1.75;
        const newPageFlow = last && last.p && !prev && !/[.!?:;"”)]$/.test(last.text) && /^[a-z(]/.test(text);
        const listCont = last && last.li && prev && gap > 0 && gap <= l.size * 1.6 && l.x > prev.x - 2 && !BULLET.test(text);
        if (listCont) last.text += ` ${text}`;
        else if (sameFlow || newPageFlow) last.text = last.text.endsWith('-') && /^[a-z]/.test(text) ? last.text.slice(0, -1) + text : `${last.text} ${text}`;
        else push({ p: 1, text });
      }
      prev = { y: l.y, size: l.size, x: l.x };
    });
  });
  let html = '', list = null;
  const closeList = () => { if (list) { html += `</${list}>`; list = null; } };
  for (const b of blocks) {
    if (b.li) { if (list !== b.li) { closeList(); html += `<${b.li}>`; list = b.li; } html += `<li><p>${esc(b.text)}</p></li>`; continue; }
    closeList();
    html += b.h ? `<h${b.h}>${esc(b.text)}</h${b.h}>` : `<p>${esc(b.text)}</p>`;
  }
  closeList();
  return { html, chars: blocks.reduce((n, b) => n + b.text.length, 0) };
}

/** mode: 'text' | 'pages'. Returns { name, ext, html, notes } like importFile() */
export async function importPdf(file, mode = 'text', onProgress) {
  const name = file.name.replace(/\.[^.]+$/, '') || 'Imported PDF';
  const doc = await openPdf(file), notes = [];
  if (doc.numPages > 150 && mode === 'pages') notes.push('This PDF is long: page pictures make a large document.');
  if (mode === 'text') {
    const r = build(await pageLines(doc, onProgress));
    if (r.chars >= 40) {
      notes.push('Text, headings and lists were recovered from the PDF. Check tables and columns, then use "Page pictures" if you want the exact look.');
      return { name, ext: 'indword', html: r.html || '<p></p>', notes };
    }
    notes.push('This PDF has no text (it is a scan), so its pages were added as pictures.');
  }
  return { name, ext: 'indword', html: await pageImages(doc, onProgress), notes };
}
