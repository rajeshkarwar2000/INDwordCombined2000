// Opens a PDF as an editable document: text, headings, lists and paragraphs are rebuilt from the page layout.
// Pages without selectable text (scans) are inserted as pictures instead.
const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const BULLET = /^[•◦▪▫●○■□‣⁃·–—-]\s+/;
const NUM = /^(\(?\d{1,3}[.)]|\(?[a-zA-Z][.)])\s+/;

/**
 * items: pdf.js text items { str, transform:[a,b,c,d,x,y], width, height }. Returns an array of HTML blocks for one page.
 * Exported separately so the layout rules can be tested without pdf.js.
 */
export function layoutPage(items, pageW, bodySize) {
  const segs = [];
  for (const it of items) {
    if (!it.str || !it.str.trim()) { continue; }
    const fs = Math.hypot(it.transform[0], it.transform[1]) || it.height || 10;
    segs.push({ s: it.str, x: it.transform[4], x1: it.transform[4] + (it.width || it.str.length * fs * 0.5), y: it.transform[5], fs });
  }
  if (!segs.length) return [];
  // 1. group into lines (same baseline), splitting a line where there is a wide gap (columns, tables)
  segs.sort((a, b) => b.y - a.y || a.x - b.x);
  const rows = [];
  for (const g of segs) {
    const r = rows.find((q) => Math.abs(q.y - g.y) < Math.max(2, Math.min(q.fs, g.fs) * 0.45));
    if (r) r.items.push(g); else rows.push({ y: g.y, fs: g.fs, items: [g] });
  }
  rows.sort((a, b) => b.y - a.y);
  const lines = [];
  for (const r of rows) {
    r.items.sort((a, b) => a.x - b.x);
    let cur = null;
    for (const g of r.items) {
      if (cur && g.x - cur.x1 > Math.max(g.fs, cur.fs) * 2.6 && g.x - cur.x1 > 24) { lines.push(cur); cur = null; }
      if (!cur) cur = { y: r.y, x: g.x, x1: g.x1, fs: g.fs, s: g.s };
      else { const gap = g.x - cur.x1; cur.s += (gap > g.fs * 0.15 && !cur.s.endsWith(' ') && !g.s.startsWith(' ') ? ' ' : '') + g.s; cur.x1 = Math.max(cur.x1, g.x1); cur.fs = Math.max(cur.fs, g.fs); }
    }
    if (cur) lines.push(cur);
  }
  // 2. two columns? look for an empty vertical strip near the middle that (almost) no line crosses
  let order = lines;
  const mid0 = pageW * 0.35, mid1 = pageW * 0.65;
  if (lines.length > 12) {
    let gutter = null;
    for (let x = mid0; x <= mid1 && !gutter; x += pageW * 0.01) {
      const cross = lines.filter((l) => l.x < x - 4 && l.x1 > x + 4).length;
      const left = lines.filter((l) => l.x1 <= x + 4).length, right = lines.filter((l) => l.x >= x - 4).length;
      if (cross <= lines.length * 0.12 && left > lines.length * 0.3 && right > lines.length * 0.3) gutter = x;
    }
    if (gutter) {
      const wide = lines.filter((l) => l.x < gutter - 4 && l.x1 > gutter + 4).sort((a, b) => b.y - a.y);
      const out = []; let top = Infinity;
      const flush = (bottom) => {
        const region = lines.filter((l) => l.y < top && l.y > bottom && !wide.includes(l));
        out.push(...region.filter((l) => l.x1 <= gutter + 4).sort((a, b) => b.y - a.y), ...region.filter((l) => l.x1 > gutter + 4).sort((a, b) => b.y - a.y));
      };
      for (const w of wide) { flush(w.y); out.push(w); top = w.y; }
      flush(-Infinity);
      order = out;
    }
  }
  // 3. lines -> blocks
  const blocks = []; let para = null, list = null, prev = null;
  const endPara = () => { if (para) { blocks.push(`<p>${esc(para.join(' '))}</p>`); para = null; } };
  const endList = () => { if (list) { blocks.push(`<${list.tag}>${list.items.map((t) => `<li><p>${esc(t)}</p></li>`).join('')}</${list.tag}>`); list = null; } };
  const left0 = Math.min(...order.map((l) => l.x));
  for (const l of order) {
    const text = l.s.trim(); if (!text) continue;
    const ratio = l.fs / bodySize;
    const gap = prev && prev.col === (l.x < pageW / 2) ? prev.y - l.y : 0;
    const newBlock = !prev || gap > Math.max(l.fs, prev.fs) * 1.65 || gap < 0;
    if (ratio >= 1.2 && text.length < 140) { // heading
      endPara(); endList();
      const tag = ratio >= 1.8 ? 'h1' : ratio >= 1.45 ? 'h2' : 'h3';
      const last = blocks[blocks.length - 1];
      if (last && last.startsWith(`<${tag}>`) && prev && prev.head && gap < l.fs * 1.6) blocks[blocks.length - 1] = last.replace(/<\/h\d>$/, ` ${esc(text)}</${tag}>`);
      else blocks.push(`<${tag}>${esc(text)}</${tag}>`);
      prev = { y: l.y, fs: l.fs, col: l.x < pageW / 2, head: true }; continue;
    }
    let m;
    if ((m = BULLET.exec(text)) || (NUM.exec(text) && /^\(?\d/.test(text))) {
      endPara();
      const tag = m ? 'ul' : 'ol';
      if (list && list.tag !== tag) endList();
      if (!list) list = { tag, items: [] };
      list.items.push(text.replace(m ? BULLET : NUM, '')); prev = { y: l.y, fs: l.fs, col: l.x < pageW / 2, li: true }; continue;
    }
    if (list && !newBlock && l.x > left0 + 4 && prev && prev.li) { list.items[list.items.length - 1] += ` ${text}`; prev = { y: l.y, fs: l.fs, col: l.x < pageW / 2, li: true }; continue; }
    endList();
    if (!para || newBlock || (prev && prev.head)) { endPara(); para = [text]; }
    else if (para[para.length - 1].endsWith('-') && /^[a-z]/.test(text)) para[para.length - 1] = para[para.length - 1].slice(0, -1) + text; // re-join a hyphenated word
    else para.push(text);
    prev = { y: l.y, fs: l.fs, col: l.x < pageW / 2 };
  }
  endPara(); endList();
  return blocks;
}

const mostCommonSize = (sizes) => {
  const m = new Map(); for (const [fs, n] of sizes) { const k = Math.round(fs * 2) / 2; m.set(k, (m.get(k) || 0) + n); }
  let best = 11, bn = 0; for (const [k, n] of m) if (n > bn) { best = k; bn = n; }
  return best;
};

async function openPdf(buffer) {
  const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const worker = (await import('pdfjs-dist/legacy/build/pdf.worker.min.mjs?url')).default;
  pdfjs.GlobalWorkerOptions.workerSrc = worker;
  try { return await pdfjs.getDocument({ data: new Uint8Array(buffer), useSystemFonts: true }).promise; }
  catch (e) {
    if (e && e.name === 'PasswordException') throw new Error('This PDF is password protected. Remove the password and try again.');
    throw new Error('This PDF could not be read. It may be damaged.');
  }
}

const STD = { A4: [794, 1123], Letter: [816, 1056], Legal: [816, 1344], Executive: [696, 1008] };

/**
 * Opens a PDF exactly as it is: every page becomes one full page of the document (picture of the page, same size, page breaks kept),
 * so the original is never reflowed and anything added later (typing, drawings) goes after or on top of the real pages.
 */
export async function pdfToPages(buffer, onProgress) {
  const doc = await openPdf(buffer);
  const MAXP = 200, n = Math.min(doc.numPages, MAXP), notes = [];
  if (doc.numPages > MAXP) notes.push(`Only the first ${MAXP} of ${doc.numPages} pages were imported.`);
  const first = await doc.getPage(1), v1 = first.getViewport({ scale: 1 });
  const wpx = (v1.width * 96) / 72, hpx = (v1.height * 96) / 72, land = wpx > hpx, pw = Math.min(wpx, hpx), ph = Math.max(wpx, hpx);
  let size = null;
  for (const [k, [sw, sh]] of Object.entries(STD)) if (Math.abs(sw - pw) / sw < 0.02 && Math.abs(sh - ph) / sh < 0.02) size = k;
  const [W0, H0] = size ? STD[size] : [Math.round(pw), Math.round(ph)];
  if (!size) size = `${W0}x${H0}`;
  const W = land ? H0 : W0, H = land ? W0 : H0;
  const parts = [];
  const target = Math.min(1500, Math.max(1100, W * 1.6)); // pixels across: sharp when zoomed in, light enough to keep the document fast
  for (let i = 1; i <= n; i += 1) {
    onProgress?.(i, n);
    const page = i === 1 ? first : await doc.getPage(i);
    const vp = page.getViewport({ scale: target / page.getViewport({ scale: 1 }).width });
    const c = document.createElement('canvas'); c.width = Math.round(vp.width); c.height = Math.round(vp.height);
    const cx = c.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, c.width, c.height);
    await page.render({ canvasContext: cx, viewport: vp }).promise;
    const url = c.toDataURL('image/jpeg', 0.84);
    c.width = c.height = 0; page.cleanup();
    parts.push(`<p><img src="${url}" data-free="1" style="width:${W}px;height:${H}px"></p>`);
  }
  parts.push('<p></p>'); // your own content starts here, on the page after the PDF
  notes.push('The PDF was opened exactly as it is. Type or draw on it, and add new pages after the last one.');
  try { await doc.destroy(); } catch { /* ignore */ }
  return { html: parts.join(''), notes, meta: { paged: true, size, orientation: land ? 'landscape' : 'portrait', header: '', footer: '', pageNumbers: false } };
}

export async function pdfToHtml(buffer, onProgress) {
  const doc = await openPdf(buffer);
  const notes = [], pages = [];
  const MAXP = 300;
  const n = Math.min(doc.numPages, MAXP);
  if (doc.numPages > MAXP) notes.push(`Only the first ${MAXP} of ${doc.numPages} pages were imported.`);
  const sizes = [];
  for (let i = 1; i <= n; i += 1) {
    onProgress?.(i, n);
    const page = await doc.getPage(i);
    const vp = page.getViewport({ scale: 1 });
    const tc = await page.getTextContent();
    const items = tc.items.filter((it) => typeof it.str === 'string');
    for (const it of items) if (it.str.trim()) sizes.push([Math.hypot(it.transform[0], it.transform[1]), it.str.length]);
    pages.push({ page, items, w: vp.width, chars: items.reduce((a, it) => a + it.str.trim().length, 0) });
  }
  const body = mostCommonSize(sizes);
  const parts = []; let scanned = 0;
  for (let i = 0; i < pages.length; i += 1) {
    const p = pages[i];
    let blocks;
    if (p.chars >= 15) blocks = layoutPage(p.items, p.w, body);
    else { // no text: a scan or a drawing, so keep the page as a picture
      scanned += 1;
      const vp = p.page.getViewport({ scale: 1.6 }), c = document.createElement('canvas'); c.width = Math.round(vp.width); c.height = Math.round(vp.height);
      const cx = c.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, c.width, c.height);
      await p.page.render({ canvasContext: cx, viewport: vp }).promise;
      blocks = [`<p><img src="${c.toDataURL('image/jpeg', 0.82)}" width="640"></p>`];
    }
    if (i > 0) parts.push('<div data-page-break></div>');
    parts.push(...blocks);
    p.page.cleanup();
  }
  if (scanned) notes.push(`${scanned} page${scanned > 1 ? 's' : ''} had no selectable text (scanned), so ${scanned > 1 ? 'they were' : 'it was'} added as picture${scanned > 1 ? 's' : ''}.`);
  notes.push('PDF text was rebuilt as editable paragraphs, headings and lists. Pictures, fonts and exact positions in the original are not kept.');
  try { await doc.destroy(); } catch { /* ignore */ }
  return { html: parts.join('') || '<p></p>', notes };
}
