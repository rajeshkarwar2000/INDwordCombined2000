/**
 * Renders notes pages with the browser's own layout engine (SVG foreignObject -> canvas).
 * Unlike html2canvas this keeps wrapped highlights, heading boxes and fonts exactly as on screen.
 */
const blobToDataUrl = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(blob); });

async function collectCss(stage) {
  const used = new Set();
  [stage, ...stage.querySelectorAll('*')].forEach((el) => { getComputedStyle(el).fontFamily.split(',').forEach((f) => used.add(f.trim().replace(/^["']|["']$/g, '').toLowerCase())); });
  let css = '';
  const jobs = [];
  Array.from(document.styleSheets).forEach((ss) => {
    let rules; try { rules = Array.from(ss.cssRules); } catch { return; }
    rules.forEach((r) => {
      if (r instanceof CSSFontFaceRule) {
        const fam = r.style.getPropertyValue('font-family').trim().replace(/^["']|["']$/g, '').toLowerCase();
        const range = r.style.getPropertyValue('unicode-range');
        if (!used.has(fam) || (range && !/U\+0000-00FF/i.test(range))) return;
        let text = r.cssText;
        const urls = [...text.matchAll(/url\(["']?([^"')]+)["']?\)/g)];
        jobs.push((async () => {
          for (const m of urls) {
            try { const res = await fetch(new URL(m[1], ss.href || document.baseURI)); text = text.replace(m[0], `url(${await blobToDataUrl(await res.blob())})`); } catch { /* keep url */ }
          }
          css += `${text}\n`;
        })());
      } else css += `${r.cssText}\n`;
    });
  });
  await Promise.all(jobs);
  return css.replace(/\]\]>/g, ']]&gt;');
}

const loadSvg = (svg) => new Promise((res, rej) => {
  const img = new Image(); img.onload = () => res(img); img.onerror = () => rej(new Error('Page render failed'));
  img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
});

/** returns an array of JPEG data URLs, one per page */
export async function stageToJpegs(stage, { W, H, GAP, n, scale = 2, onProgress, overlay, signal, bg = '#fff' }) {
  const css = await collectCss(stage);
  const clone = stage.cloneNode(true);
  clone.classList.add('exporting');
  clone.querySelectorAll('.ink-layer, .ink-layer-hl').forEach((el) => el.remove()); // the ink is drawn onto each page bitmap below
  // Each page is rendered from only the blocks that sit on it (a long imported PDF would otherwise repeat every page picture for every page).
  const ser = new XMLSerializer();
  const origKids = [...(stage.querySelector('.ProseMirror')?.children || [])], pm = clone.querySelector('.ProseMirror');
  const pcards = [...clone.querySelectorAll('.pcard')].map((el) => ser.serializeToString(el));
  let blocks = [];
  if (pm) {
    const kids = [...pm.children];
    blocks = kids.map((el, k) => {
      const top = parseFloat(el.style.top), hidden = el.style.display === 'none';
      return { top: Number.isFinite(top) ? top : null, h: Math.max(origKids[k]?.offsetHeight || 0, el.querySelector('img') ? H : 0), hidden, html: ser.serializeToString(el) };
    });
    kids.forEach((el) => el.remove());
    pm.appendChild(document.createTextNode('@@BLOCKS@@'));
  }
  const first = clone.querySelector('.pcard');
  if (first) { clone.querySelectorAll('.pcard').forEach((el) => el.remove()); clone.insertBefore(document.createTextNode('@@PCARDS@@'), clone.firstChild); }
  const shell = ser.serializeToString(clone);
  const pageHtml = (i) => {
    const y0 = i * (H + GAP), y1 = y0 + H + GAP;
    const mine = blocks.filter((b) => !b.hidden && (b.top == null || (b.top < y1 && b.top + Math.max(b.h, 1) > y0 - 2))).map((b) => b.html).join('');
    return shell.replace('@@PCARDS@@', () => pcards[i] || '').replace('@@BLOCKS@@', () => mine);
  };
  const out = [];
  for (let i = 0; i < n; i += 1) {
    if (signal?.aborted) throw Object.assign(new Error('Cancelled'), { name: 'AbortError' });
    onProgress?.(i + 1, n);
    const html = pageHtml(i);
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}"><foreignObject x="0" y="0" width="${W}" height="${H}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${W}px;height:${H}px;overflow:hidden;position:relative;background:${bg}"><style><![CDATA[${css}]]></style><div style="position:absolute;left:0;top:${-i * (H + GAP)}px;width:${W}px">${html}</div></div></foreignObject></svg>`;
    const img = await loadSvg(svg);
    const c = document.createElement('canvas'); c.width = W * scale; c.height = H * scale;
    const x = c.getContext('2d'); x.fillStyle = bg; x.fillRect(0, 0, c.width, c.height); x.imageSmoothingQuality = 'high'; x.drawImage(img, 0, 0, c.width, c.height);
    overlay?.(x, i);
    out.push(c.toDataURL('image/jpeg', 0.98)); c.width = c.height = 0;
  }
  return out;
}
