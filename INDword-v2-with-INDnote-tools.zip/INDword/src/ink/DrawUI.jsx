import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Pen, Paintbrush, Highlighter, Crosshair, Eraser, MousePointer2, Shapes, Undo2, Redo2, Hand, Type, Trash2, Check, Plus, Pencil, Fingerprint, X } from 'lucide-react';
import R from './render.js';
import { LASER_COLORS } from './engine.js';
import { Btn, Group } from '../ribbon/ui.jsx';

export const TOOLS = [
  ['pen', 'Pen', Pen], ['brush', 'Brush', Paintbrush], ['highlighter', 'Highlighter', Highlighter], ['laser', 'Laser', Crosshair],
  ['eraser', 'Eraser', Eraser], ['select', 'Select', MousePointer2], ['shapes', 'Shapes', Shapes],
];
const toolMeta = Object.fromEntries(TOOLS.map(([id, label, Icon]) => [id, { label, Icon }]));
const hasColor = (t) => ['pen', 'brush', 'highlighter', 'laser', 'shapes'].includes(t);

/* ------------------------------------------------------------------ small controls */
const Title = ({ children }) => <div className="px-1 pb-1 pt-2 text-[11px] font-semibold uppercase tracking-wide opacity-55">{children}</div>;

function Slider({ label, min, max, step = 1, value, onChange, fmt }) {
  return (
    <label className="block px-1">
      <div className="flex justify-between text-sm"><span>{label}</span><span className="tabular-nums opacity-70">{fmt ? fmt(value) : value}</span></div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="h-8 w-full" style={{ accentColor: '#3b82f6' }} />
    </label>
  );
}
function Segment({ options, value, onChange }) {
  return (
    <div className="flex gap-1 rounded-2xl bg-black/5 p-1 dark:bg-white/10">
      {options.map(([k, l]) => <button key={k} type="button" onClick={() => onChange(k)} className={`min-h-[38px] flex-1 rounded-xl text-sm font-medium ${value === k ? 'bg-white shadow dark:bg-zinc-700' : ''}`}>{l}</button>)}
    </div>
  );
}
function Toggle({ label, value, onChange }) {
  return (
    <button type="button" onClick={() => onChange(!value)} className="flex min-h-[40px] w-full items-center justify-between rounded-xl px-1 text-sm">
      <span>{label}</span>
      <span className={`flex h-6 w-11 items-center rounded-full p-0.5 transition ${value ? 'bg-blue-500' : 'bg-black/20 dark:bg-white/25'}`}><span className={`h-5 w-5 rounded-full bg-white shadow transition ${value ? 'translate-x-5' : ''}`} /></span>
    </button>
  );
}
function OptGrid({ items, value, onChange, cols = 3 }) {
  return (
    <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${cols},1fr)` }}>
      {items.map(([k, l, node]) => (
        <button key={k} type="button" title={l} onClick={() => onChange(k)} className={`flex min-h-[52px] flex-col items-center justify-center gap-1 rounded-2xl border px-1 py-1.5 text-xs ${value === k ? 'border-blue-500 bg-blue-500/15' : 'border-black/10 dark:border-white/15'}`}>
          {node}{l && <span>{l}</span>}
        </button>
      ))}
    </div>
  );
}

function Canvas({ w, h, draw, deps }) {
  const ref = useRef(null);
  useEffect(() => {
    const c = ref.current; if (!c) return;
    const d = Math.min(window.devicePixelRatio || 1, 2); c.width = w * d; c.height = h * d;
    const x = c.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0); x.clearRect(0, 0, w, h); draw(x, w, h);
  }, deps); // eslint-disable-line react-hooks/exhaustive-deps
  return <canvas ref={ref} style={{ width: w, height: h }} />;
}
const wave = (w, h, n = 24) => Array.from({ length: n + 1 }, (_, i) => { const t = i / n; return [8 + t * (w - 16), h / 2 + Math.sin(t * Math.PI * 2) * h * 0.28, 0.5]; });
const ShapePrev = ({ kind }) => <Canvas w={34} h={34} deps={[kind]} draw={(x) => R.drawObj(x, { t: 'shape', kind, x1: 5, y1: 7, x2: 29, y2: 27, color: '#6b7280', bw: 2, fill: false })} />;

/* ------------------------------------------------------------------ colour list: swatches, colour wheel, add / remove */
function ColorRow({ value, onChange, list, onList, fixed }) {
  const [edit, setEdit] = useState(false);
  const has = list.some((c) => c.toLowerCase() === (value || '').toLowerCase());
  return (
    <div>
      <div className="flex flex-wrap items-center gap-2">
        {list.map((c) => (
          <button key={c} type="button" aria-label={c} onClick={() => (edit && !fixed ? onList(list.filter((x) => x !== c)) : onChange(c))}
            className={`relative h-9 w-9 rounded-full border border-black/15 active:scale-90 ${value && value.toLowerCase() === c.toLowerCase() && !edit ? 'ring-2 ring-blue-500 ring-offset-2 ring-offset-transparent' : ''}`} style={{ background: c }}>
            {edit && !fixed && <span className="absolute inset-0 grid place-items-center rounded-full bg-black/45 text-white"><X size={16} /></span>}
          </button>
        ))}
        <label title="Colour wheel" className="relative grid h-9 w-9 cursor-pointer place-items-center rounded-full border border-black/15" style={{ background: 'conic-gradient(red,yellow,lime,aqua,blue,magenta,red)' }}>
          <input type="color" value={/^#[0-9a-f]{6}$/i.test(value || '') ? value : '#111827'} onChange={(e) => onChange(e.target.value)} className="absolute inset-0 h-full w-full cursor-pointer opacity-0" />
        </label>
        {!fixed && <>
          <button type="button" title="Add this colour to the list" disabled={has || !value} onClick={() => onList([...list, value])} className="grid h-9 w-9 place-items-center rounded-full border border-dashed border-black/30 disabled:opacity-30 dark:border-white/40"><Plus size={16} /></button>
          <button type="button" title={edit ? 'Done' : 'Remove colours'} onClick={() => setEdit(!edit)} className={`grid h-9 w-9 place-items-center rounded-full ${edit ? 'bg-blue-500 text-white' : 'border border-black/15'}`}>{edit ? <Check size={16} /> : <Pencil size={14} />}</button>
        </>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ option panels */
export function ToolOptions({ tool, ink, confirm, flash, pageInfo }) {
  const { cfg, setCfg, setPref, engine } = ink;
  const c = cfg[tool]; const set = (p) => setCfg(tool, p);
  if (!c && tool !== 'select') return null;
  const colorList = tool === 'highlighter' ? ink.hlPalette : tool === 'laser' ? LASER_COLORS : ink.palette;
  const setList = (l) => setPref(tool === 'highlighter' ? { hlPalette: l } : { palette: l });
  const color = hasColor(tool) && (
    <><Title>Colour</Title><ColorRow value={c.color} onChange={(v) => set({ color: v })} list={colorList} onList={setList} fixed={tool === 'laser'} /></>
  );

  if (tool === 'pen') return (
    <div className="space-y-2">
      <Title>Pen</Title>
      <OptGrid value={c.pen === 'fountain' ? 'calligraphy' : c.pen} onChange={(v) => set({ pen: v })} items={[
        ['ball', 'Ball', <Canvas key="a" w={56} h={22} deps={[]} draw={(x, w, h) => R.drawStroke(x, { t: 's', tool: 'pen', pen: 'ball', color: '#6b7280', size: 3, pts: wave(w, h) }, 0, null, true)} />],
        ['natural', 'Natural', <Canvas key="b" w={56} h={22} deps={[]} draw={(x, w, h) => R.drawStroke(x, { t: 's', tool: 'pen', pen: 'natural', color: '#6b7280', size: 4, pts: wave(w, h).map((p, i, a) => [p[0], p[1], 0.25 + 0.7 * Math.sin((i / a.length) * Math.PI)]) }, 0, null, true)} />],
        ['calligraphy', 'Calligraphy', <Canvas key="c" w={56} h={22} deps={[]} draw={(x, w, h) => R.drawStroke(x, { t: 's', tool: 'pen', pen: 'calligraphy', nib: 'chisel', angle: 40, color: '#6b7280', size: 5, pts: wave(w, h) }, 0, null, true)} />]]} />
      <Slider label="Thickness" min={1} max={40} value={c.size} onChange={(v) => set({ size: v })} fmt={(v) => `${v} px`} />
      <Title>Line style</Title>
      <Segment value={c.line} onChange={(v) => set({ line: v })} options={[['solid', 'Solid'], ['dotted', 'Dotted'], ['dashdot', 'Dash']]} />
      {c.line !== 'solid' && <Slider label="Spacing" min={2} max={40} value={c.space} onChange={(v) => set({ space: v })} fmt={(v) => `${v} px`} />}
      {c.line === 'solid' && (c.pen === 'calligraphy' || c.pen === 'fountain') && (<>
        <Title>Calligraphy nib</Title>
        <Segment value={c.nib} onChange={(v) => set({ nib: v })} options={[['chisel', 'Broad nib'], ['pointed', 'Pointed']]} />
        {c.nib === 'chisel' && <Slider label="Nib angle" min={0} max={90} value={c.angle} onChange={(v) => set({ angle: v })} fmt={(v) => `${v}°`} />}
      </>)}
      {color}
    </div>
  );

  if (tool === 'brush') return (
    <div className="space-y-2">
      <Title>Brush</Title>
      <OptGrid cols={3} value={c.brush} onChange={(v) => set({ brush: v })} items={[['pencil', 'Pencil'], ['oil', 'Oil'], ['spill', 'Spill'], ['watercolor', 'Watercolor'], ['crayon', 'Crayon']].map(([k, l]) => [k, l,
        <Canvas key={k} w={56} h={22} deps={[c.color]} draw={(x, w, h) => R.drawStroke(x, { t: 's', tool: 'brush', brush: k, color: c.color, size: 12, seed: 7, pts: wave(w, h) }, 0, null, false)} />])} />
      <Slider label="Size" min={4} max={90} value={c.size} onChange={(v) => set({ size: v })} fmt={(v) => `${v} px`} />
      {color}
    </div>
  );

  if (tool === 'highlighter') return (
    <div className="space-y-2">
      <Title>Highlighter</Title>
      <OptGrid value={c.tip || 'round'} onChange={(v) => set({ tip: v })} items={[['round', 'Round'], ['flat', 'Flat nib'], ['square', 'Square']].map(([k, l]) => [k, l,
        <Canvas key={k} w={56} h={26} deps={[k]} draw={(x) => R.drawStroke(x, { t: 's', tool: 'hl', tip: k, color: '#facc15', size: 14, alpha: 0.7, pts: [[10, 18, 0.5], [24, 8, 0.5], [38, 18, 0.5], [48, 8, 0.5]] }, 0, null, true)} />])} />
      <Toggle label="Straight line" value={!!c.straight} onChange={(v) => set({ straight: v })} />
      <Slider label="Thickness" min={8} max={80} value={c.size} onChange={(v) => set({ size: v })} fmt={(v) => `${v} px`} />
      <Slider label="Opacity" min={15} max={90} value={Math.round(c.alpha * 100)} onChange={(v) => set({ alpha: v / 100 })} fmt={(v) => `${v}%`} />
      {color}
      <p className="px-1 text-xs opacity-60">Highlights sit on top of the text and stay readable. They are drawn over the page, so they stay where you put them if the text changes.</p>
    </div>
  );

  if (tool === 'laser') return (
    <div className="space-y-2">
      <Title>Laser pointer</Title>
      <div className="overflow-hidden rounded-2xl bg-black/5 dark:bg-white/10">
        <Canvas w={290} h={70} deps={[c.mode, c.color, c.size]} draw={(x, w, h) => {
          const pts = Array.from({ length: 41 }, (_, i) => { const t = i / 40; return { x: 30 + t * (w - 60), y: h / 2 + Math.sin(t * Math.PI * 2) * 22 }; });
          const sz = c.size * 0.8, hd = { x: pts[40].x, y: pts[40].y, a: 1 };
          if (c.mode === 'dot') R.drawLaser(x, [], null, c.color, sz, { head: { x: pts[26].x, y: pts[26].y, a: 1 } });
          else if (c.mode === 'line') R.drawLaser(x, pts, pts.map((_, i) => Math.pow(i / 40, 1.25)), c.color, sz, { taper: true, head: hd });
          else R.drawLaser(x, pts, null, c.color, sz, { head: hd });
        }} />
      </div>
      <Segment value={c.mode} onChange={(v) => set({ mode: v })} options={[['dot', 'Dot'], ['line', 'Trail'], ['delay', 'Hold']]} />
      {c.mode === 'line' && <Slider label="Trail length" min={300} max={2500} step={50} value={c.trail || 650} onChange={(v) => set({ trail: v })} fmt={(v) => `${(v / 1000).toFixed(2)} s`} />}
      {c.mode === 'delay' && <Slider label="Hold time" min={1} max={5} value={c.delay} onChange={(v) => set({ delay: v })} fmt={(v) => `${v} s`} />}
      <Slider label="Size" min={3} max={30} value={c.size} onChange={(v) => set({ size: v })} fmt={(v) => `${v} px`} />
      {color}
      <p className="px-1 text-xs opacity-60">Laser marks fade away by themselves and are never saved in the document.</p>
    </div>
  );

  if (tool === 'eraser') return (
    <div className="space-y-2">
      <Title>Eraser</Title>
      <Segment value={c.mode} onChange={(v) => set({ mode: v })} options={[['stroke', 'Whole stroke'], ['pixel', 'Part of stroke']]} />
      <Slider label="Eraser size" min={8} max={120} value={c.size} onChange={(v) => set({ size: v })} fmt={(v) => `${v} px`} />
      <div className="flex gap-2 pt-1">
        <button type="button" className="rbtn !flex-1 !flex-row gap-2 !text-red-600" onClick={() => pageInfo ? (engine.clearPage(pageInfo.page - 1, pageInfo.pitch, pageInfo.H), flash?.('Ink on this page cleared')) : null}><Trash2 size={16} />Clear page</button>
        <button type="button" className="rbtn !flex-1 !flex-row gap-2 !text-red-600" onClick={() => confirm?.('Clear all ink?', 'Every pen, brush, highlighter and shape drawing in this document will be removed. You can undo this.', () => { engine.clearAll(); flash?.('All ink cleared'); })}><Trash2 size={16} />Clear all</button>
      </div>
    </div>
  );

  if (tool === 'shapes') return (
    <div className="space-y-2">
      <Title>Shape</Title>
      <OptGrid cols={6} value={c.kind} onChange={(v) => set({ kind: v })} items={R.SHAPES.map(([k, l]) => [k, '', <ShapePrev key={k} kind={k} />])} />
      <Slider label="Border width" min={1} max={24} value={c.bw} onChange={(v) => set({ bw: v })} fmt={(v) => `${v} px`} />
      <Title>Line style</Title>
      <Segment value={c.dash || 'solid'} onChange={(v) => set({ dash: v })} options={[['solid', 'Solid'], ['dashed', 'Dashed'], ['dotted', 'Dotted']]} />
      <Slider label="Opacity" min={10} max={100} value={Math.round((c.op == null ? 1 : c.op) * 100)} onChange={(v) => set({ op: v / 100 })} fmt={(v) => `${v}%`} />
      <Toggle label="Fill shape" value={!!c.fill} onChange={(v) => set({ fill: v })} />
      {c.fill && (<><Title>Fill colour</Title><ColorRow value={c.fillColor || c.color} onChange={(v) => set({ fillColor: v })} list={ink.palette} onList={setList} /></>)}
      {color}
      <p className="px-1 text-xs opacity-60">Drag to draw, or tap to place a shape. Lines snap to straight angles. The tool stays on.</p>
    </div>
  );

  if (tool === 'select') return (
    <div className="space-y-2 text-sm">
      <Title>Select</Title>
      <p className="px-1 opacity-80">Tap a drawing to select it. Drag to move. Use the blue dot to resize and the red dot to delete. The bar under the selection duplicates, reorders, recolours or deletes it.</p>
    </div>
  );
  return null;
}

/* ------------------------------------------------------------------ popover (used by the ribbon and the floating bar) */
export function Pop({ rect, onClose, children, width = 330, above }) {
  const ref = useRef(null);
  useEffect(() => {
    const h = (e) => { if (!ref.current?.contains(e.target) && !e.target.closest?.('[data-toolbtn]')) onClose(); };
    document.addEventListener('pointerdown', h); return () => document.removeEventListener('pointerdown', h);
  }, [onClose]);
  if (!rect) return null;
  const left = Math.max(8, Math.min(rect.left + rect.width / 2 - width / 2, window.innerWidth - width - 8));
  const style = above ? { bottom: window.innerHeight - rect.top + 8 } : { top: rect.bottom + 6 };
  return createPortal(
    <div ref={ref} style={{ position: 'fixed', left, width, maxHeight: above ? Math.min(window.innerHeight - 140, rect.top - 16) : window.innerHeight - rect.bottom - 16, ...style }}
      className="glass glass-menu z-[65] animate-pop overflow-y-auto overscroll-contain rounded-3xl p-3">{children}</div>, document.body);
}

/* ------------------------------------------------------------------ ribbon tab */
export function DrawTab({ c }) {
  const { ink, flash } = c;
  const [pop, setPop] = useState(null);
  const pg = c.view.pageNav;
  const pageInfo = { page: pg.page, pitch: c.pageGeom.pitch, H: c.pageGeom.H };
  const tap = (id, e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    if (ink.tool !== id) { ink.setTool(id); setPop(null); } else setPop(pop && pop.id === id ? null : { id, rect });
  };
  const cur = ink.tool && ink.cfg[ink.tool];
  const quick = ink.tool && hasColor(ink.tool) && cur
    ? (ink.tool === 'highlighter' ? ink.hlPalette : ink.tool === 'laser' ? LASER_COLORS : ink.palette).slice(0, 7) : null;
  return (<>
    <Group title="Draw tools">
      {TOOLS.map(([id, label, Icon]) => (
        <button key={id} type="button" data-toolbtn="1" title={ink.tool === id ? `${label} options` : label} onMouseDown={(e) => e.preventDefault()} onClick={(e) => tap(id, e)} className={`rbtn relative ${ink.tool === id ? 'rbtn-on' : ''}`}>
          <Icon size={19} /><span className="text-xs">{label}</span>
          {ink.cfg[id]?.color && <i className="absolute right-1.5 top-1.5 h-2.5 w-2.5 rounded-full border border-white/70" style={{ background: ink.cfg[id].color }} />}
        </button>
      ))}
    </Group>
    <Group title="Type">
      <Btn icon={Type} label="Text" on={!ink.tool} title="Back to typing" onClick={() => ink.setTool(null)} />
      <Btn icon={ink.fingerDraw ? Fingerprint : Hand} label={ink.fingerDraw ? 'Finger draws' : 'Stylus only'} on={ink.fingerDraw} title={ink.fingerDraw ? 'Finger draws as well' : 'Stylus draws, finger scrolls'} onClick={() => { ink.setPref({ fingerDraw: !ink.fingerDraw }); flash(ink.fingerDraw ? 'Stylus draws, finger scrolls' : 'Finger draws too'); }} />
    </Group>
    {quick && (
      <Group title="Colour">
        <div className="flex max-w-[330px] flex-wrap items-center gap-1.5 px-1 py-1">
          {quick.map((col) => <button key={col} type="button" aria-label={col} onMouseDown={(e) => e.preventDefault()} onClick={() => ink.setCfg(ink.tool, { color: col })} style={{ background: col }} className={`h-8 w-8 rounded-full border border-black/15 active:scale-90 ${cur.color && cur.color.toLowerCase() === col.toLowerCase() ? 'ring-2 ring-blue-500 ring-offset-1' : ''}`} />)}
          <label className="relative h-8 w-8 cursor-pointer rounded-full border border-black/15" title="Colour wheel" style={{ background: 'conic-gradient(red,yellow,lime,aqua,blue,magenta,red)' }}>
            <input type="color" value={/^#[0-9a-f]{6}$/i.test(cur.color || '') ? cur.color : '#111827'} onChange={(e) => ink.setCfg(ink.tool, { color: e.target.value })} className="absolute inset-0 h-full w-full cursor-pointer opacity-0" />
          </label>
        </div>
      </Group>
    )}
    <Group title="Edit">
      <Btn icon={Undo2} label="Undo ink" disabled={!ink.canUndo} onClick={() => ink.undo()} />
      <Btn icon={Redo2} label="Redo ink" disabled={!ink.canRedo} onClick={() => ink.redo()} />
    </Group>
    {pop && <Pop rect={pop.rect} onClose={() => setPop(null)}><ToolOptions tool={pop.id} ink={ink} confirm={c.confirm} flash={flash} pageInfo={pageInfo} /></Pop>}
  </>);
}

/* ------------------------------------------------------------------ floating tool bar (shown while a drawing tool is on) */
export function InkDock({ ink, confirm, flash, pageInfo }) {
  const [pop, setPop] = useState(null);
  const { tool } = ink;
  useEffect(() => { setPop(null); }, [tool]);
  if (!tool) return null;
  const tap = (id, e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    if (ink.tool !== id) ink.setTool(id); else setPop(pop ? null : { id, rect });
  };
  const sw = ink.cfg[tool]?.color;
  return (<>
    <div className="glass glass-menu no-print fixed bottom-14 left-1/2 z-[70] flex max-w-[96vw] -translate-x-1/2 items-center gap-0.5 overflow-x-auto rounded-full p-1.5" style={{ touchAction: 'pan-x' }}>
      {TOOLS.map(([id, label, Icon]) => (
        <button key={id} type="button" data-toolbtn="1" title={label} aria-label={label} onClick={(e) => tap(id, e)} className={`relative grid min-h-[44px] min-w-[44px] place-items-center rounded-full ${tool === id ? 'rbtn-on' : 'hover:bg-black/5 dark:hover:bg-white/10'}`}>
          <Icon size={20} />
          {tool === id && sw && <i className="absolute bottom-1 right-1 h-2.5 w-2.5 rounded-full border border-white/80" style={{ background: sw }} />}
        </button>
      ))}
      <span className="mx-1 h-6 w-px bg-black/15 dark:bg-white/20" />
      <button type="button" title="Undo" aria-label="Undo ink" disabled={!ink.canUndo} onClick={() => ink.undo()} className="grid min-h-[44px] min-w-[44px] place-items-center rounded-full hover:bg-black/5 disabled:opacity-35 dark:hover:bg-white/10"><Undo2 size={20} /></button>
      <button type="button" title="Redo" aria-label="Redo ink" disabled={!ink.canRedo} onClick={() => ink.redo()} className="grid min-h-[44px] min-w-[44px] place-items-center rounded-full hover:bg-black/5 disabled:opacity-35 dark:hover:bg-white/10"><Redo2 size={20} /></button>
      <button type="button" title={ink.fingerDraw ? 'Finger draws too' : 'Stylus only'} aria-label="Stylus or finger" onClick={() => ink.setPref({ fingerDraw: !ink.fingerDraw })} className={`grid min-h-[44px] min-w-[44px] place-items-center rounded-full ${ink.fingerDraw ? 'rbtn-on' : 'hover:bg-black/5 dark:hover:bg-white/10'}`}>{ink.fingerDraw ? <Fingerprint size={20} /> : <Hand size={20} />}</button>
      <button type="button" onClick={() => ink.setTool(null)} className="ml-1 flex min-h-[44px] items-center gap-1 rounded-full bg-blue-500 px-4 text-sm font-semibold text-white"><Type size={16} />Done</button>
    </div>
    {pop && <Pop rect={pop.rect} above onClose={() => setPop(null)}><ToolOptions tool={pop.id} ink={ink} confirm={confirm} flash={flash} pageInfo={pageInfo} /></Pop>}
  </>);
}
