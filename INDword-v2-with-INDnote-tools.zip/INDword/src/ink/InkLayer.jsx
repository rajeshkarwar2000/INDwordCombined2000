import { useEffect, useLayoutEffect, useReducer, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Copy, ArrowUpToLine, ArrowDownToLine, Trash2 } from 'lucide-react';
import R, { UNIT } from './render.js';
import { uid } from './engine.js';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const bboxCache = new WeakMap();
const bboxOf = (o) => { let b = bboxCache.get(o); if (!b) { b = R.bbox(o); bboxCache.set(o, b); } return b; };

/* ---------------------------------------------------------------- one page-sized drawing tile */
// kind 'base': pen, brush, shapes.   kind 'hl': highlighter strokes (their layer is multiplied onto the text underneath)
function Tile({ engine, kind, t, top, W, H, pitch, sc, reg }) {
  const slot = useRef(null), cv = useRef(null);
  const [vis0, setVis] = useState(t < 2);
  const [, force] = useReducer((x) => x + 1, 0);
  const vis = vis0 || engine.forceAll;
  const [has, setHas] = useState(kind === 'base');
  const raf = useRef(0);
  const bw = Math.max(1, Math.round(W * sc)), bh = Math.max(1, Math.round(H * sc));

  useEffect(() => {
    const el = slot.current; if (!el || !('IntersectionObserver' in window)) return undefined;
    const io = new IntersectionObserver((es) => es.forEach((e) => setVis(e.isIntersecting)), { rootMargin: '140% 0px 140% 0px' });
    io.observe(el); return () => io.disconnect();
  }, []);

  const paint = () => {
    raf.current = 0;
    const c = cv.current; if (!c || !vis) return;
    const cpp = c.width / W, k = cpp * UNIT, y0 = t * pitch;
    const lo = y0 / UNIT - 40, hi = (y0 + H) / UNIT + 40;
    const pv = engine.preview; let any = false;
    const items = [];
    for (const o0 of engine.objs) {
      const o = pv && pv.id === o0.id ? pv.o : o0;
      if (R.isHl(o) !== (kind === 'hl')) continue;
      const bb = bboxOf(o); if (bb.y > hi || bb.y + bb.h < lo) continue;
      items.push(o); any = true;
    }
    if (kind === 'hl' && any !== has) { setHas(any); if (!has) return; }
    const ctx = c.getContext('2d'); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, c.width, c.height);
    if (c.width <= 1) return;
    ctx.setTransform(k, 0, 0, k, 0, -y0 * cpp); ctx.imageSmoothingQuality = 'high';
    for (const o of items) { if (kind === 'hl') R.drawStroke(ctx, o, 0, null, true); else R.drawObj(ctx, o); }
  };
  const sched = () => { if (!raf.current) raf.current = requestAnimationFrame(paint); };
  const paintRef = useRef(paint); paintRef.current = paint;
  useEffect(() => {
    const un = engine.subscribe((k) => { if (k === 'force') force(); else sched(); });
    reg.set(`${kind}${t}`, () => { if (raf.current) { cancelAnimationFrame(raf.current); raf.current = 0; } paintRef.current(); });
    return () => { un(); reg.delete(`${kind}${t}`); cancelAnimationFrame(raf.current); raf.current = 0; };
  }, [engine, t, kind]); // eslint-disable-line react-hooks/exhaustive-deps
  useLayoutEffect(() => { paint(); }, [bw, bh, vis, has, pitch, t]); // eslint-disable-line react-hooks/exhaustive-deps

  const on = vis && has;
  return (
    <div ref={slot} style={{ position: 'absolute', left: 0, top, width: W, height: H, pointerEvents: 'none' }}>
      {vis && <canvas ref={cv} width={on ? bw : 1} height={on ? bh : 1} style={{ position: 'absolute', left: 0, top: 0, width: W, height: H, pointerEvents: 'none' }} />}
    </div>
  );
}

/* ---------------------------------------------------------------- the layer */
export default function InkLayer({ engine, tool, cfg, fingerDraw, W, H, gap, pageCount, zoom, scroller, hlBlend = 'multiply', onFlash, onPickColor }) {
  const pitch = H + gap, totalH = pageCount * pitch - gap;
  const layer = useRef(null), live = useRef(null), liveHl = useRef(null), laserCv = useRef(null), lastU = useRef(1);
  const [, bump] = useReducer((x) => x + 1, 0);
  const [selId, setSelId] = useState(null);
  const reg = useRef(new Map()).current;
  const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  const sc = Math.max(1, Math.min(dpr * zoom, 2.2, Math.sqrt(4e6 / (W * H))));

  const S = useRef({}); S.current = { tool, cfg, fingerDraw, W, H, pitch, totalH, zoom, selId, hlBlend };

  useEffect(() => { engine.relayout(pitch); }, [engine, pitch]);
  useEffect(() => engine.subscribe(() => { const id = S.current.selId; if (id) { if (!engine.objs.some((o) => o.id === id)) setSelId(null); bump(); } }), [engine]);
  useEffect(() => { if (tool !== 'select') setSelId(null); }, [tool]);

  /* ---------- coordinates ---------- */
  const toInk = (e) => {
    const r = layer.current.getBoundingClientRect(), cssU = r.width / S.current.W;
    return { x: (e.clientX - r.left) / cssU / UNIT, y: (e.clientY - r.top) / cssU / UNIT, u: cssU * UNIT, cssU };
  };
  const pres = (e) => (e.pointerType === 'pen' && e.pressure > 0 ? e.pressure : 0.5);

  /* ---------- live canvas (the stroke being drawn) ---------- */
  const lv = useRef({ top: 0, h: 0, cpp: 1, cv: null });
  const openLive = (yInk, hl) => {
    const cv = hl ? liveHl.current : live.current, { W: w, totalH: tot, zoom: z } = S.current; if (!cv) return null;
    const r = layer.current.getBoundingClientRect(), cssU = r.width / w;
    const vp = ((scroller?.current?.clientHeight || window.innerHeight) / cssU);
    const y = yInk * UNIT, top = clamp(y - vp, 0, Math.max(0, tot - 2 * vp)), h = Math.min(tot - top, Math.max(2.2 * vp, 400));
    const cpp = Math.max(1, Math.min(dpr * z, 2, Math.sqrt(5e6 / (w * h))));
    cv.width = Math.round(w * cpp); cv.height = Math.round(h * cpp);
    cv.style.top = `${top}px`; cv.style.height = `${h}px`;
    lv.current = { top, h, cpp, cv };
    return cv.getContext('2d');
  };
  const liveCtx = () => {
    const { cv, top, cpp } = lv.current, c = cv.getContext('2d');
    c.setTransform(cpp * UNIT, 0, 0, cpp * UNIT, 0, -top * cpp); return c;
  };
  const closeLive = () => { [live.current, liveHl.current].forEach((cv) => { if (cv) { cv.width = 1; cv.height = 1; } }); };
  const paintAll = () => reg.forEach((f) => f());

  /* ---------- input ---------- */
  const st = useRef({ cur: null, touches: new Map(), pinch: false, lastPen: 0, raf: 0, vel: { vx: 0, vy: 0, t: 0 }, pan: { x: 0, y: 0, raf: 0 }, fling: 0, lastTap: 0, laser: { strokes: [], cur: null, raf: 0 } }).current;

  useEffect(() => {
    const el = layer.current; if (!el || !tool) return undefined;
    const sc0 = () => scroller?.current;
    const cap = (id) => { try { el.setPointerCapture(id); } catch { /* released pointer */ } };

    const applyPan = () => { st.pan.raf = 0; const s = sc0(); if (s) { s.scrollLeft -= st.pan.x; s.scrollTop -= st.pan.y; } st.pan.x = st.pan.y = 0; };
    const flingStop = () => { if (st.fling) { cancelAnimationFrame(st.fling); st.fling = 0; } };
    const doFling = () => {
      flingStop(); let last = performance.now();
      const tick = (t) => {
        const dt = Math.min(40, t - last); last = t; const s = sc0(); if (!s) return;
        s.scrollLeft -= st.vel.vx * dt; s.scrollTop -= st.vel.vy * dt;
        const f = Math.exp(-dt / 330); st.vel.vx *= f; st.vel.vy *= f;
        st.fling = Math.hypot(st.vel.vx, st.vel.vy) > 0.02 ? requestAnimationFrame(tick) : 0;
      };
      st.fling = requestAnimationFrame(tick);
    };

    /* ===== pointer down ===== */
    const down = (e) => {
      if (e.target.closest && e.target.closest('[data-inkui]')) return;
      flingStop();
      const { fingerDraw: fd } = S.current;
      if (e.pointerType === 'pen') st.lastPen = performance.now();
      if (e.pointerType === 'touch') {
        if (!fd && performance.now() - st.lastPen < 700) return; // palm rejection
        st.touches.set(e.pointerId, { x: e.clientX, y: e.clientY }); st.vel.vx = st.vel.vy = 0; st.vel.t = 0;
        if (st.touches.size >= 2) { cancelDraw(); st.pinch = true; return; }
        if (!fd) { cap(e.pointerId); return; }
      }
      if (st.touches.size >= 2) return;
      let t = S.current.tool;
      if (e.pointerType === 'pen' && (e.buttons & 32 || e.button === 5)) t = 'eraser';
      cap(e.pointerId);
      if (t === 'laser') { beginLaser(e); return; }
      begin(t, e);
    };

    const begin = (t, e) => {
      const p = toInk(e), c = S.current.cfg[t] || {};
      st.cur = { tool: t, id: e.pointerId, u: p.u, x0: p.x, y0: p.y, moved: false, q: [] };
      const cur = st.cur;
      if (t === 'pen' || t === 'brush' || t === 'highlighter') {
        const kind = t === 'highlighter' ? 'hl' : t;
        const s = { id: uid(), t: 's', tool: kind, pts: [[p.x, p.y, pres(e)]], size: c.size, color: c.color, seed: (Math.random() * 1e9) | 0 };
        if (t === 'pen') Object.assign(s, { pen: c.pen, line: c.line, space: c.space, nib: c.nib, angle: c.angle });
        if (t === 'brush') s.brush = c.brush;
        if (t === 'highlighter') { s.alpha = c.alpha; s.tip = c.tip || 'round'; s.straight = !!c.straight; }
        cur.s = s; cur.st = R.newStrokeState(s); cur.drawn = 0;
        openLive(p.y, t === 'highlighter');
        liveStroke();
      } else if (t === 'eraser') {
        openLive(p.y, false); cur.pushed = false; eraseAt(p); drawEraserCursor(p);
      } else if (t === 'select') selectDown(p);
      else if (t === 'shapes') { cur.x1 = p.x; cur.y1 = p.y; cur.x2 = p.x; cur.y2 = p.y; openLive(p.y, false); }
    };

    /* ===== move ===== */
    const move = (e) => {
      if (e.pointerType === 'touch' && st.touches.has(e.pointerId)) {
        const prev = st.touches.get(e.pointerId); st.touches.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (st.pinch || st.touches.size >= 2) return;
        if (!st.cur) {
          const dx = e.clientX - prev.x, dy = e.clientY - prev.y, now = performance.now(), dt = Math.max(1, now - (st.vel.t || now - 16));
          st.pan.x += dx; st.pan.y += dy; if (!st.pan.raf) st.pan.raf = requestAnimationFrame(applyPan);
          st.vel.vx = st.vel.vx * 0.55 + (dx / dt) * 0.45; st.vel.vy = st.vel.vy * 0.55 + (dy / dt) * 0.45; st.vel.t = now; return;
        }
      }
      const cur = st.cur; if (!cur || cur.id !== e.pointerId) return;
      const evs = (e.getCoalescedEvents && e.getCoalescedEvents()) || [], list = evs.length ? evs : [e];
      if (cur.tool === 'laser') {
        const ls = st.laser.cur, now = performance.now();
        if (ls) for (const ev of list) {
          const q = { x: ev.clientX, y: ev.clientY, t: now };
          if (ls.mode === 'dot') ls.pts = [q]; else { const l = ls.pts[ls.pts.length - 1]; if (Math.hypot(q.x - l.x, q.y - l.y) >= 1.2) ls.pts.push(q); }
        }
        laserLoop(); return;
      }
      for (const ev of list) step(ev);
    };
    const step = (ev) => {
      const cur = st.cur, p = toInk(ev), t = cur.tool;
      if (!cur.moved && Math.hypot(p.x - cur.x0, p.y - cur.y0) * cur.u > 4) cur.moved = true;
      if (cur.s) {
        const s = cur.s;
        if (s.straight) {
          let x = p.x, y = p.y; const a = s.pts[0], dx = x - a[0], dy = y - a[1], L = Math.hypot(dx, dy);
          if (L > 8 / cur.u) { const ang = Math.abs(Math.atan2(dy, dx)); if (ang < 0.07 || ang > Math.PI - 0.07) y = a[1]; else if (Math.abs(ang - Math.PI / 2) < 0.07) x = a[0]; }
          s.pts = [a, [x, y, 0.5]];
        } else { const l = s.pts[s.pts.length - 1]; if (s.pts.length < 2 || Math.hypot(p.x - l[0], p.y - l[1]) * cur.u >= 1.4) s.pts.push([p.x, p.y, pres(ev)]); }
        sched();
      } else if (t === 'eraser') { cur.q.push(p); sched(); }
      else if (t === 'select') { cur.last = p; sched(); }
      else if (t === 'shapes') { cur.x2 = p.x; cur.y2 = p.y; sched(); }
    };
    const sched = () => { if (!st.raf) st.raf = requestAnimationFrame(frame); };
    const frame = () => {
      st.raf = 0; const cur = st.cur; if (!cur) return; const t = cur.tool;
      if (cur.s) liveStroke();
      else if (t === 'eraser') { const q = cur.q; cur.q = []; for (const p of q) eraseAt(p); if (q.length) drawEraserCursor(q[q.length - 1]); }
      else if (t === 'select') { if (cur.last) selectMove(cur.last); }
      else if (t === 'shapes') drawCreating();
    };

    /* ===== up ===== */
    const up = (e) => {
      if (e.pointerType === 'touch') {
        st.touches.delete(e.pointerId);
        if (st.touches.size < 2) st.pinch = st.touches.size > 0 ? st.pinch : false;
        if (!st.cur && st.touches.size === 0 && performance.now() - st.vel.t < 90 && Math.hypot(st.vel.vx, st.vel.vy) > 0.25) doFling();
      }
      const cur = st.cur; if (!cur || cur.id !== e.pointerId) return;
      if (st.raf) { cancelAnimationFrame(st.raf); st.raf = 0; }
      frame();
      st.cur = null;
      const t = cur.tool;
      if (cur.s) commitStroke(cur);
      else if (t === 'eraser') { closeLive(); }
      else if (t === 'laser') { if (st.laser.cur) { st.laser.cur.end = performance.now(); st.laser.cur = null; } }
      else if (t === 'select') selectUp(cur);
      else if (t === 'shapes') commitShape(cur);
    };
    const cancelDraw = () => {
      const cur = st.cur; if (!cur) return; st.cur = null;
      if (cur.tool === 'laser') { if (st.laser.cur) { st.laser.cur.end = performance.now(); st.laser.cur = null; } return; }
      if (cur.tool === 'select') { engine.preview = null; paintAll(); }
      closeLive();
    };

    /* ===== strokes ===== */
    function liveStroke() {
      const cur = st.cur, s = cur.s, ctx = liveCtx();
      if (s.tool === 'hl' || (s.tool === 'pen' && s.line && s.line !== 'solid')) {
        const bb = cur.bb || (cur.bb = [1e9, 1e9, -1e9, -1e9]), pad = s.size + 4;
        for (let i = cur.drawn || 0; i < s.pts.length; i++) { const q = s.pts[i]; if (q[0] < bb[0]) bb[0] = q[0]; if (q[1] < bb[1]) bb[1] = q[1]; if (q[0] > bb[2]) bb[2] = q[0]; if (q[1] > bb[3]) bb[3] = q[1]; }
        const pv = cur.pb || bb; cur.pb = bb.slice();
        const x0 = Math.min(pv[0], bb[0]) - pad, y0 = Math.min(pv[1], bb[1]) - pad, x1 = Math.max(pv[2], bb[2]) + pad, y1 = Math.max(pv[3], bb[3]) + pad;
        ctx.clearRect(x0 - pad * 2, y0 - pad * 2, x1 - x0 + pad * 4, y1 - y0 + pad * 4);
        cur.drawn = s.pts.length; R.drawStroke(ctx, s, 0, null, true); return;
      }
      R.drawStroke(ctx, s, cur.drawn, cur.st, true); cur.drawn = s.pts.length;
    }
    function commitStroke(c) {
      const s = c.s;
      if (s.pts.length === 1 && s.pen) s.pts.push([s.pts[0][0] + 0.01, s.pts[0][1], s.pts[0][2]]);
      engine.add(s); paintAll(); closeLive(); // painted onto the tiles first, then the live canvas is cleared: no blink
    }

    /* ===== eraser ===== */
    const densify = (pts, gapU) => {
      const out = [pts[0]];
      for (let i = 1; i < pts.length; i++) {
        const a = pts[i - 1], b = pts[i], d = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.ceil(d / gapU);
        for (let k = 1; k <= n; k++) { const f = k / n; out.push([a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, (a[2] ?? 0.5) + ((b[2] ?? 0.5) - (a[2] ?? 0.5)) * f]); }
      }
      return out;
    };
    function eraseAt(p) {
      const ec = S.current.cfg.eraser, r = ec.size / 2, out = []; let changed = false;
      for (const o of engine.objs) {
        if (!R.hit(o, p.x, p.y, r)) { out.push(o); continue; }
        if (ec.mode === 'pixel' && o.t === 's') {
          const lim = r + o.size / 2, dp = densify(o.pts, Math.max(2, o.size / 3)), runs = []; let run = [];
          for (const q of dp) { if (Math.hypot(q[0] - p.x, q[1] - p.y) <= lim) { if (run.length) runs.push(run); run = []; } else run.push(q); }
          if (run.length) runs.push(run);
          if (runs.length === 1 && runs[0].length === dp.length) { out.push(o); continue; }
          runs.forEach((rn) => out.push({ ...o, id: uid(), pts: rn }));
          changed = true;
        } else changed = true;
      }
      if (changed) { if (!st.cur.pushed) { engine.push(); st.cur.pushed = true; } engine.set(out); }
    }
    function drawEraserCursor(p) {
      const cur = st.cur, ctx = liveCtx(), rr = S.current.cfg.eraser.size / 2 + 6;
      if (cur.ec) ctx.clearRect(cur.ec.x - rr, cur.ec.y - rr, rr * 2, rr * 2); else ctx.clearRect(0, 0, 1e5, 1e5);
      cur.ec = { x: p.x, y: p.y };
      ctx.save(); ctx.strokeStyle = 'rgba(60,70,90,.85)'; ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.lineWidth = 2 / (lv.current.cpp * UNIT);
      ctx.beginPath(); ctx.arc(p.x, p.y, S.current.cfg.eraser.size / 2, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); ctx.restore();
    }

    /* ===== laser pointer (screen-space canvas, never saved) ===== */
    function beginLaser(e) {
      const lc = S.current.cfg.laser, now = performance.now();
      st.cur = { tool: 'laser', id: e.pointerId };
      const ls = { pts: [{ x: e.clientX, y: e.clientY, t: now }], end: 0, mode: lc.mode === 'delay' ? 'hold' : lc.mode === 'line' ? 'trail' : lc.mode, color: lc.color, size: lc.size, delay: lc.delay, trail: lc.trail || 650 };
      st.laser.strokes.push(ls); st.laser.cur = ls; laserLoop();
    }
    function laserLoop() {
      const L = st.laser; if (L.raf) return;
      const tick = () => {
        L.raf = 0; const cv = laserCv.current; if (!cv) return;
        const d = Math.min(window.devicePixelRatio || 1, 2), w = window.innerWidth, hh = window.innerHeight;
        if (cv.width !== Math.round(w * d) || cv.height !== Math.round(hh * d)) { cv.width = Math.round(w * d); cv.height = Math.round(hh * d); }
        const ctx = cv.getContext('2d'); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height); ctx.setTransform(d, 0, 0, d, 0, 0);
        const now = performance.now(), keep = [];
        for (const s of L.strokes) {
          const isDown = !s.end, since = now - s.end, sz = s.size * 0.8, last = s.pts[s.pts.length - 1];
          if (s.mode === 'dot') {
            if (!isDown && since > 220) continue; keep.push(s);
            R.drawLaser(ctx, [], null, s.color, sz, { head: { x: last.x, y: last.y, a: isDown ? 1 : 1 - since / 220 } });
          } else if (s.mode === 'hold') {
            const fade = isDown ? 1 : (since - s.delay * 1000 <= 0 ? 1 : 1 - (since - s.delay * 1000) / 650);
            if (fade <= 0) continue; keep.push(s);
            R.drawLaser(ctx, s.pts, null, s.color, sz, { alpha: fade, head: isDown ? { x: last.x, y: last.y, a: 1 } : null });
          } else {
            const TR = s.trail; if (!isDown && since > TR + 60) continue; keep.push(s);
            while (s.pts.length > 2 && now - s.pts[0].t > TR + 60) s.pts.shift();
            const al = s.pts.map((q) => { const a = 1 - (now - q.t) / TR; return a <= 0 ? 0 : Math.pow(a, 1.25); });
            R.drawLaser(ctx, s.pts, al, s.color, sz, { taper: true, head: isDown ? { x: last.x, y: last.y, a: 1 } : (since < 150 ? { x: last.x, y: last.y, a: 1 - since / 150 } : null) });
          }
        }
        L.strokes = keep;
        if (keep.length) L.raf = requestAnimationFrame(tick); else ctx.clearRect(0, 0, w, hh);
      };
      L.raf = requestAnimationFrame(tick);
    }

    /* ===== shapes ===== */
    const snapLine = (c) => {
      const dx = c.x2 - c.x1, dy = c.y2 - c.y1, L = Math.hypot(dx, dy); if (!L) return;
      const a = Math.atan2(dy, dx), q = Math.PI / 4, n = Math.round(a / q);
      if (Math.abs(a - n * q) < 0.09) { c.x2 = c.x1 + L * Math.cos(n * q); c.y2 = c.y1 + L * Math.sin(n * q); }
    };
    const shapeObj = (c, id) => { const k = S.current.cfg.shapes; return { id, t: 'shape', kind: k.kind, x1: c.x1, y1: c.y1, x2: c.x2, y2: c.y2, color: k.color, bw: k.bw, fill: k.fill, fillColor: k.fillColor || null, dash: k.dash, op: k.op }; };
    function drawCreating() {
      const ctx = liveCtx(), c = st.cur; ctx.clearRect(0, 0, 1e5, 1e5);
      if (R.isLineShape(S.current.cfg.shapes.kind)) snapLine(c);
      R.drawObj(ctx, shapeObj(c));
    }
    function commitShape(c) {
      closeLive();
      if (Math.hypot(c.x2 - c.x1, c.y2 - c.y1) * c.u < 10) { // a tap places a default-size shape
        const d = 220, k = S.current.cfg.shapes.kind, line = R.isLineShape(k);
        c.x1 = Math.max(10, c.x0 - d / 2); c.y1 = c.y0 - d / 2 + (line ? d / 2 : 0); c.x2 = c.x1 + d; c.y2 = line ? c.y1 : c.y1 + d * 0.7;
      } else if (R.isLineShape(S.current.cfg.shapes.kind)) snapLine(c);
      engine.add(shapeObj(c, uid())); paintAll();
    }

    /* ===== select / move / resize ===== */
    const handles = (o) => {
      const b = R.bbox(o), r = Math.max(22, 20 / (lastU.current || 1));
      const line = o.t === 'shape' && R.isLineShape(o.kind);
      return { b, r, del: [b.x + b.w + 8, b.y - 8], size: [b.x + b.w, b.y + b.h], ep: line ? [[o.x1, o.y1], [o.x2, o.y2]] : null };
    };
    function selectDown(p) {
      lastU.current = p.u;
      const cur = st.cur, selO = engine.objs.find((o) => o.id === S.current.selId);
      if (selO) {
        const hd = handles(selO);
        if (Math.hypot(p.x - hd.del[0], p.y - hd.del[1]) <= hd.r) { cur.mode = 'delete'; return; }
        if (hd.ep) for (let i = 0; i < 2; i++) if (Math.hypot(p.x - hd.ep[i][0], p.y - hd.ep[i][1]) <= hd.r) { cur.mode = 'endpoint'; cur.ei = i; cur.o0 = selO; return; }
        if (Math.hypot(p.x - hd.size[0], p.y - hd.size[1]) <= hd.r) { cur.mode = 'resize'; cur.o0 = selO; cur.b0 = R.bbox(selO); return; }
      }
      let hit = null;
      for (let i = engine.objs.length - 1; i >= 0; i--) if (R.hit(engine.objs[i], p.x, p.y, 10 / p.u)) { hit = engine.objs[i]; break; }
      if (!hit) { cur.mode = 'none'; setSelId(null); return; }
      setSelId(hit.id); S.current.selId = hit.id; cur.mode = 'move'; cur.o0 = hit;
    }
    function selectMove(p) {
      const cur = st.cur, m = cur.mode; if (m !== 'move' && m !== 'resize' && m !== 'endpoint') return;
      if (!cur.moved) return;
      const o0 = cur.o0; let o;
      if (m === 'move') o = R.transform(o0, 0, 0, 1, 1, p.x - cur.x0, p.y - cur.y0);
      else if (m === 'endpoint') {
        o = { ...o0 }; const k = cur.ei ? ['x2', 'y2'] : ['x1', 'y1']; o[k[0]] = p.x; o[k[1]] = p.y;
        const dx = o.x2 - o.x1, dy = o.y2 - o.y1, L = Math.hypot(dx, dy), q = Math.PI / 4, n = Math.round(Math.atan2(dy, dx) / q);
        if (L && Math.abs(Math.atan2(dy, dx) - n * q) < 0.09) { if (cur.ei) { o.x2 = o.x1 + L * Math.cos(n * q); o.y2 = o.y1 + L * Math.sin(n * q); } else { o.x1 = o.x2 - L * Math.cos(n * q); o.y1 = o.y2 - L * Math.sin(n * q); } }
      } else {
        const b = cur.b0; let sx = Math.max(0.1, (p.x - b.x) / b.w), sy = Math.max(0.1, (p.y - b.y) / b.h);
        if (o0.t === 's') sx = sy = Math.max(0.1, (sx + sy) / 2);
        o = R.transform(o0, b.x, b.y, sx, sy, 0, 0);
      }
      cur.cur = o; engine.preview = { id: o0.id, o }; paintAll(); bump();
    }
    function selectUp(c) {
      if (c.mode === 'delete') { if (S.current.selId) engine.remove([S.current.selId]); setSelId(null); paintAll(); return; }
      engine.preview = null;
      if (c.mode === 'none') { paintAll(); return; }
      if (c.moved && c.cur) { engine.replace(c.o0.id, c.cur); paintAll(); bump(); return; }
      paintAll(); bump();
    }

    el.addEventListener('pointerdown', down);
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    const noMenu = (e) => e.preventDefault();
    el.addEventListener('contextmenu', noMenu);
    return () => {
      el.removeEventListener('pointerdown', down); el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', up); el.removeEventListener('contextmenu', noMenu);
      cancelAnimationFrame(st.raf); st.raf = 0; st.cur = null; st.touches.clear(); st.pinch = false; flingStop();
      cancelAnimationFrame(st.pan.raf); st.pan.raf = 0;
      st.laser.strokes = []; st.laser.cur = null; cancelAnimationFrame(st.laser.raf); st.laser.raf = 0;
      const lc = laserCv.current; if (lc) { const c = lc.getContext('2d'); c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, lc.width, lc.height); }
      engine.preview = null; closeLive();
    };
  }, [tool, engine, scroller]); // eslint-disable-line react-hooks/exhaustive-deps

  /* keyboard: Delete removes the selected object */
  useEffect(() => {
    if (tool !== 'select') return undefined;
    const k = (e) => { if ((e.key === 'Delete' || e.key === 'Backspace') && S.current.selId && !/INPUT|TEXTAREA/.test((e.target || {}).tagName || '')) { engine.remove([S.current.selId]); setSelId(null); } };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [tool, engine]);

  /* ---------- selection visuals ---------- */
  const selObj = tool === 'select' && selId ? (engine.preview && engine.preview.id === selId ? engine.preview.o : engine.objs.find((o) => o.id === selId)) : null;
  let selUi = null;
  if (selObj) {
    const b = R.bbox(selObj), k = UNIT, px = (v) => v * k;
    const line = selObj.t === 'shape' && R.isLineShape(selObj.kind);
    const dot = (x, y, bg, key, ch) => <span key={key} style={{ position: 'absolute', left: px(x) - 11, top: px(y) - 11, width: 22, height: 22, borderRadius: 11, background: bg, border: '2px solid #fff', boxShadow: '0 1px 4px rgba(0,0,0,.4)', color: '#fff', fontSize: 14, lineHeight: '18px', textAlign: 'center', fontWeight: 700 }}>{ch}</span>;
    const barTop = px(b.y + b.h) + 20, flip = barTop + 56 > totalH;
    selUi = (<>
      <div style={{ position: 'absolute', left: px(b.x), top: px(b.y), width: px(b.w), height: px(b.h), border: '2px dashed #0a84ff', borderRadius: 4, pointerEvents: 'none' }} className="ink-ui" />
      <div className="ink-ui" style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        {dot(b.x + b.w + 8, b.y - 8, '#ef4444', 'd', '×')}
        {dot(b.x + b.w, b.y + b.h, '#0a84ff', 'r', '')}
        {line && [[selObj.x1, selObj.y1], [selObj.x2, selObj.y2]].map((q, i) => dot(q[0], q[1], '#fff', `e${i}`, ''))}
      </div>
      <div data-inkui="1" className="ink-ui glass glass-menu" style={{ position: 'absolute', left: clamp(px(b.x), 4, W - 190), top: flip ? Math.max(4, px(b.y) - 60) : barTop, display: 'flex', gap: 2, padding: 4, borderRadius: 16, pointerEvents: 'auto', zIndex: 5 }}>
        {[[Copy, 'Duplicate', () => { const n = engine.dup(selId); if (n) setSelId(n.id); }], [ArrowUpToLine, 'Bring to front', () => engine.order(selId, true)], [ArrowDownToLine, 'Send to back', () => engine.order(selId, false)], [Trash2, 'Delete', () => { engine.remove([selId]); setSelId(null); }]].map(([I, t, fn]) => (
          <button key={t} type="button" title={t} aria-label={t} onClick={fn} className="rbtn !min-h-[40px] !min-w-[40px]"><I size={18} /></button>
        ))}
        {onPickColor && <label title="Colour" className="rbtn !min-h-[40px] !min-w-[40px] cursor-pointer"><span style={{ width: 20, height: 20, borderRadius: 10, background: selObj.color, border: '2px solid rgba(0,0,0,.25)', display: 'block' }} /><input type="color" value={selObj.color && selObj.color.length === 7 ? selObj.color : '#111827'} onChange={(e) => engine.update(selId, { color: e.target.value })} style={{ position: 'absolute', opacity: 0, width: 1, height: 1 }} /></label>}
      </div>
    </>);
  }

  const tiles = Array.from({ length: pageCount }, (_, i) => i);
  const box = { position: 'absolute', left: 0, top: 0, width: W, height: totalH, zIndex: 3, pointerEvents: 'none' };
  return (<>
    {/* highlighter layer: multiplied onto the text so the words stay readable (screen on dark pages) */}
    <div className="ink-layer-hl" style={{ ...box, mixBlendMode: hlBlend }}>
      {tiles.map((i) => <Tile key={i} kind="hl" engine={engine} t={i} top={i * pitch} W={W} H={H} pitch={pitch} sc={sc} reg={reg} />)}
      <canvas ref={liveHl} width={1} height={1} className="ink-ui" style={{ position: 'absolute', left: 0, top: 0, width: W, pointerEvents: 'none' }} />
    </div>
    <div ref={layer} className="ink-layer" data-ink-layer="1" style={{ ...box, pointerEvents: tool ? 'auto' : 'none', touchAction: tool ? 'none' : 'auto', cursor: tool ? 'crosshair' : 'auto' }}>
      {tiles.map((i) => <Tile key={i} kind="base" engine={engine} t={i} top={i * pitch} W={W} H={H} pitch={pitch} sc={sc} reg={reg} />)}
      <canvas ref={live} width={1} height={1} className="ink-ui" style={{ position: 'absolute', left: 0, top: 0, width: W, pointerEvents: 'none' }} />
      {selUi}
    </div>
    {tool === 'laser' && createPortal(<canvas ref={laserCv} className="ink-ui" style={{ position: 'fixed', left: 0, top: 0, width: '100vw', height: '100vh', pointerEvents: 'none', zIndex: 60 }} />, document.body)}
  </>);
}
