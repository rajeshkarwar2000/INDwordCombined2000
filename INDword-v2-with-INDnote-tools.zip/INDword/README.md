# INDword
Word-style document app for Android tablets. Documents are stored on the device (IndexedDB) and work offline.
GitHub is used only to hold this source and to build the APK remotely.

## AI Notes
Add article images (Home card or Notes tab > From Images). Works through copy-paste with Gemini (no API key). Generated PYQ labels must be verified.

## Notes pages
Notes documents use a real paged layout (Notes tab > Notes Page): A4 cards with gaps, dashed border, header, footer, page numbers and the indIAS logo background. Text fills column 1, then column 2, then the next page. PDF export renders page by page.

## Save to…
Export (PDF, Word, etc.) opens Android's own "Save to" window so you choose the folder. The small native plugin is copied in automatically by the `capacitor:*:after` scripts in package.json (see scripts-native.cjs and resources/native). If it is missing, the app falls back to the share sheet.

## Draw tab (INDnote tools inside INDword) - version 2.0
Open the **Draw** tab (or any document) and pick a tool; a floating tool bar appears at the bottom. Tap an active tool again for its options.

- **Pen** (ball, natural, calligraphy broad/pointed; solid, dotted, dash), **Brush** (pencil, oil, spill, watercolor, crayon), **Highlighter** (round, flat, square, straight line; multiplied onto the text so words stay readable), **Laser pointer** (dot, trail, hold; never saved), **Eraser** (whole stroke or part of stroke, clear page / all), **Select** (move, resize, line ends, duplicate, front/back, recolour, delete), **Shapes** (24 shapes, fill, dash, opacity).
- Editable colour lists, colour wheel, stylus-only drawing with finger scrolling and palm rejection (switch to *Finger draws* when you have no stylus).
- Ink lives on a transparent layer over the pages, in Print Layout (paged or continuous). It is saved inside the document, follows page size changes, and is included in PDF export. Ink stays where it was drawn if the text above it changes, like a pen on paper.
- Undo / Redo in the top bar act on the drawing while a drawing tool is on, and on the text otherwise. **Done** (or the Back button) returns to typing.
- The ink layer is not part of Word (.docx), Markdown, HTML or text exports.
