import { UNIT } from './render.js';
import { uid } from './engine.js';

/** Reads a picture file and shrinks it (longest side 1600 px) so documents with pictures stay small. */
export function fileToInkImage(file, maxSide = 1600) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), im = new Image();
    im.onload = () => {
      const s = Math.min(1, maxSide / Math.max(im.naturalWidth, im.naturalHeight, 1));
      const w = Math.max(1, Math.round(im.naturalWidth * s)), h = Math.max(1, Math.round(im.naturalHeight * s));
      const c = document.createElement('canvas'); c.width = w; c.height = h;
      const x = c.getContext('2d'); const alpha = /png|webp|gif|svg/.test(file.type);
      if (!alpha) { x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); }
      x.drawImage(im, 0, 0, w, h); URL.revokeObjectURL(url);
      let src = alpha ? c.toDataURL('image/webp', 0.92) : c.toDataURL('image/jpeg', 0.88);
      if (alpha && !src.startsWith('data:image/webp')) src = c.toDataURL('image/png');
      res({ src, w, h });
    };
    im.onerror = () => { URL.revokeObjectURL(url); rej(new Error('That picture could not be opened')); };
    im.src = url;
  });
}

/** Puts a picture in the middle of the part of the page that is on screen and selects it, ready to move and resize. */
export async function insertInkImage(ink, file) {
  const img = await fileToInkImage(file);
  const layer = document.querySelector('[data-ink-layer="1"]'); if (!layer) throw new Error('Open a document first');
  const main = layer.closest('main') || document.body;
  const lr = layer.getBoundingClientRect(), mr = main.getBoundingClientRect(), z = lr.width / layer.offsetWidth || 1;
  const W = layer.offsetWidth / UNIT, H = layer.offsetHeight / UNIT;
  let wi = Math.min(W * 0.5, img.w / UNIT * 0.6 + W * 0.2), hi = wi * img.h / img.w;
  const maxH = (mr.height / z / UNIT) * 0.7; if (hi > maxH) { hi = maxH; wi = hi * img.w / img.h; }
  const cx = ((mr.left + mr.right) / 2 - lr.left) / z / UNIT, cy = ((mr.top + mr.bottom) / 2 - lr.top) / z / UNIT;
  const x1 = Math.max(0, Math.min(W - wi, cx - wi / 2)), y1 = Math.max(0, Math.min(H - hi, cy - hi / 2));
  const o = { id: uid(), t: 'img', iid: uid(), src: img.src, x1, y1, x2: x1 + wi, y2: y1 + hi, bw: 0, op: 1 };
  ink.engine.pendingSelect = o.id;
  ink.setTool('select');
  ink.engine.push(); ink.engine.set([...ink.engine.objs, o], 'draw');
}
