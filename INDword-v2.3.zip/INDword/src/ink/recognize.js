// Hold-to-draw shapes: turns a rough freehand stroke into a clean shape (line, circle / ellipse, rectangle / square, triangle, diamond).
// Points are [x, y, pressure] in ink units. Returns { kind, x1, y1, x2, y2 } (the same fields a Shapes-tool object uses) or null.

const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);

function segDist(p, a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1], l2 = dx * dx + dy * dy;
  let t = l2 ? ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l2 : 0; t = Math.max(0, Math.min(1, t));
  return Math.hypot(p[0] - (a[0] + t * dx), p[1] - (a[1] + t * dy));
}
const toPoly = (pts, closed) => { const e = []; for (let i = 1; i < pts.length; i++) e.push([pts[i - 1], pts[i]]); if (closed) e.push([pts[pts.length - 1], pts[0]]); return e; };
const minDist = (p, edges) => { let m = 1e18; for (const [a, b] of edges) { const d = segDist(p, a, b); if (d < m) m = d; } return m; };

// evenly spaced points along a polyline
function resample(pts, n, closed) {
  const path = closed ? [...pts, pts[0]] : pts; let L = 0; for (let i = 1; i < path.length; i++) L += dist(path[i - 1], path[i]);
  if (!L) return [pts[0]];
  const out = [], step = L / n; let acc = 0, target = 0;
  for (let i = 1; i < path.length && out.length < n; i++) {
    const a = path[i - 1], b = path[i], d = dist(a, b);
    while (acc + d >= target && out.length < n) { const f = d ? (target - acc) / d : 0; out.push([a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f]); target += step; }
    acc += d;
  }
  return out;
}

const UNIT_POLY = {
  rect: [[0, 0], [1, 0], [1, 1], [0, 1]],
  tri: [[0.5, 0], [1, 1], [0, 1]],
  diamond: [[0.5, 0], [1, 0.5], [0.5, 1], [0, 0.5]],
  ellipse: Array.from({ length: 72 }, (_, i) => { const a = (i * Math.PI * 2) / 72; return [0.5 + 0.5 * Math.cos(a), 0.5 + 0.5 * Math.sin(a)]; }),
};

/** the angle of a line snapped to 0 / 45 / 90 ... degrees when it is within about 4 degrees of one */
export function snapAngle(x1, y1, x2, y2) {
  const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy); if (!L) return [x2, y2];
  const q = Math.PI / 4, a = Math.atan2(dy, dx), n = Math.round(a / q);
  if (Math.abs(a - n * q) < 0.07) return [x1 + L * Math.cos(n * q), y1 + L * Math.sin(n * q)];
  return [x2, y2];
}

export function recognize(pts) {
  if (!pts || pts.length < 6) return null;
  let L = 0, x0 = 1e18, y0 = 1e18, x1 = -1e18, y1 = -1e18, turn = 0;
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i];
    if (p[0] < x0) x0 = p[0]; if (p[1] < y0) y0 = p[1]; if (p[0] > x1) x1 = p[0]; if (p[1] > y1) y1 = p[1];
    if (i) L += dist(pts[i - 1], p);
  }
  const w = x1 - x0, h = y1 - y0;
  if (L < 70 || Math.max(w, h) < 40) return null;                       // too small to be a deliberate shape
  // total turning of the path (a closed loop turns about 360 degrees, a line hardly at all)
  const s = resample(pts, 48, false);
  for (let i = 2; i < s.length; i++) {
    const a1 = Math.atan2(s[i - 1][1] - s[i - 2][1], s[i - 1][0] - s[i - 2][0]), a2 = Math.atan2(s[i][1] - s[i - 1][1], s[i][0] - s[i - 1][0]);
    let d = a2 - a1; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; turn += d;
  }
  const a = pts[0], z = pts[pts.length - 1], gap = dist(a, z);
  const closed = gap < 0.22 * L && Math.abs(turn) > 3.7;

  if (!closed) {
    // straight line: every point stays close to the chord
    if (gap < 60) return null;
    let dev = 0; for (const p of pts) { const d = segDist(p, a, z); if (d > dev) dev = d; }
    if (dev < 0.07 * gap + 3 && L < 1.3 * gap) { const [ex, ey] = snapAngle(a[0], a[1], z[0], z[1]); return { kind: 'line', x1: a[0], y1: a[1], x2: ex, y2: ey }; }
    return null;
  }
  if (Math.min(w, h) < 0.18 * Math.max(w, h)) return null;              // a squashed loop is not a shape

  const samp = resample(pts, 72, true), norm = (w + h) / 2;
  let best = null;
  for (const [kind, unit] of Object.entries(UNIT_POLY)) {
    const poly = unit.map((p) => [x0 + p[0] * w, y0 + p[1] * h]), edges = toPoly(poly, true);
    // how far the stroke is from the shape, and how much of the shape the stroke covers
    let e1 = 0; for (const p of samp) e1 += minDist(p, edges); e1 /= samp.length;
    const strokeEdges = toPoly(samp, true), dense = resample(poly, 96, true);
    let e2 = 0; for (const p of dense) e2 += minDist(p, strokeEdges); e2 /= dense.length;
    const err = (e1 + e2) / 2 / norm;
    if (!best || err < best.err) best = { kind, err };
  }
  if (!best || best.err > 0.07) return null;

  let { kind } = best, bx0 = x0, by0 = y0, bx1 = x1, by1 = y1;
  const sq = Math.abs(w - h) / Math.max(w, h) < (kind === 'ellipse' ? 0.14 : 0.1);
  if (sq && (kind === 'ellipse' || kind === 'rect')) { // a circle or a square: make it exact, around the same centre
    const m = Math.max(w, h) / 2, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2; bx0 = cx - m; bx1 = cx + m; by0 = cy - m; by1 = cy + m;
  }
  return { kind, x1: bx0, y1: by0, x2: bx1, y2: by1 };
}
