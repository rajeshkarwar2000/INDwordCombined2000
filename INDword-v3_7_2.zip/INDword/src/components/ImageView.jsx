import { useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { createRoot } from 'react-dom/client';
import { NodeSelection } from '@tiptap/pm/state';
import { PanelLeft, PanelRight, AlignCenter, Type, Crop, RotateCcw, RotateCw, RefreshCw, Download, Trash2, SlidersHorizontal, Lock, Unlock, Undo2 } from 'lucide-react';
import { Modal, Field } from './Dialogs.jsx';
import { saveBlob } from '../services/exporters.js';
import { readAsDataUrl } from '../services/importers.js';

const loadImg = (src) => new Promise((res, rej) => {
  const i = new window.Image(); i.crossOrigin = 'anonymous';
  i.onload = () => res(i); i.onerror = () => rej(new Error('Image could not be loaded')); i.src = src;
});
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

export async function cropDataUrl(src, { t, r, b, l }) {
  const i = await loadImg(src);
  const sx = Math.round((i.naturalWidth * l) / 100); const sy = Math.round((i.naturalHeight * t) / 100);
  const sw = Math.max(1, Math.round((i.naturalWidth * (100 - l - r)) / 100)); const sh = Math.max(1, Math.round((i.naturalHeight * (100 - t - b)) / 100));
  const c = document.createElement('canvas'); c.width = sw; c.height = sh;
  c.getContext('2d', { willReadFrequently: true }).drawImage(i, sx, sy, sw, sh, 0, 0, sw, sh);
  return c.toDataURL('image/png');
}
export async function rotateDataUrl(src, deg) {
  const i = await loadImg(src);
  const c = document.createElement('canvas'); c.width = i.naturalHeight; c.height = i.naturalWidth;
  const x = c.getContext('2d', { willReadFrequently: true }); x.translate(c.width / 2, c.height / 2); x.rotate((deg * Math.PI) / 180);
  x.drawImage(i, -i.naturalWidth / 2, -i.naturalHeight / 2);
  return c.toDataURL('image/png');
}

/* ---------- free-form crop: drag any edge or corner, or move the whole frame ---------- */
const MIN = 6;
const HANDLES = [['nw', 0, 0], ['n', 50, 0], ['ne', 100, 0], ['e', 100, 50], ['se', 100, 100], ['s', 50, 100], ['sw', 0, 100], ['w', 0, 50]];
const RATIOS = [['Free', null], ['1:1', 1], ['4:3', 4 / 3], ['3:4', 3 / 4], ['16:9', 16 / 9]];

export function CropDialog({ src, onApply, onClose }) {
  const [r, setR] = useState({ x: 0, y: 0, w: 100, h: 100 });
  const [ratio, setRatio] = useState(null);
  const [nat, setNat] = useState({ w: 1, h: 1 });
  const [busy, setBusy] = useState(false);
  const box = useRef(null);

  const pickRatio = (val) => {
    setRatio(val);
    if (!val) return;
    const ir = nat.w / nat.h;
    const w = val >= ir ? 100 : (100 * val) / ir; const h = val >= ir ? (100 * ir) / val : 100;
    setR({ x: (100 - w) / 2, y: (100 - h) / 2, w, h });
  };
  const begin = (mode) => (e) => {
    e.preventDefault(); e.stopPropagation();
    const b = box.current.getBoundingClientRect(); const s = { ...r };
    const x0 = e.clientX; const y0 = e.clientY; const t = e.currentTarget;
    t.setPointerCapture(e.pointerId);
    const move = (ev) => {
      const dx = ((ev.clientX - x0) / b.width) * 100; const dy = ((ev.clientY - y0) / b.height) * 100;
      let { x, y, w, h } = s;
      if (mode === 'move') { x = clamp2(s.x + dx, 0, 100 - s.w); y = clamp2(s.y + dy, 0, 100 - s.h); }
      else {
        if (mode.includes('w')) { const nx = clamp2(s.x + dx, 0, s.x + s.w - MIN); w = s.w + (s.x - nx); x = nx; }
        if (mode.includes('e')) w = clamp2(s.w + dx, MIN, 100 - s.x);
        if (mode.includes('n')) { const ny = clamp2(s.y + dy, 0, s.y + s.h - MIN); h = s.h + (s.y - ny); y = ny; }
        if (mode.includes('s')) h = clamp2(s.h + dy, MIN, 100 - s.y);
        if (ratio && mode.length === 2) {
          h = (w * nat.w) / (ratio * nat.h);
          if (mode.includes('n')) y = s.y + s.h - h;
          if (y < 0 || y + h > 100) return;
        }
      }
      setR({ x, y, w, h });
    };
    const up = () => { t.removeEventListener('pointermove', move); t.removeEventListener('pointerup', up); };
    t.addEventListener('pointermove', move); t.addEventListener('pointerup', up);
  };
  const apply = async () => {
    setBusy(true);
    try { const box = { t: r.y, l: r.x, r: 100 - r.x - r.w, b: 100 - r.y - r.h }; onApply(await cropDataUrl(src, box), box); } finally { setBusy(false); }
  };

  return (
    <Modal title="Crop Picture" onClose={onClose} wide>
      <p className="mb-2 text-sm opacity-70">Drag the edges or corners freely, or drag inside the frame to move it.</p>
      <div className="mb-3 flex justify-center rounded-2xl bg-black/10 p-4 dark:bg-white/10">
        <div ref={box} className="relative inline-block max-w-full select-none overflow-hidden" style={{ touchAction: 'none' }}>
          <img src={src} alt="" draggable={false} className="block max-h-[48vh] max-w-full" onLoad={(e) => setNat({ w: e.target.naturalWidth, h: e.target.naturalHeight })} />
          <div onPointerDown={begin('move')} className="absolute cursor-move" style={{ left: `${r.x}%`, top: `${r.y}%`, width: `${r.w}%`, height: `${r.h}%`, boxShadow: '0 0 0 9999px rgba(0,0,0,.55)', border: '2px solid #fff', touchAction: 'none' }}>
            {[33.3, 66.6].map((p) => <span key={`v${p}`} className="pointer-events-none absolute top-0 bottom-0 border-l border-white/50" style={{ left: `${p}%` }} />)}
            {[33.3, 66.6].map((p) => <span key={`h${p}`} className="pointer-events-none absolute left-0 right-0 border-t border-white/50" style={{ top: `${p}%` }} />)}
            {HANDLES.map(([k, x, y]) => (
              <span key={k} onPointerDown={begin(k)} aria-label={`Crop ${k}`}
                style={{ position: 'absolute', left: `${x}%`, top: `${y}%`, width: 30, height: 30, marginLeft: -15, marginTop: -15, display: 'grid', placeItems: 'center', touchAction: 'none' }}>
                <span style={{ width: k.length === 2 ? 16 : 12, height: k.length === 2 ? 16 : 12, borderRadius: k.length === 2 ? 3 : 6, background: '#fff', border: '2px solid #3b82f6', boxShadow: '0 1px 3px rgba(0,0,0,.5)' }} />
              </span>
            ))}
          </div>
        </div>
      </div>
      <div className="mb-3 flex flex-wrap gap-1">
        {RATIOS.map(([n, v]) => <button key={n} type="button" onClick={() => pickRatio(v)} className={`rbtn ${ratio === v ? 'rbtn-on' : ''}`}>{n}</button>)}
      </div>
      <div className="flex gap-2">
        <button type="button" className="secondary" onClick={() => { setRatio(null); setR({ x: 0, y: 0, w: 100, h: 100 }); }}>Reset</button>
        <button type="button" className="secondary flex-1" onClick={onClose}>Cancel</button>
        <button type="button" className="primary flex-1" disabled={busy} onClick={apply}>Apply Crop</button>
      </div>
    </Modal>
  );
}

function PropsDialog({ attrs, onApply, onClose }) {
  const [alt, setAlt] = useState(attrs.alt || '');
  const [w, setW] = useState(attrs.width || '');
  const [h, setH] = useState(attrs.height || '');
  const [lock, setLock] = useState(attrs.lock !== false);
  const [align, setAlign] = useState(attrs.align || 'inline');
  return (
    <Modal title="Picture Properties" onClose={onClose}>
      <Field label="Alternative text"><input className="ginput" value={alt} onChange={(e) => setAlt(e.target.value)} /></Field>
      <Field label="Width (e.g. 320px or 50%)"><input className="ginput" value={w} onChange={(e) => setW(e.target.value)} placeholder="auto" /></Field>
      <Field label="Height (e.g. 200px, leave empty for automatic)"><input className="ginput" value={h} onChange={(e) => setH(e.target.value)} placeholder="auto" /></Field>
      <label className="mb-3 flex min-h-[44px] items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={lock} onChange={(e) => setLock(e.target.checked)} /> Lock aspect ratio</label>
      <Field label="Layout">
        <select className="ginput" value={align} onChange={(e) => setAlign(e.target.value)}>
          <option value="inline">Inline with text</option><option value="left">Float left</option>
          <option value="center">Centre</option><option value="right">Float right</option>
        </select>
      </Field>
      <button type="button" className="primary w-full" onClick={() => onApply({ alt, align, lock, width: /^\d+(\.\d+)?(px|%)$/.test(w.trim()) ? w.trim() : null, height: !lock && /^\d+(\.\d+)?px$/.test(h.trim()) ? h.trim() : null })}>Apply</button>
    </Modal>
  );
}

const TBL = ({ icon: I, label, text, on, onClick }) => (
  <button type="button" title={label} aria-label={label} onMouseDown={(e) => e.preventDefault()} onClick={onClick}
    className={`rbtn !min-h-[44px] ${on ? 'rbtn-on' : ''}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '0 10px', fontSize: 13, fontWeight: 600 }}><I size={18} />{text}</button>
);
const TB = ({ icon: I, label, on, onClick, children }) => (
  <button type="button" title={label} aria-label={label} onMouseDown={(e) => e.preventDefault()} onClick={onClick}
    className={`rbtn !min-h-[44px] !min-w-[44px] ${on ? 'rbtn-on' : ''}`}>{I ? <I size={18} /> : children}</button>
);

/* The buttons, the resize handles and the dialogs of a selected picture (React). The picture itself is plain DOM (see createImageNodeView),
   so it is always drawn, even if this part fails. */
function ImageOverlay({ a, show, ctl }) {
  const file = useRef(null);
  const [dlg, setDlg] = useState(null);
  const { updateAttributes, deleteNode, startResize, download, replace, rotate, sizePct, block } = ctl;
  return (
    <>
      {show && (
        <>
          {[
            ['nw', -1, -1, { left: -12, top: -12 }, 'nwse-resize'], ['ne', 1, -1, { right: -12, top: -12 }, 'nesw-resize'],
            ['sw', -1, 1, { left: -12, bottom: -12 }, 'nesw-resize'], ['se', 1, 1, { right: -12, bottom: -12 }, 'nwse-resize'],
            ['n', 0, -1, { left: '50%', top: -12, marginLeft: -12 }, 'ns-resize'], ['s', 0, 1, { left: '50%', bottom: -12, marginLeft: -12 }, 'ns-resize'],
            ['w', -1, 0, { top: '50%', left: -12, marginTop: -12 }, 'ew-resize'], ['e', 1, 0, { top: '50%', right: -12, marginTop: -12 }, 'ew-resize'],
          ].map(([k, dx, dy, pos, cur]) => (
            <span key={k} onPointerDown={startResize(dx, dy)} aria-label={`Resize ${k}`}
              style={{ position: 'absolute', width: 24, height: 24, borderRadius: dx && dy ? 12 : 6, background: dx && dy ? '#3b82f6' : '#fff', border: '3px solid #3b82f6', boxShadow: '0 1px 4px rgba(0,0,0,.4)', touchAction: 'none', cursor: cur, zIndex: 5, ...pos }} />
          ))}
          <span className="glass glass-menu no-print" onMouseDown={(e) => e.preventDefault()} onPointerDown={(e) => e.stopPropagation()} style={{ position: 'absolute', ...(a.align === 'right' ? { right: 0 } : { left: 0 }), top: '100%', marginTop: 14, zIndex: 40, display: 'flex', flexWrap: 'wrap', gap: 2, padding: 6, borderRadius: 18, width: 'max-content', maxWidth: 460, fontSize: 13, lineHeight: 1.2, textAlign: 'left' }}>
            <TB icon={PanelLeft} label="Float left: text wraps around the picture" on={a.align === 'left'} onClick={() => updateAttributes({ align: 'left', dx: 0 })} />
            <TB icon={AlignCenter} label="Centre: text above and below" on={a.align === 'center'} onClick={() => updateAttributes({ align: 'center', dx: 0 })} />
            <TB icon={PanelRight} label="Float right: text wraps around the picture" on={a.align === 'right'} onClick={() => updateAttributes({ align: 'right', dx: 0 })} />
            <TB icon={Type} label={block ? 'Own line: text above and below' : 'Inline with text'} on={a.align === 'inline' || !a.align} onClick={() => updateAttributes({ align: 'inline', dx: 0 })} />
            {[25, 50, 75, 100].map((p) => <TB key={p} label={`${p}%`} on={a.width === `${p}%`} onClick={() => sizePct(p)}>{p}%</TB>)}
            <TBL icon={a.lock === false ? Unlock : Lock} text={a.lock === false ? 'Free resize: ON' : 'Free resize'} label={a.lock === false ? 'Free resize is ON: the handles stretch width and height separately. Tap to keep the ratio again.' : 'Free resize: turn on to stretch width and height separately with the handles'} on={a.lock === false} onClick={() => updateAttributes({ lock: a.lock === false, height: null })} />
            <TB icon={Undo2} label="Reset size" onClick={() => updateAttributes({ width: null, height: null })} />
            <TB icon={Crop} label="Crop" onClick={() => setDlg('crop')} />
            <TB icon={RotateCcw} label="Rotate left" onClick={() => rotate(-90)} />
            <TB icon={RotateCw} label="Rotate right" onClick={() => rotate(90)} />
            <TB icon={RefreshCw} label="Replace image" onClick={() => file.current?.click()} />
            <TB icon={Download} label="Download image" onClick={download} />
            <TB icon={SlidersHorizontal} label="Image properties" onClick={() => setDlg('props')} />
            <TB icon={Trash2} label="Delete image" onClick={() => deleteNode()} />
            <input ref={file} type="file" accept="image/*" hidden onChange={replace} />
          </span>
        </>
      )}
      {dlg === 'crop' && createPortal(<CropDialog src={a.src} onClose={() => setDlg(null)} onApply={(src) => { updateAttributes({ src, width: null, height: null }); setDlg(null); }} />, document.body)}
      {dlg === 'props' && createPortal(<PropsDialog attrs={a} onClose={() => setDlg(null)} onApply={(v) => { updateAttributes(v); setDlg(null); }} />, document.body)}
    </>
  );
}

const ALIGNS = ['left', 'right', 'center', 'inline'];
const clamp2 = (v, a, b) => Math.min(b, Math.max(a, v));

/** Node view of a picture: the <img> is created with plain DOM code; the handles, toolbar and dialogs are a small React layer on top.

    Structure:  dom (figure for block pictures, span for inline ones)  >  box  >  img + React layer.
    `dom` belongs to ProseMirror and to the page layout (which gives it position / left / top / width through a node decoration), so this code
    NEVER writes dom.style. Everything this code styles lives on `box` / `img`. (Writing dom.style used to wipe the layout's position, which threw
    the picture out of place and on top of the text as soon as it was tapped.)

    Moving: dragging a picture no longer shifts it by a free offset (that always ended on top of the text). The picture is dropped between blocks
    and the side it is dropped on (left / centre / right third) sets its alignment; the text then flows around it (see pagedLayout.js). */
export function createImageNodeView({ node: first, editor, getPos, block = false }) {
  let node = first; let selected = false;
  const dom = document.createElement(block ? 'figure' : 'span'); dom.setAttribute('contenteditable', 'false');
  dom.className = block ? 'word-img word-img-fig' : 'word-img word-img-inl';
  if (block) dom.setAttribute('data-note-picture', '');
  const box = document.createElement('span'); box.className = 'wi-box'; dom.appendChild(box);
  const img = document.createElement('img'); img.draggable = false; box.appendChild(img);
  const ui = document.createElement('span'); ui.style.display = 'contents'; box.appendChild(ui);
  const root = createRoot(ui);

  const layoutState = () => editor.storage.pagedLayout;
  const relayout = () => { try { editor.view.dispatch(editor.view.state.tr.setMeta('relayout', true).setMeta('addToHistory', false)); } catch (e) { /* ignore */ } };
  // the width a "100%" picture has: one column of the page layout, or the width of the text
  const availW = () => { const cfg = layoutState()?.cfg; return cfg ? cfg.colW : (editor.view.dom.clientWidth || 600); };
  const widthCss = (w) => (typeof w === 'number' ? `${w}px` : /%$/.test(w || '') ? `${Math.round((availW() * parseFloat(w)) / 100)}px` : (w || ''));

  const paint = () => {
    const a = node.attrs; const show = selected && editor.isEditable; const freeH = a.height && a.lock === false;
    const al = ALIGNS.includes(a.align) ? a.align : 'inline';
    // alignment classes (css in index.css): inline pictures float on `dom` (they sit in a paragraph), block pictures on `box`
    ALIGNS.forEach((k) => { (block ? box : dom).classList.toggle(`wi-${k}`, k === al); (block ? dom : box).classList.remove(`wi-${k}`); });
    (block ? box : dom).style.setProperty('--wi-dx', `${Math.max(0, Number(a.dx) || 0)}px`);
    img.alt = a.alt || '';
    if (img.getAttribute('src') !== (a.src || '')) img.setAttribute('src', a.src || '');
    img.style.cssText = `width:${widthCss(a.width)};max-width:100%;height:${freeH ? a.height : 'auto'};${freeH ? 'object-fit:fill;' : ''}display:block;${a.border ? 'border:1.5px solid #000000;box-sizing:border-box;' : ''}outline:${show ? '2px solid #3b82f6' : 'none'};outline-offset:1px;touch-action:${show ? 'none' : 'auto'};`;
  };
  const renderUI = () => root.render(<ImageOverlay a={node.attrs} show={selected && editor.isEditable} ctl={ctl} />);
  img.onerror = () => {
    if (dom.querySelector('.img-err')) return;
    const m = document.createElement('span'); m.className = 'img-err'; m.style.cssText = 'display:block;font-size:12px;font-style:italic;color:#b91c1c;border:1px dashed #b91c1c;padding:6px';
    m.textContent = 'This picture could not be shown. Add it again.'; box.insertBefore(m, ui);
  };
  img.onload = () => { const m = dom.querySelector('.img-err'); if (m) m.remove(); };

  const updateAttributes = (v) => {
    const pos = getPos(); if (typeof pos !== 'number') return;
    editor.view.dispatch(editor.view.state.tr.setNodeMarkup(pos, undefined, { ...node.attrs, ...v }));
  };
  const deleteNode = () => { const pos = getPos(); if (typeof pos === 'number') editor.view.dispatch(editor.view.state.tr.delete(pos, pos + node.nodeSize)); };
  const select = () => { try { const p = getPos(); if (typeof p === 'number' && editor.state.doc.nodeAt(p)?.type === node.type) { editor.commands.setNodeSelection(p); editor.view.dom.blur(); } } catch (e) { /* the picture was moved */ } };

  /* ---------- moving: find the block under the finger, show where the picture will land, drop it there ---------- */
  let guide = null; let suppressClick = false;
  const hideGuide = () => { if (guide) { guide.remove(); guide = null; } };
  const dropInfo = (x, y) => {
    const view = editor.view; let hit = null;
    box.style.pointerEvents = 'none';                       // so the picture itself is not what we find under the finger
    try { hit = view.posAtCoords({ left: x, top: y }); } catch (e) { /* ignore */ }
    box.style.pointerEvents = '';
    if (!hit) return null;
    const doc = view.state.doc; const $h = doc.resolve(hit.pos);
    const start = $h.depth >= 1 ? $h.before(1) : hit.pos; const nd = doc.nodeAt(start); if (!nd) return null;
    const el = view.nodeDOM(start); const r = el && el.getBoundingClientRect ? el.getBoundingClientRect() : null; if (!r || !r.width) return null;
    return { start, nd, r, after: y > r.top + r.height / 2 };
  };
  // where the dragged picture is, found from the picture itself (its top edge decides the row, its left edge the sideways position)
  const dropFor = (pr, fx, fy) => dropInfo(pr.left + pr.width / 2, pr.top + 2) || dropInfo(fx, fy);
  const showGuide = (d) => {
    if (!d) { hideGuide(); return; }
    if (!guide) { guide = document.createElement('div'); guide.className = 'no-print'; document.body.appendChild(guide); }
    guide.style.cssText = `position:fixed;pointer-events:none;z-index:99999;height:4px;border-radius:2px;background:#3b82f6;box-shadow:0 0 0 2px rgba(59,130,246,.35);left:${d.r.left}px;width:${d.r.width}px;top:${(d.after ? d.r.bottom : d.r.top) - 2}px;`;
  };
  /* The picture stays exactly where it was dropped, sideways: its distance from the left or right edge of the column is kept (dx) and the text
     flows into the room on the other side. Up and down it lands on the nearest line of the text (the text cannot be under it). */
  const placeFor = (d, pr) => {
    const cfg = layoutState()?.cfg; const view = editor.view; const w = box.offsetWidth || 1;
    let colWd; let ox;
    if (cfg) {
      const sr = view.dom.getBoundingClientRect(); const sc = sr.width / cfg.W || 1;
      const cx = (pr.left + pr.width / 2 - sr.left) / sc;
      const idx = cfg.cols > 1 ? clamp2(Math.floor((cx - cfg.mL) / (cfg.colW + cfg.gap)), 0, cfg.cols - 1) : 0;
      colWd = cfg.cols > 1 ? cfg.colW : cfg.fullW; ox = (pr.left - sr.left) / sc - (cfg.mL + idx * (cfg.colW + cfg.gap));
    } else { const sc = pr.width / w || 1; colWd = d.r.width / sc; ox = (pr.left - d.r.left) / sc; }
    if (colWd - w - 16 < 120) return { align: 'inline', dx: 0 };                          // no room beside it: own rows
    if (Math.abs(ox + w / 2 - colWd / 2) < colWd * 0.07) return { align: 'center', dx: 0 };
    const maxOff = Math.max(0, colWd - w - 16 - 120);
    return ox + w / 2 < colWd / 2 ? { align: 'left', dx: Math.round(clamp2(ox, 0, maxOff)) } : { align: 'right', dx: Math.round(clamp2(colWd - ox - w, 0, maxOff)) };
  };
  const commitMove = (d, pr) => {
    if (!d) return;
    const view = editor.view; const st = view.state; const from = getPos(); if (typeof from !== 'number') return;
    const next = { ...node.attrs, ...placeFor(d, pr), dy: 0 };
    const $f = st.doc.resolve(from); const ownStart = $f.depth >= 1 ? $f.before(1) : from;
    const ownEnd = ownStart + (st.doc.nodeAt(ownStart)?.nodeSize || node.nodeSize);
    const at = d.after ? d.start + d.nd.nodeSize : d.start;
    if (d.start === ownStart || at === ownStart || at === ownEnd) { updateAttributes({ align: next.align, dx: next.dx, dy: 0 }); return; }   // same row: only the side changes
    const tr = st.tr;
    const sole = !block && $f.depth === 1 && $f.parent.type.name === 'paragraph' && $f.parent.childCount === 1;
    if (sole) tr.delete($f.before(), $f.after()); else tr.delete(from, from + node.nodeSize);
    const to = tr.mapping.map(at, 1);
    tr.insert(to, block ? node.type.create(next) : st.schema.nodes.paragraph.create(null, node.type.create(next)));
    try { tr.setSelection(NodeSelection.create(tr.doc, block ? to : to + 1)); } catch (e) { /* ignore */ }
    view.dispatch(tr);
  };
  const startMove = (e) => {
    if (!editor.isEditable || (e.button !== undefined && e.button > 0)) return;
    const show = selected && editor.isEditable;
    if (e.pointerType === 'touch' && !show) return;           // first tap selects, then a drag moves
    const x0 = e.clientX; const y0 = e.clientY; let moved = false; let drop = null; let ghost = null; let lastPr = null;
    const limit = e.pointerType === 'touch' ? 10 : 5;         // a tap with a little finger wobble must not move the picture
    const t = e.currentTarget; try { t.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    const move = (ev) => {
      if (!moved && Math.hypot(ev.clientX - x0, ev.clientY - y0) < limit) return;
      if (!moved) {
        moved = true; select(); box.style.opacity = '.3';                       // the picture stays in its place; only a small ghost follows the finger, so nothing is ever covered
        ghost = document.createElement('img'); ghost.src = img.src; ghost.className = 'no-print';
        ghost.style.cssText = 'position:fixed;z-index:99998;pointer-events:none;width:72px;height:auto;max-height:90px;object-fit:contain;opacity:.85;border-radius:6px;box-shadow:0 4px 14px rgba(0,0,0,.35);background:#fff';
        document.body.appendChild(ghost);
      }
      ghost.style.left = `${ev.clientX - 36}px`; ghost.style.top = `${ev.clientY - 36}px`;
      // where the picture would land: the same sideways distance from the column edge as the finger has moved
      const r0 = box.getBoundingClientRect(); const pr = { left: r0.left + (ev.clientX - x0), top: r0.top + (ev.clientY - y0), width: r0.width, height: r0.height };
      lastPr = pr; drop = dropFor(pr, ev.clientX, ev.clientY); showGuide(drop);
    };
    const end = (ev, commit) => {
      const pr = lastPr || box.getBoundingClientRect();         // where the picture would land
      t.removeEventListener('pointermove', move); t.removeEventListener('pointerup', up); t.removeEventListener('pointercancel', cancel);
      box.style.opacity = ''; if (ghost) { ghost.remove(); ghost = null; } hideGuide();
      if (moved) { suppressClick = true; setTimeout(() => { suppressClick = false; }, 400); if (commit) commitMove(dropFor(pr, ev.clientX, ev.clientY) || drop, pr); }
    };
    const up = (ev) => end(ev, true);
    const cancel = (ev) => end(ev, false);
    t.addEventListener('pointermove', move); t.addEventListener('pointerup', up); t.addEventListener('pointercancel', cancel);
  };

  /* ---------- resizing. dx/dy are -1, 0 or 1: which edges this handle moves. Corners keep the ratio while "lock" is on.
     The page layout is paused while the handle is held, so the picture can not jump to another column or page under the finger;
     it is laid out once, when the finger lifts. ---------- */
  const startResize = (dx, dy) => (e) => {
    e.preventDefault(); e.stopPropagation();
    const el = img; const rect = el.getBoundingClientRect();
    const scale = rect.width / el.offsetWidth || 1;
    const a = node.attrs; const x0 = e.clientX; const y0 = e.clientY; const w0 = el.offsetWidth; const h0 = el.offsetHeight; const target = e.currentTarget;
    const locked = a.lock !== false; const corner = dx !== 0 && dy !== 0;
    const kx = a.align === 'center' ? 2 : 1;                  // a centred picture grows on both sides, so the handle follows the finger
    const st = layoutState(); if (st) st.hold = true;
    try { target.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    const calc = (ev) => {
      let w = w0 + (kx * dx * (ev.clientX - x0)) / scale; let h = h0 + (dy * (ev.clientY - y0)) / scale;
      if (locked) { if (dx !== 0) { h = (w * h0) / w0; } else { w = (h * w0) / h0; } }
      return [Math.max(30, Math.round(w)), Math.max(30, Math.round(h))];
    };
    const move = (ev) => {
      const [w, h] = calc(ev);
      if (dx !== 0 || locked) el.style.width = `${w}px`;
      if (dy !== 0 || locked) el.style.height = locked ? 'auto' : `${h}px`;
      if (!locked && dy !== 0) el.style.objectFit = 'fill';
    };
    const release = () => { target.removeEventListener('pointermove', move); target.removeEventListener('pointerup', up); target.removeEventListener('pointercancel', cancel); if (st) st.hold = false; };
    const up = (ev) => {
      release();
      const [w, h] = calc(ev);
      if (locked) updateAttributes({ width: `${w}px`, height: null });
      else updateAttributes({ width: dx !== 0 || corner ? `${w}px` : (a.width || `${w0}px`), height: dy !== 0 || corner ? `${h}px` : (a.height || `${h0}px`) });
    };
    const cancel = () => { release(); paint(); relayout(); };
    target.addEventListener('pointermove', move); target.addEventListener('pointerup', up); target.addEventListener('pointercancel', cancel);
  };

  const ctl = {
    block, updateAttributes, deleteNode, startResize,
    download: async () => {
      const a = node.attrs; const blob = await (await fetch(a.src)).blob();
      const ext = (blob.type.split('/')[1] || 'png').replace('svg+xml', 'svg');
      saveBlob(`${(a.alt || 'image').replace(/[^\w-]+/g, '_')}.${ext}`, blob);
    },
    replace: async (e) => { const f = e.target.files?.[0]; if (f) updateAttributes({ src: await readAsDataUrl(f), width: null, height: null }); e.target.value = ''; },
    rotate: async (deg) => updateAttributes({ src: await rotateDataUrl(node.attrs.src, deg), width: null, height: null }),
    sizePct: (p) => updateAttributes({ width: `${p}%`, height: null }),
  };

  img.addEventListener('pointerdown', startMove);
  dom.addEventListener('click', () => { if (suppressClick) { suppressClick = false; return; } select(); });
  paint(); renderUI();
  return {
    dom,
    update: (n) => { if (n.type !== node.type) return false; node = n; paint(); renderUI(); return true; },
    selectNode: () => { selected = true; paint(); renderUI(); },
    deselectNode: () => { selected = false; paint(); renderUI(); },
    stopEvent: (ev) => ui.contains(ev.target),
    ignoreMutation: () => true,
    destroy: () => { hideGuide(); const st = layoutState(); if (st) st.hold = false; setTimeout(() => root.unmount(), 0); },
  };
}
