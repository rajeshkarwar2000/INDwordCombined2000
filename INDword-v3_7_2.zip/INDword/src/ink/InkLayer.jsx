import { useEffect, useLayoutEffect, useReducer, useRef, useState } from 'react';
import { createPortal, flushSync } from 'react-dom';
import { Copy, ArrowUpToLine, ArrowDownToLine, Trash2, Crop, RotateCcw, RotateCw, FlipHorizontal2, FlipVertical2, RefreshCw, Download, Undo2 } from 'lucide-react';
import { CropDialog } from '../components/ImageView.jsx';
import { saveBlob } from '../services/exporters.js';
import { rotateInkImage, flipInkImage, cropInkImage, replaceInkImage, sizeInkImage, resetInkImage, dataUrlToBlob } from './images.js';
import R, { UNIT } from './render.js';
import { uid } from './engine.js';
import { recognize, snapAngle } from './recognize.js';
import { PenTracker, polishStroke, roundKinks } from './penTracker.js';

/* low-latency canvases (the stroke being drawn skips the usual wait for the screen refresh, like the front buffer of iPad ink) */
const ctx2 = (c, blend) => (blend ? c.getContext('2d') : c.getContext('2d', { desynchronized: true }));


const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const bboxCache = new WeakMap();
const bboxOf = (o) => { let b = bboxCache.get(o); if (!b) { b = R.bbox(o); bboxCache.set(o, b); } return b; };
// does object o (plus its soft edges / glow) reach the ink-unit rectangle?
const reaches = (o, lx, ly, hx, hy) => { const b = bboxOf(o), m = 40 + (o.t === 's' ? o.size * 1.2 : 0); return !(b.x - m > hx || b.x + b.w + m < lx || b.y - m > hy || b.y + b.h + m < ly); };

const CELL_PX = 1024;   // a drawing tile is at most about 1024 x 1024 canvas pixels, so any zoom level can be drawn sharply
const HOLD_MS = 550;    // keep the pen still this long at the end of a stroke to turn it into a clean shape

/* ---------------------------------------------------------------- one drawing tile (a part of one page) */
// kind 'base': pen, brush, shapes, pictures.   kind 'hl': highlighter strokes (their layer is multiplied onto the text underneath)
// Only the tiles near the screen exist. Their resolution follows the zoom, so ink stays sharp when you zoom in.
function Tile({ engine, kind, rkey, x0, y0, cw, ch, sc, reg, eager }) {
  const cv = useRef(null);
  const [has, setHas] = useState(kind === 'base');
  const raf = useRef(0);
  const bw = Math.max(1, Math.round(cw * sc)), bh = Math.max(1, Math.round(ch * sc));

  const paint = () => {
    raf.current = 0;
    const c = cv.current; if (!c) return;
    const lx = x0 / UNIT, hx = (x0 + cw) / UNIT, ly = y0 / UNIT, hy = (y0 + ch) / UNIT;
    const pv = engine.preview; let any = false;
    const items = [];
    for (const o0 of engine.objs) {
      const o = pv && pv.id === o0.id ? pv.o : o0;
      if (R.isHl(o) !== (kind === 'hl')) continue;
      if (!reaches(o, lx, ly, hx, hy)) continue;
      items.push(o); any = true;
    }
    if (kind === 'hl' && any !== has) { setHas(any); if (!has && !eager) return; }
    const ctx = c.getContext('2d'); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, c.width, c.height);
    if (c.width <= 1) return;
    const cpp = c.width / cw, k = cpp * UNIT;
    ctx.setTransform(k, 0, 0, k, -x0 * cpp, -y0 * cpp); ctx.imageSmoothingQuality = 'high';
    for (const o of items) { if (kind === 'hl') R.drawStroke(ctx, o, 0, null, true); else R.drawObj(ctx, o); }
  };
  const sched = () => { if (!raf.current) raf.current = requestAnimationFrame(paint); };
  // draw one new object on top of what is already there (no repaint of the whole tile)
  const add = (o) => {
    const c = cv.current; if (!c || R.isHl(o) !== (kind === 'hl')) return;
    if (c.width <= 1) { paint(); return; }
    if (!reaches(o, x0 / UNIT, y0 / UNIT, (x0 + cw) / UNIT, (y0 + ch) / UNIT)) return;
    const cpp = c.width / cw, ctx = c.getContext('2d'); ctx.setTransform(cpp * UNIT, 0, 0, cpp * UNIT, -x0 * cpp, -y0 * cpp);
    if (kind === 'hl') R.drawStroke(ctx, o, 0, null, true); else R.drawObj(ctx, o);
  };
  const paintRef = useRef(paint); paintRef.current = paint;
  const addRef = useRef(add); addRef.current = add;
  useEffect(() => {
    const un = engine.subscribe((k) => { if (k !== 'add') sched(); });
    reg.set(rkey, { paint: () => { if (raf.current) { cancelAnimationFrame(raf.current); raf.current = 0; } paintRef.current(); }, add: (o) => addRef.current(o) });
    return () => { un(); reg.delete(rkey); cancelAnimationFrame(raf.current); raf.current = 0; };
  }, [engine, rkey]); // eslint-disable-line react-hooks/exhaustive-deps
  useLayoutEffect(() => { paint(); }, [bw, bh, has, eager, x0, y0, cw, ch]); // eslint-disable-line react-hooks/exhaustive-deps

  const on = has || !!eager;
  return <canvas ref={cv} width={on ? bw : 1} height={on ? bh : 1} style={{ position: 'absolute', left: x0, top: y0, width: cw, height: ch, pointerEvents: 'none' }} />;
}

/* ---------------------------------------------------------------- the layer */
export default function InkLayer({ engine, tool, cfg, fingerDraw, W, H, gap, pageCount, zoom, scroller, hlBlend = 'multiply', onFlash, onPickColor }) {
  const pitch = H + gap, totalH = pageCount * pitch - gap;
  const layer = useRef(null), live = useRef(null), liveHl = useRef(null), liveTail = useRef(null), laserCv = useRef(null), lastU = useRef(1);
  const [, bump] = useReducer((x) => x + 1, 0);
  const [selId, setSelId] = useState(null);
  const [cells, setCells] = useState(null);
  const reg = useRef(new Map()).current;
  const dpr = Math.min(window.devicePixelRatio || 1, 3);
  // canvas pixels per css pixel: exactly the screen's resolution at this zoom (so ink is as sharp as the text), up to 16x; lower while exporting
  const scWant = Math.max(1, Math.min(Math.round(dpr * zoom * 10) / 10, 16));
  const sc = engine.forceAll ? Math.min(2, scWant) : scWant;

  const S = useRef({}); S.current = { tool, cfg, fingerDraw, W, H, pitch, totalH, zoom, selId, hlBlend, sc, pageCount };

  useEffect(() => { engine.relayout(pitch); }, [engine, pitch]);
  useEffect(() => engine.subscribe((k) => {
    if (engine.pendingSelect) { const id = engine.pendingSelect; if (engine.objs.some((o) => o.id === id)) { engine.pendingSelect = null; setSelId(id); S.current.selId = id; bump(); return; } }
    if (k === 'force') { bump(); syncCells(false); return; }
    const id = S.current.selId; if (id) { if (!engine.objs.some((o) => o.id === id)) setSelId(null); bump(); }
  }), [engine]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (tool !== 'select') setSelId(null); }, [tool]);

  /* ---------- which part of the layer is on screen (css px of the layer) ---------- */
  const viewWin = (mx, my) => {
    const s = scroller?.current, l = layer.current; if (!s || !l) return null;
    const sr = s.getBoundingClientRect(), lr = l.getBoundingClientRect(); if (!lr.width) return null;
    const z = lr.width / S.current.W, ax = (sr.width * mx) / z, ay = (sr.height * my) / z;
    return { x0: (sr.left - lr.left) / z - ax, x1: (sr.right - lr.left) / z + ax, y0: (sr.top - lr.top) / z - ay, y1: (sr.bottom - lr.top) / z + ay };
  };
  const calcCells = () => {
    const { W: w, H: h, pitch: pt, pageCount: pc, sc: s } = S.current;
    const cell = CELL_PX / s, cols = Math.max(1, Math.ceil(w / cell)), rows = Math.max(1, Math.ceil(h / cell)), cw = w / cols, ch = h / rows;
    const win = engine.forceAll ? null : viewWin(0.3, 0.45);
    const list = [];
    for (let t = 0; t < pc; t++) {
      const top = t * pt; if (win && (top + h < win.y0 || top > win.y1)) continue;
      for (let r = 0; r < rows; r++) {
        const y = top + r * ch; if (win && (y + ch < win.y0 || y > win.y1)) continue;
        for (let c = 0; c < cols; c++) { const x = c * cw; if (win && (x + cw < win.x0 || x > win.x1)) continue; list.push([t, c, r]); }
      }
    }
    return { sig: `${s}|${cols}x${rows}|${w}x${h}|${list.map((q) => q.join('.')).join(',')}`, grid: `${s}-${cols}x${rows}`, list, cw, ch, sc: s };
  };
  // When the zoom changes the tiles are replaced by sharper ones. The old tiles stay underneath for a moment, so the page never flashes blank while the new canvases are being put on screen.
  const cellsRef = useRef(null), prevT = useRef(0);
  const [prev, setPrev] = useState(null);
  const syncCells = (now) => {
    const next = calcCells(), cur = cellsRef.current; if (cur && cur.sig === next.sig) return;
    const apply = () => {
      if (cur && cur.grid !== next.grid) { setPrev(cur); clearTimeout(prevT.current); prevT.current = setTimeout(() => setPrev(null), 260); }
      cellsRef.current = next; setCells(next);
    };
    if (now) flushSync(apply); else apply();
  };
  useLayoutEffect(() => { syncCells(false); }, [W, H, pitch, pageCount, sc, zoom]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const s = scroller?.current; if (!s) return undefined;
    let raf = 0;
    const upd = () => { raf = 0; if (s.dataset.pinching) return; syncCells(false); };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(upd); };
    const onSync = () => { if (raf) { cancelAnimationFrame(raf); raf = 0; } syncCells(true); }; // zoom just changed: draw the new tiles before the screen is painted
    s.addEventListener('scroll', onScroll, { passive: true }); s.addEventListener('ink-sync', onSync);
    const ro = new ResizeObserver(onScroll); ro.observe(s);
    return () => { s.removeEventListener('scroll', onScroll); s.removeEventListener('ink-sync', onSync); ro.disconnect(); cancelAnimationFrame(raf); };
  }, [scroller, engine]); // eslint-disable-line react-hooks/exhaustive-deps

  /* ---------- coordinates ---------- */
  const rectRef = useRef(null);
  const toInk = (e) => {
    const r = (st.cur && rectRef.current) || layer.current.getBoundingClientRect(), cssU = r.width / S.current.W;
    return { x: (e.clientX - r.left) / cssU / UNIT, y: (e.clientY - r.top) / cssU / UNIT, u: cssU * UNIT, cssU };
  };
  const pres = (e) => (e.pointerType === 'pen' && e.pressure > 0 ? e.pressure : 0.5);

  /* ---------- live canvas (the stroke being drawn): covers the screen plus a margin, at full zoom resolution ---------- */
  const lv = useRef({ left: 0, top: 0, cpp: 1, cv: null, idle: 0 });
  // The live canvases stay allocated between strokes (allocating a big canvas at every pen-down made strokes start late) and are released after a short pause.
  const openLive = (yInk, hl) => {
    const cv = hl ? liveHl.current : live.current, tail = liveTail.current, { W: w, totalH: tot, sc: s } = S.current; if (!cv) return null;
    clearTimeout(lv.current.idle);
    const win = viewWin(0.2, 0.2);
    let left = 0, top = 0, lw = w, lh = tot;
    if (win) { lw = Math.min(w, win.x1 - win.x0); lh = Math.min(tot, win.y1 - win.y0); left = clamp(win.x0, 0, Math.max(0, w - lw)); top = clamp(win.y0, 0, Math.max(0, tot - lh)); }
    else { lh = Math.min(tot, 1600); top = clamp(yInk * UNIT - 800, 0, Math.max(0, tot - lh)); }
    left = Math.floor(left * s) / s; top = Math.floor(top * s) / s;
    const pw = Math.max(1, Math.round(lw * s)), ph = Math.max(1, Math.round(lh * s));
    [cv, tail].forEach((c) => {
      if (!c) return;
      if (c.width !== pw || c.height !== ph) { c.width = pw; c.height = ph; } else if (c.width > 1) ctx2(c, c === liveHl.current).clearRect(0, 0, c.width, c.height);
      c.style.left = `${left}px`; c.style.top = `${top}px`; c.style.width = `${lw}px`; c.style.height = `${lh}px`;
    });
    lv.current = { ...lv.current, left, top, cpp: pw / lw, cv };
    return ctx2(cv, hl);
  };
  const setT = (c) => { const { left, top, cpp } = lv.current, x = ctx2(c, c === liveHl.current); x.setTransform(cpp * UNIT, 0, 0, cpp * UNIT, -left * cpp, -top * cpp); return x; };
  const liveCtx = () => setT(lv.current.cv);
  const tailCtx = () => setT(liveTail.current);
  const closeLive = () => {
    [live.current, liveHl.current, liveTail.current].forEach((c) => { if (c && c.width > 1) { const x = ctx2(c, c === liveHl.current); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, c.width, c.height); } });
    if (liveHl.current) liveHl.current.style.opacity = '';
    clearTimeout(lv.current.idle);
    lv.current.idle = setTimeout(() => { [live.current, liveHl.current, liveTail.current].forEach((c) => { if (c) { c.width = 1; c.height = 1; } }); }, 20000);
  };
  const paintAll = () => reg.forEach((e) => e.paint());
  const addAll = (o) => reg.forEach((e) => e.add(o));

  /* ---------- input ---------- */
  const st = useRef({ cur: null, touches: new Map(), pinch: false, lastPen: 0, raf: 0, vel: { vx: 0, vy: 0, t: 0 }, pan: { x: 0, y: 0, raf: 0 }, fling: 0, lastTap: 0, laser: { strokes: [], cur: null, raf: 0 } }).current;

  useEffect(() => {
    const el = layer.current; if (!el || !tool) return undefined;
    const sc0 = () => scroller?.current;
    if (['pen', 'brush', 'highlighter', 'eraser', 'shapes'].includes(tool)) { openLive(0, tool === 'highlighter'); closeLive(); } // allocate the live canvases now, so the first stroke starts without delay
    const cap = (id) => { try { el.setPointerCapture(id); } catch { /* released pointer */ } };

    const applyPan = () => { st.pan.raf = 0; const s = sc0(); if (s) { s.scrollLeft -= st.pan.x; s.scrollTop -= st.pan.y; } st.pan.x = st.pan.y = 0; };
    const flingStop = () => { if (st.fling) { cancelAnimationFrame(st.fling); st.fling = 0; } };
    const doFling = () => {
      flingStop(); let last = performance.now();
      const tick = (t) => {
        const dt = Math.min(40, t - last); last = t; const s = sc0(); if (!s) return;
        s.scrollLeft -= st.vel.vx * dt; s.scrollTop -= st.vel.vy * dt;
        const f = Math.exp(-dt / 330); st.vel.vx *= f; st.vel.vy *= f;
        st.fling = Math.hypot(st.vel.vx, st.vel.vy) > 0.02 ? requestAnimationFrame(tick) : 0;
      };
      st.fling = requestAnimationFrame(tick);
    };

    /* ===== pointer down ===== */
    const down = (e) => {
      if (e.target.closest && e.target.closest('[data-inkui]')) return;
      flingStop();
      const { fingerDraw: fd } = S.current;
      if (e.pointerType === 'pen') st.lastPen = performance.now();
      if (e.pointerType === 'touch') {
        if (!fd && performance.now() - st.lastPen < 700) return; // palm rejection
        // a stroke is being written: a second finger or a palm is ignored (no pinch, no pan, no cancelled or bent stroke).
        // A pen stroke ignores every touch; a finger stroke ignores a second finger once it has really started moving (a pinch starts with both fingers almost still).
        if (st.cur && st.cur.s && !st.pinch && (st.cur.pt === 'pen' || st.cur.s.pts.length > 12)) return;
        st.touches.set(e.pointerId, { x: e.clientX, y: e.clientY }); st.vel.vx = st.vel.vy = 0; st.vel.t = 0;
        if (st.touches.size >= 2) { cancelDraw(); st.pinch = true; return; }
        if (!fd) { cap(e.pointerId); return; }
      }
      if (st.touches.size >= 2) return;
      let t = S.current.tool;
      if (e.pointerType === 'pen' && (e.buttons & 32 || e.button === 5)) t = 'eraser';
      cap(e.pointerId);
      if (t === 'laser') { beginLaser(e); return; }
      begin(t, e);
    };

    const begin = (t, e) => {
      const p = toInk(e), c = S.current.cfg[t] || {};
      st.cur = { tool: t, id: e.pointerId, pt: e.pointerType, u: p.u, x0: p.x, y0: p.y, moved: false, q: [], c0: { x: e.clientX, y: e.clientY, t: e.timeStamp || performance.now() } };
      rectRef.current = layer.current.getBoundingClientRect();
      const cur = st.cur;
      if (t === 'pen' || t === 'brush' || t === 'highlighter') {
        const kind = t === 'highlighter' ? 'hl' : t;
        const s = { id: uid(), t: 's', tool: kind, pts: [[p.x, p.y, pres(e)]], size: c.size, color: c.color, seed: (Math.random() * 1e9) | 0 };
        if (t === 'pen') Object.assign(s, { pen: c.pen, line: c.line, space: c.space, nib: c.nib, angle: c.angle });
        if (t === 'brush') s.brush = c.brush;
        if (t === 'highlighter') { s.alpha = c.alpha; s.tip = c.tip || 'round'; s.straight = !!c.straight; }
        cur.s = s; cur.st = R.newStrokeState(s); cur.drawn = 0;
        openLive(p.y, t === 'highlighter'); // nothing is drawn until the pen moves: no dot at the start of a stroke
        if (t !== 'highlighter' && c.hold !== false) cur.hold = { x: e.clientX, y: e.clientY, tm: setTimeout(holdFire, HOLD_MS) };
      } else if (t === 'eraser') {
        openLive(p.y, false); cur.pushed = false; eraseAt(p); drawEraserCursor(p);
      } else if (t === 'select') selectDown(p);
      else if (t === 'shapes') { cur.x1 = p.x; cur.y1 = p.y; cur.x2 = p.x; cur.y2 = p.y; openLive(p.y, false); }
    };

    /* ===== move ===== */
    const move = (e) => {
      if (st.dead === e.pointerId) return; // this pointer's stroke was ended by the jump guard: it must not pan or draw until it lifts
      if (e.pointerType === 'touch' && st.touches.has(e.pointerId)) {
        const prev = st.touches.get(e.pointerId); st.touches.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (st.pinch || st.touches.size >= 2) return;
        if (!st.cur) {
          const dx = e.clientX - prev.x, dy = e.clientY - prev.y, now = performance.now(), dt = Math.max(1, now - (st.vel.t || now - 16));
          st.pan.x += dx; st.pan.y += dy; if (!st.pan.raf) st.pan.raf = requestAnimationFrame(applyPan);
          st.vel.vx = st.vel.vx * 0.55 + (dx / dt) * 0.45; st.vel.vy = st.vel.vy * 0.55 + (dy / dt) * 0.45; st.vel.t = now; return;
        }
      }
      const cur = st.cur; if (!cur || cur.id !== e.pointerId) return;
      const evs = (e.getCoalescedEvents && e.getCoalescedEvents()) || [], list = evs.length ? evs : [e];
      if (cur.tool === 'laser') {
        const ls = st.laser.cur, now = performance.now();
        if (ls) {
          for (const ev of list) {
            const q = { x: ev.clientX, y: ev.clientY, t: now };
            if (ls.mode === 'dot') ls.pts = [q]; else { const l = ls.pts[ls.pts.length - 1]; if (Math.hypot(q.x - l.x, q.y - l.y) >= 1.8) ls.pts.push(q); }
          }
          const pe = e.getPredictedEvents && e.getPredictedEvents(); ls.pred = pe && pe.length ? { x: pe[pe.length - 1].clientX, y: pe[pe.length - 1].clientY } : null;
        }
        laserLoop(); return;
      }
      for (const ev of list) step(ev);
      // A short guess of where the ink tip goes next (drawn lighter on the temporary layer only, never stored). PenTracker gives one only while the
      // pen moves smoothly, it follows the curve and it is a few pixels long, so a wrong guess cannot show as a straight line.
      cur.pred = null;
      if (cur.s && cur.s.tool === 'pen' && (!cur.s.line || cur.s.line === 'solid') && !cur.s.straight && !cur.snap && cur.tr && st.cur === cur) {
        const pr = cur.tr.predict(); if (pr) { const k = toInk({ clientX: pr[0], clientY: pr[1] }); cur.pred = [[k.x, k.y]]; }
      }
      drawNow();
    };
    // Draw the line right away instead of waiting for the next animation frame (saves up to one frame between pen and ink). Only for the plain pens, whose live drawing
    // is cheap; if a device is too slow for it, this switches itself off and the normal animation-frame drawing takes over.
    const drawNow = () => {
      const cur = st.cur; if (st.syncOff || !cur || !cur.s || cur.snap || cur.s.straight || cur.s.tool !== 'pen' || (cur.s.line && cur.s.line !== 'solid')) return;
      const t0 = performance.now(); if (st.raf) { cancelAnimationFrame(st.raf); st.raf = 0; }
      liveStroke();
      if (performance.now() - t0 > 8) st.syncOff = true;
    };
    const step = (ev) => {
      const cur = st.cur; if (!cur) return;
      const p = toInk(ev), t = cur.tool;
      if (!cur.moved && Math.hypot(p.x - cur.x0, p.y - cur.y0) * cur.u > 4) cur.moved = true;
      if (cur.snap) { adjustSnap(cur, p); sched(); return; }
      if (cur.hold && Math.hypot(ev.clientX - cur.hold.x, ev.clientY - cur.hold.y) > 5) { cur.hold.x = ev.clientX; cur.hold.y = ev.clientY; clearTimeout(cur.hold.tm); cur.hold.tm = setTimeout(holdFire, HOLD_MS); }
      if (cur.s) {
        const s = cur.s;
        if (s.straight) {
          let x = p.x, y = p.y; const a = s.pts[0], dx = x - a[0], dy = y - a[1], L = Math.hypot(dx, dy);
          if (L > 8 / cur.u) { const ang = Math.abs(Math.atan2(dy, dx)); if (ang < 0.07 || ang > Math.PI - 0.07) y = a[1]; else if (Math.abs(ang - Math.PI / 2) < 0.07) x = a[0]; }
          s.pts = [a, [x, y, 0.5]];
        } else {
          // The first pointer that touched is the focus: only its samples reach this point (the pointer id is checked in move()).
          // PenTracker turns them into stroke points: light jitter filter, speed-aware leash, jump guard (see penTracker.js).
          const tr = cur.tr || (cur.tr = (() => { const k = new PenTracker(cur.u / UNIT); k.seed(cur.c0.x, cur.c0.y, cur.c0.t); return k; })());
          const res = tr.push(ev.clientX, ev.clientY, ev.timeStamp || performance.now());
          if (res.restart) { st.dead = cur.id; finish(cur, false); return; } // the pointer jumped somewhere else for good: end this stroke here, never draw a line across
          if (res.accepted) { cur.rawPrev = cur.raw; cur.raw = p; } // a glitch sample is never remembered as the pen position
          for (const q of res.points) { const k = toInk({ clientX: q[0], clientY: q[1] }); s.pts.push([k.x, k.y, pres(ev)]); }
        }
        sched();
      } else if (t === 'eraser') { cur.q.push(p); sched(); }
      else if (t === 'select') { cur.last = p; sched(); }
      else if (t === 'shapes') { cur.x2 = p.x; cur.y2 = p.y; sched(); }
    };
    const sched = () => { if (!st.raf) st.raf = requestAnimationFrame(frame); };
    const frame = () => {
      st.raf = 0; const cur = st.cur; if (!cur) return; const t = cur.tool;
      if (cur.snap) drawSnap();
      else if (cur.s) liveStroke();
      else if (t === 'eraser') { const q = cur.q; cur.q = []; for (const p of q) eraseAt(p); if (q.length) drawEraserCursor(q[q.length - 1]); }
      else if (t === 'select') { if (cur.last) selectMove(cur.last); }
      else if (t === 'shapes') drawCreating();
    };

    /* ===== up ===== */
    const finish = (cur, pushRaw) => {
      if (st.raf) { cancelAnimationFrame(st.raf); st.raf = 0; }
      cur.pred = null;
      // end of the stroke: take the last real position too (a cancelled pointer has no trustworthy last position, so nothing is added then)
      if (pushRaw && cur.s && !cur.s.straight && cur.raw && cur.s.pts.length > 1) { const l = cur.s.pts[cur.s.pts.length - 1]; if (Math.hypot(cur.raw.x - l[0], cur.raw.y - l[1]) * cur.u > 0.6) cur.s.pts.push([cur.raw.x, cur.raw.y, l[2]]); }
      // once, when the pen is lifted: remove the last small wobbles of the touch panel (about 1.8 screen pixels wide; corners and the two ends stay exactly as written)
      if (cur.s && !cur.polished) { cur.s.pts = smoothPts(cur); cur.polished = true; }   // exactly the points the live line already shows
      frame();
      st.cur = null; stopHold(cur);
      const t = cur.tool;
      if (cur.snap) commitSnap(cur);
      else if (cur.s) commitStroke(cur);
      else if (t === 'eraser') { closeLive(); }
      else if (t === 'laser') { if (st.laser.cur) { st.laser.cur.end = performance.now(); st.laser.cur = null; } }
      else if (t === 'select') selectUp(cur);
      else if (t === 'shapes') commitShape(cur);
    };
    const up = (e) => {
      if (e.pointerType === 'touch') {
        st.touches.delete(e.pointerId);
        if (st.touches.size < 2) st.pinch = st.touches.size > 0 ? st.pinch : false;
        if (!st.cur && st.touches.size === 0 && performance.now() - st.vel.t < 90 && Math.hypot(st.vel.vx, st.vel.vy) > 0.25) doFling();
      }
      if (st.dead === e.pointerId) st.dead = null;
      const cur = st.cur; if (!cur || cur.id !== e.pointerId) return; // only the focus pointer ends the stroke
      finish(cur, e.type !== 'pointercancel');
    };
    const cancelDraw = () => {
      const cur = st.cur; if (!cur) return; st.cur = null; stopHold(cur);
      if (cur.tool === 'laser') { if (st.laser.cur) { st.laser.cur.end = performance.now(); st.laser.cur = null; } return; }
      if (cur.tool === 'select') { engine.preview = null; paintAll(); }
      closeLive();
    };

    // wipe the live canvases after the tiles have certainly been shown (a heavy tile can take a frame or two to reach the screen)
    const closeLiveSoon = () => { requestAnimationFrame(() => requestAnimationFrame(() => { if (!st.cur) closeLive(); })); };

    /* ===== strokes ===== */
    function liveBall() {
      const cur = st.cur, s = cur.s, pts = s.pts, n = pts.length, ctx = liveCtx(), tc = tailCtx();
      if (cur.ci == null) cur.ci = 1;
      // the finished part of the curve: piece k (pts[k-1] -> pts[k]) is final once pts[k+1] exists, and never changes after that
      const lastFin = n - 2;
      if (lastFin >= cur.ci) {
        ctx.save(); ctx.strokeStyle = s.color; ctx.lineWidth = s.size; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.beginPath(); ctx.moveTo(pts[cur.ci - 1][0], pts[cur.ci - 1][1]);
        for (let k = cur.ci; k <= lastFin; k++) R.crSeg(ctx, pts[Math.max(0, k - 2)], pts[k - 1], pts[k], pts[k + 1]);
        ctx.stroke(); ctx.restore(); cur.ci = lastFin + 1;
      }
      // the unfinished last piece lives on its own canvas and is wiped every frame
      const a = pts[n - 2], b = pts[n - 1], p0 = pts[Math.max(0, n - 3)], pad = s.size + 6 + Math.hypot(b[0] - a[0], b[1] - a[1]) * 0.5;
      const pr = cur.pred && cur.pred.length ? cur.pred : null, xs = [a[0], b[0], p0[0], ...(pr ? pr.map((q) => q[0]) : [])], ys = [a[1], b[1], p0[1], ...(pr ? pr.map((q) => q[1]) : [])];
      const bb = [Math.min(...xs) - pad, Math.min(...ys) - pad, Math.max(...xs) + pad, Math.max(...ys) + pad];
      const pv = cur.tb || bb; cur.tb = bb;
      tc.clearRect(Math.min(pv[0], bb[0]) - 2, Math.min(pv[1], bb[1]) - 2, Math.max(pv[2], bb[2]) - Math.min(pv[0], bb[0]) + 4, Math.max(pv[3], bb[3]) - Math.min(pv[1], bb[1]) + 4);
      tc.save(); tc.strokeStyle = tc.fillStyle = s.color; tc.lineWidth = s.size; tc.lineCap = 'round'; tc.lineJoin = 'round';
      tc.beginPath(); tc.moveTo(a[0], a[1]); R.crSeg(tc, p0, a, b, b); tc.stroke();
      if (pr) { tc.globalAlpha = 0.55; tc.beginPath(); tc.moveTo(b[0], b[1]); R.crSeg(tc, a, b, pr[0], pr[0]); tc.stroke(); tc.globalAlpha = 1; }
      tc.restore();
    }
    // Natural / calligraphy pens: same idea as the ball pen. The finished curve goes onto the live canvas, the unfinished last half-segment onto the tail canvas.
    function liveVar() {
      const cur = st.cur, s = cur.s, n = s.pts.length, ctx = liveCtx(), tc = tailCtx();
      cur.st.noTail = true; R.drawStroke(ctx, s, cur.drawn, cur.st, true); cur.drawn = n;
      const pts = s.pts, a = pts[Math.max(0, n - 2)], b = pts[n - 1], p0 = pts[Math.max(0, n - 3)], pr = cur.pred && cur.pred.length ? cur.pred[0] : null;
      const pad = s.size * 2 + 6 + Math.hypot(b[0] - a[0], b[1] - a[1]) * 0.5, xs = [a[0], b[0], p0[0], ...(pr ? [pr[0]] : [])], ys = [a[1], b[1], p0[1], ...(pr ? [pr[1]] : [])];
      const bb = [Math.min(...xs) - pad, Math.min(...ys) - pad, Math.max(...xs) + pad, Math.max(...ys) + pad];
      const pv = cur.tb || bb; cur.tb = bb;
      tc.clearRect(Math.min(pv[0], bb[0]) - 2, Math.min(pv[1], bb[1]) - 2, Math.max(pv[2], bb[2]) - Math.min(pv[0], bb[0]) + 4, Math.max(pv[3], bb[3]) - Math.min(pv[1], bb[1]) + 4);
      R.drawVarTail(tc, s, cur.st, pr);
    }
    // Round highlighter: drawn solid, piece by piece (cheap), and made see-through by the canvas itself, so overlaps never get darker and no frame redraws the whole stroke.
    function liveHlRound() {
      const cur = st.cur, s = cur.s, pts = s.pts, n = pts.length, ctx = liveCtx(), cv = lv.current.cv;
      cv.style.opacity = String(s.alpha == null ? 0.45 : s.alpha);
      if (cur.hi == null) cur.hi = 1;
      ctx.save(); ctx.strokeStyle = s.color; ctx.lineWidth = s.size; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      // finished pieces (final once the next point exists), then the last piece; the pen's own colour is solid here, the canvas makes it see-through
      ctx.beginPath(); ctx.moveTo(pts[cur.hi - 1][0], pts[cur.hi - 1][1]);
      for (let k = cur.hi; k <= n - 1; k++) R.crSeg(ctx, pts[Math.max(0, k - 2)], pts[k - 1], pts[k], pts[Math.min(n - 1, k + 1)]);
      ctx.stroke(); ctx.restore();
      cur.hi = Math.max(cur.hi, n - 1);
    }
    // The smoothed points of the stroke being drawn (the same smoothing is used while writing and when the pen lifts, so the line never changes at the end)
    function smoothPts(cur) { const s = cur.s; return !s.straight && cur.tr && s.pts.length > 4 ? roundKinks(polishStroke(s.pts, 1.8 / cur.u)) : s.pts; }
    const wholePen = (s) => s.tool === 'pen' && !s.straight && (!s.line || s.line === 'solid') && s.pts.length <= 4000;
    // Pens are drawn whole, from the smoothed points, on every frame: what you see while writing is what stays when you lift the pen (no jump, no blink)
    function liveWhole() {
      const cur = st.cur, s = cur.s, pts = cur.polished ? s.pts : smoothPts(cur), ctx = liveCtx();
      const bb = [1e9, 1e9, -1e9, -1e9], pad = s.size * 2 + 8;
      for (const q of pts) { if (q[0] < bb[0]) bb[0] = q[0]; if (q[1] < bb[1]) bb[1] = q[1]; if (q[0] > bb[2]) bb[2] = q[0]; if (q[1] > bb[3]) bb[3] = q[1]; }
      const pv = cur.pb || bb; cur.pb = bb.slice();
      const x0 = Math.min(pv[0], bb[0]) - pad, y0 = Math.min(pv[1], bb[1]) - pad, x1 = Math.max(pv[2], bb[2]) + pad, y1 = Math.max(pv[3], bb[3]) + pad;
      ctx.clearRect(x0, y0, x1 - x0, y1 - y0);
      const s2 = { ...s, pts }; R.drawStroke(ctx, s2, 0, R.newStrokeState(s2), true);
    }
    function liveStroke() {
      const cur = st.cur, s = cur.s;
      if (s.pts.length < 2) return; // a single point is only drawn when the stroke is finished (a tap)
      if (wholePen(s)) { liveWhole(); return; }
      if (s.tool === 'pen' && (s.pen || 'ball') === 'ball' && (!s.line || s.line === 'solid')) { liveBall(); return; }
      if (R.isVarPen(s)) { liveVar(); return; }
      if (s.tool === 'hl' && !s.straight && (s.tip || 'round') === 'round') { liveHlRound(); return; }
      const ctx = liveCtx();
      if (R.isWhole(s)) {
        const bb = cur.bb || (cur.bb = [1e9, 1e9, -1e9, -1e9]), pad = s.size * (s.tool === 'brush' ? 2.2 : 1) + 4;
        for (let i = cur.drawn || 0; i < s.pts.length; i++) { const q = s.pts[i]; if (q[0] < bb[0]) bb[0] = q[0]; if (q[1] < bb[1]) bb[1] = q[1]; if (q[0] > bb[2]) bb[2] = q[0]; if (q[1] > bb[3]) bb[3] = q[1]; }
        const pv = cur.pb || bb; cur.pb = bb.slice();
        const x0 = Math.min(pv[0], bb[0]) - pad, y0 = Math.min(pv[1], bb[1]) - pad, x1 = Math.max(pv[2], bb[2]) + pad, y1 = Math.max(pv[3], bb[3]) + pad;
        ctx.clearRect(x0 - pad * 2, y0 - pad * 2, x1 - x0 + pad * 4, y1 - y0 + pad * 4);
        cur.drawn = s.pts.length; R.drawStroke(ctx, s, 0, null, true); return;
      }
      R.drawStroke(ctx, s, cur.drawn, cur.st, true); cur.drawn = s.pts.length;
    }
    function commitStroke(c) {
      const s = c.s;
      if (s.pts.length === 1 && s.pen) s.pts.push([s.pts[0][0] + 0.01, s.pts[0][1], s.pts[0][2]]);
      engine.push(); engine.set([...engine.objs, s], 'add'); addAll(s); if (c.polished && wholePen(s)) closeLive(); else closeLiveSoon(); // the stroke is drawn onto the tiles and the live copy (identical) is wiped in the same frame: never doubled, never missing
    }

    /* ===== hold to draw a shape: keep the pen still at the end of a stroke and it becomes a clean shape ===== */
    const stopHold = (cur) => { if (cur && cur.hold) { clearTimeout(cur.hold.tm); cur.hold = null; } };
    const snapObj = (cur, sn, id) => {
      const s = cur.s, bw = s.tool === 'brush' ? clamp(s.size * 0.3, 2, 16) : s.size;
      return { id, t: 'shape', kind: sn.kind, x1: sn.x1, y1: sn.y1, x2: sn.x2, y2: sn.y2, ...(sn.qx != null ? { qx: sn.qx, qy: sn.qy } : {}), color: s.color, bw, fill: false, fillColor: null, dash: s.line === 'dotted' ? 'dotted' : s.line === 'dashdot' ? 'dashed' : 'solid', op: 1 };
    };
    function holdFire() {
      const cur = st.cur; if (!cur || !cur.s || cur.snap) return;
      cur.hold = null;
      const r = recognize(cur.s.pts); if (!r) return;
      const hl = (S.current.cfg[cur.tool] || {}).holdLine; if (r.kind === 'line' && (hl === 'arrow' || hl === 'tarrow')) r.kind = hl; else if (r.kind === 'arrow' && hl === 'tarrow') r.kind = 'tarrow'; else if (r.kind === 'carrow' && hl === 'tarrow') r.kind = 'tcarrow';
      const last = cur.s.pts[cur.s.pts.length - 1], cx = (r.x1 + r.x2) / 2, cy = (r.y1 + r.y2) / 2;
      cur.snap = { ...r, hx: last[0], hy: last[1], cx, cy, hw: Math.abs(r.x2 - r.x1) / 2, hh: Math.abs(r.y2 - r.y1) / 2, d0: Math.max(1, Math.hypot(last[0] - cx, last[1] - cy)), moved: false };
      try { if (navigator.vibrate) navigator.vibrate(12); } catch { /* not supported */ }
      sched();
    }
    function adjustSnap(cur, p) { // after the shape appeared, moving the pen resizes it (a line follows the pen)
      const sn = cur.snap;
      if (!sn.moved && Math.hypot(p.x - sn.hx, p.y - sn.hy) * cur.u > 8) sn.moved = true;
      if (!sn.moved) return;
      if (R.isCurved(sn.kind)) return;
      if (R.isLineShape(sn.kind)) { const [ex, ey] = snapAngle(sn.x1, sn.y1, p.x, p.y); sn.x2 = ex; sn.y2 = ey; return; }
      const f = Math.max(0.25, Math.hypot(p.x - sn.cx, p.y - sn.cy) / sn.d0);
      sn.x1 = sn.cx - sn.hw * f; sn.x2 = sn.cx + sn.hw * f; sn.y1 = sn.cy - sn.hh * f; sn.y2 = sn.cy + sn.hh * f;
    }
    function drawSnap() {
      const cur = st.cur, ctx = liveCtx(), tc = tailCtx();
      ctx.clearRect(0, 0, 1e6, 1e6); tc.clearRect(0, 0, 1e6, 1e6);
      R.drawObj(ctx, snapObj(cur, cur.snap, 'snap'));
    }
    function commitSnap(c) {
      const o = snapObj(c, c.snap, uid()); engine.push(); engine.set([...engine.objs, o], 'add'); addAll(o); closeLiveSoon();
    }

    /* ===== eraser ===== */
    const densify = (pts, gapU) => {
      const out = [pts[0]];
      for (let i = 1; i < pts.length; i++) {
        const a = pts[i - 1], b = pts[i], d = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.ceil(d / gapU);
        for (let k = 1; k <= n; k++) { const f = k / n; out.push([a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, (a[2] ?? 0.5) + ((b[2] ?? 0.5) - (a[2] ?? 0.5)) * f]); }
      }
      return out;
    };
    function eraseAt(p) {
      const ec = S.current.cfg.eraser, r = ec.size / 2, out = []; let changed = false;
      for (const o of engine.objs) {
        if (o.t === 'img' || !R.hit(o, p.x, p.y, r)) { out.push(o); continue; } // pictures are removed with the Select tool
        if (ec.mode === 'pixel' && o.t === 's') {
          const lim = r + o.size / 2, dp = densify(o.pts, Math.max(2, o.size / 3)), runs = []; let run = [];
          for (const q of dp) { if (Math.hypot(q[0] - p.x, q[1] - p.y) <= lim) { if (run.length) runs.push(run); run = []; } else run.push(q); }
          if (run.length) runs.push(run);
          if (runs.length === 1 && runs[0].length === dp.length) { out.push(o); continue; }
          runs.forEach((rn) => out.push({ ...o, id: uid(), pts: rn }));
          changed = true;
        } else changed = true;
      }
      if (changed) { if (!st.cur.pushed) { engine.push(); st.cur.pushed = true; } engine.set(out); }
    }
    function drawEraserCursor(p) {
      const cur = st.cur, ctx = liveCtx(), rr = S.current.cfg.eraser.size / 2 + 6;
      if (cur.ec) ctx.clearRect(cur.ec.x - rr, cur.ec.y - rr, rr * 2, rr * 2); else ctx.clearRect(0, 0, 1e5, 1e5);
      cur.ec = { x: p.x, y: p.y };
      ctx.save(); ctx.strokeStyle = 'rgba(60,70,90,.85)'; ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.lineWidth = 2 / (lv.current.cpp * UNIT);
      ctx.beginPath(); ctx.arc(p.x, p.y, S.current.cfg.eraser.size / 2, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); ctx.restore();
    }

    /* ===== laser pointer (screen-space canvas, never saved) ===== */
    // Drawn straight on the screen with a low-latency canvas; only the part that changed is cleared, and the head is drawn where the pen is heading (predicted).
    function beginLaser(e) {
      const lc = S.current.cfg.laser, now = performance.now();
      st.cur = { tool: 'laser', id: e.pointerId };
      const ls = { pts: [{ x: e.clientX, y: e.clientY, t: now }], end: 0, mode: lc.mode === 'delay' ? 'hold' : lc.mode === 'line' ? 'trail' : lc.mode, color: lc.color, size: lc.size, delay: lc.delay, trail: lc.trail || 650, pred: null };
      st.laser.strokes.push(ls); st.laser.cur = ls; laserLoop();
    }
    function laserLoop() {
      const L = st.laser; if (L.raf) return;
      const tick = () => {
        L.raf = 0; const cv = laserCv.current; if (!cv) return;
        const d = Math.min(window.devicePixelRatio || 1, 2), w = window.innerWidth, hh = window.innerHeight;
        if (cv.width !== Math.round(w * d) || cv.height !== Math.round(hh * d)) { cv.width = Math.round(w * d); cv.height = Math.round(hh * d); L.prev = null; }
        const ctx = L.ctx && L.ctxCv === cv ? L.ctx : (L.ctx = cv.getContext('2d', { desynchronized: true }), L.ctxCv = cv, L.ctx);
        const now = performance.now(), keep = [];
        let bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9;
        const grow = (x, y, r) => { if (x - r < bx0) bx0 = x - r; if (y - r < by0) by0 = y - r; if (x + r > bx1) bx1 = x + r; if (y + r > by1) by1 = y + r; };
        // first decide what is still alive and how much screen it covers, then clear only that area
        for (const s of L.strokes) {
          const isDown = !s.end, since = now - s.end;
          if (s.mode === 'dot') { if (!isDown && since > 220) continue; }
          else if (s.mode === 'hold') { const fade = isDown ? 1 : (since - s.delay * 1000 <= 0 ? 1 : 1 - (since - s.delay * 1000) / 650); if (fade <= 0) continue; }
          else { if (!isDown && since > s.trail + 60) continue; while (s.pts.length > 2 && now - s.pts[0].t > s.trail + 60) s.pts.shift(); }
          keep.push(s);
          const pad = s.size * 2.6 + 6;
          if (s.mode === 'dot') { const q = s.pts[s.pts.length - 1]; grow(q.x, q.y, pad); } else for (const q of s.pts) grow(q.x, q.y, pad);
          if (s.pred) grow(s.pred.x, s.pred.y, pad);
        }
        const pv = L.prev;
        let cx0 = bx0, cy0 = by0, cx1 = bx1, cy1 = by1;
        if (pv) { cx0 = Math.min(cx0, pv[0]); cy0 = Math.min(cy0, pv[1]); cx1 = Math.max(cx1, pv[2]); cy1 = Math.max(cy1, pv[3]); }
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        if (cx1 > cx0) ctx.clearRect(Math.floor(cx0 * d) - 2, Math.floor(cy0 * d) - 2, Math.ceil((cx1 - cx0) * d) + 4, Math.ceil((cy1 - cy0) * d) + 4);
        L.prev = keep.length ? [bx0, by0, bx1, by1] : null;
        ctx.setTransform(d, 0, 0, d, 0, 0);
        for (const s of keep) {
          const isDown = !s.end, since = now - s.end, sz = s.size * 0.8;
          const pushed = isDown && s.pred && s.mode !== 'dot'; if (pushed) s.pts.push({ x: s.pred.x, y: s.pred.y, t: now });
          const last = s.pts[s.pts.length - 1];
          if (s.mode === 'dot') {
            R.drawLaser(ctx, [], null, s.color, sz, { head: { x: last.x, y: last.y, a: isDown ? 1 : 1 - since / 220 } });
          } else if (s.mode === 'hold') {
            const fade = isDown ? 1 : (since - s.delay * 1000 <= 0 ? 1 : 1 - (since - s.delay * 1000) / 650);
            R.drawLaser(ctx, s.pts, null, s.color, sz, { alpha: fade, head: null });
          } else {
            const TR = s.trail;
            const al = s.pts.map((q) => { const a = 1 - (now - q.t) / TR; return a <= 0 ? 0 : Math.pow(a, 1.25); });
            R.drawLaser(ctx, s.pts, al, s.color, sz, { taper: true, head: null });
          }
          if (pushed) s.pts.pop();
        }
        L.strokes = keep;
        if (keep.length) L.raf = requestAnimationFrame(tick);
      };
      L.raf = requestAnimationFrame(tick);
    }

    /* ===== shapes ===== */
    const snapLine = (c) => {
      const dx = c.x2 - c.x1, dy = c.y2 - c.y1, L = Math.hypot(dx, dy); if (!L) return;
      const a = Math.atan2(dy, dx), q = Math.PI / 4, n = Math.round(a / q);
      if (Math.abs(a - n * q) < 0.09) { c.x2 = c.x1 + L * Math.cos(n * q); c.y2 = c.y1 + L * Math.sin(n * q); }
    };
    const shapeObj = (c, id) => { const k = S.current.cfg.shapes; return { id, t: 'shape', kind: k.kind, x1: c.x1, y1: c.y1, x2: c.x2, y2: c.y2, color: k.color, bw: k.bw, fill: k.fill, fillColor: k.fillColor || null, dash: k.dash, op: k.op }; };
    function drawCreating() {
      const ctx = liveCtx(), c = st.cur; ctx.clearRect(0, 0, 1e5, 1e5);
      if (R.isLineShape(S.current.cfg.shapes.kind)) snapLine(c);
      R.drawObj(ctx, shapeObj(c));
    }
    function commitShape(c) {
      closeLive();
      if (Math.hypot(c.x2 - c.x1, c.y2 - c.y1) * c.u < 10) { // a tap places a default-size shape
        const d = 220, k = S.current.cfg.shapes.kind, line = R.isLineShape(k);
        c.x1 = Math.max(10, c.x0 - d / 2); c.y1 = c.y0 - d / 2 + (line ? d / 2 : 0); c.x2 = c.x1 + d; c.y2 = line ? c.y1 : c.y1 + d * 0.7;
      } else if (R.isLineShape(S.current.cfg.shapes.kind)) snapLine(c);
      const o = shapeObj(c, uid()); engine.push(); engine.set([...engine.objs, o], 'add'); addAll(o);
    }

    /* ===== select / move / resize ===== */
    const handles = (o) => {
      const b = R.bbox(o), r = Math.max(22, 20 / (lastU.current || 1));
      const line = o.t === 'shape' && R.isLineShape(o.kind);
      return { b, r, del: [b.x + b.w + 8, b.y - 8], size: [b.x + b.w, b.y + b.h], ep: line ? [[o.x1, o.y1], [o.x2, o.y2]] : null };
    };
    function selectDown(p) {
      lastU.current = p.u;
      const cur = st.cur, selO = engine.objs.find((o) => o.id === S.current.selId);
      if (selO) {
        const hd = handles(selO);
        if (Math.hypot(p.x - hd.del[0], p.y - hd.del[1]) <= hd.r) { cur.mode = 'delete'; return; }
        if (hd.ep) for (let i = 0; i < 2; i++) if (Math.hypot(p.x - hd.ep[i][0], p.y - hd.ep[i][1]) <= hd.r) { cur.mode = 'endpoint'; cur.ei = i; cur.o0 = selO; return; }
        if (Math.hypot(p.x - hd.size[0], p.y - hd.size[1]) <= hd.r) { cur.mode = 'resize'; cur.o0 = selO; cur.b0 = R.bbox(selO); return; }
      }
      let hit = null;
      for (let i = engine.objs.length - 1; i >= 0; i--) if (R.hit(engine.objs[i], p.x, p.y, 10 / p.u)) { hit = engine.objs[i]; break; }
      if (!hit) { cur.mode = 'none'; setSelId(null); return; }
      setSelId(hit.id); S.current.selId = hit.id; cur.mode = 'move'; cur.o0 = hit;
    }
    function selectMove(p) {
      const cur = st.cur, m = cur.mode; if (m !== 'move' && m !== 'resize' && m !== 'endpoint') return;
      if (!cur.moved) return;
      const o0 = cur.o0; let o;
      if (m === 'move') o = R.transform(o0, 0, 0, 1, 1, p.x - cur.x0, p.y - cur.y0);
      else if (m === 'endpoint') {
        o = { ...o0 }; const k = cur.ei ? ['x2', 'y2'] : ['x1', 'y1']; o[k[0]] = p.x; o[k[1]] = p.y;
        const dx = o.x2 - o.x1, dy = o.y2 - o.y1, L = Math.hypot(dx, dy), q = Math.PI / 4, n = Math.round(Math.atan2(dy, dx) / q);
        if (L && Math.abs(Math.atan2(dy, dx) - n * q) < 0.09) { if (cur.ei) { o.x2 = o.x1 + L * Math.cos(n * q); o.y2 = o.y1 + L * Math.sin(n * q); } else { o.x1 = o.x2 - L * Math.cos(n * q); o.y1 = o.y2 - L * Math.sin(n * q); } }
      } else {
        const b = cur.b0; let sx = Math.max(0.1, (p.x - b.x) / b.w), sy = Math.max(0.1, (p.y - b.y) / b.h);
        if (o0.t === 's' || o0.t === 'img') sx = sy = Math.max(0.1, (sx + sy) / 2);
        o = R.transform(o0, b.x, b.y, sx, sy, 0, 0);
      }
      cur.cur = o; engine.preview = { id: o0.id, o }; paintAll(); bump();
    }
    function selectUp(c) {
      if (c.mode === 'delete') { if (S.current.selId) engine.remove([S.current.selId]); setSelId(null); paintAll(); return; }
      engine.preview = null;
      if (c.mode === 'none') { paintAll(); return; }
      if (c.moved && c.cur) { engine.replace(c.o0.id, c.cur); paintAll(); bump(); return; }
      paintAll(); bump();
    }

    el.addEventListener('pointerdown', down);
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    const noMenu = (e) => e.preventDefault();
    el.addEventListener('contextmenu', noMenu);
    return () => {
      el.removeEventListener('pointerdown', down); el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', up); el.removeEventListener('contextmenu', noMenu);
      cancelAnimationFrame(st.raf); st.raf = 0; st.cur = null; st.touches.clear(); st.pinch = false; flingStop();
      cancelAnimationFrame(st.pan.raf); st.pan.raf = 0;
      st.laser.strokes = []; st.laser.cur = null; cancelAnimationFrame(st.laser.raf); st.laser.raf = 0; st.laser.prev = null;
      const lc = laserCv.current; if (lc && lc.width > 1) { const c = lc.getContext('2d'); c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, lc.width, lc.height); }
      engine.preview = null; closeLive(); clearTimeout(lv.current.idle);
      [live.current, liveHl.current, liveTail.current].forEach((c) => { if (c) { c.width = 1; c.height = 1; } });
    };
  }, [tool, engine, scroller]); // eslint-disable-line react-hooks/exhaustive-deps

  /* keyboard: Delete removes the selected object */
  useEffect(() => {
    if (tool !== 'select') return undefined;
    const k = (e) => { if ((e.key === 'Delete' || e.key === 'Backspace') && S.current.selId && !/INPUT|TEXTAREA/.test((e.target || {}).tagName || '')) { engine.remove([S.current.selId]); setSelId(null); } };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [tool, engine]);

  /* ---------- selection visuals ---------- */
  const selObj = tool === 'select' && selId ? (engine.preview && engine.preview.id === selId ? engine.preview.o : engine.objs.find((o) => o.id === selId)) : null;
  const [cropO, setCropO] = useState(null); const repl = useRef(null);
  const imgGo = (fn) => async () => { try { await fn(); } catch (e) { /* picture could not be changed */ } };
  let selUi = null;
  if (selObj) {
    const b = R.bbox(selObj), k = UNIT, px = (v) => v * k;
    const line = selObj.t === 'shape' && R.isLineShape(selObj.kind);
    const dot = (x, y, bg, key, ch) => <span key={key} style={{ position: 'absolute', left: px(x) - 11, top: px(y) - 11, width: 22, height: 22, borderRadius: 11, background: bg, border: '2px solid #fff', boxShadow: '0 1px 4px rgba(0,0,0,.4)', color: '#fff', fontSize: 14, lineHeight: '18px', textAlign: 'center', fontWeight: 700 }}>{ch}</span>;
    const barTop = px(b.y + b.h) + 20, flip = barTop + 56 > totalH;
    selUi = (<>
      <div style={{ position: 'absolute', left: px(b.x), top: px(b.y), width: px(b.w), height: px(b.h), border: '2px dashed #0a84ff', borderRadius: 4, pointerEvents: 'none' }} className="ink-ui" />
      <div className="ink-ui" style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        {dot(b.x + b.w + 8, b.y - 8, '#ef4444', 'd', '×')}
        {dot(b.x + b.w, b.y + b.h, '#0a84ff', 'r', '')}
        {line && [[selObj.x1, selObj.y1], [selObj.x2, selObj.y2]].map((q, i) => dot(q[0], q[1], '#fff', `e${i}`, ''))}
      </div>
      <div data-inkui="1" className="ink-ui glass glass-menu" style={{ position: 'absolute', left: clamp(px(b.x), 4, W - 190), top: flip ? Math.max(4, px(b.y) - 60) : barTop, display: 'flex', gap: 2, padding: 4, borderRadius: 16, pointerEvents: 'auto', zIndex: 5 }}>
        {[[Copy, 'Duplicate', () => { const n = engine.dup(selId); if (n) setSelId(n.id); }], [ArrowUpToLine, 'Bring to front', () => engine.order(selId, true)], [ArrowDownToLine, 'Send to back', () => engine.order(selId, false)], [Trash2, 'Delete', () => { engine.remove([selId]); setSelId(null); }]].map(([I, t, fn]) => (
          <button key={t} type="button" title={t} aria-label={t} onClick={fn} className="rbtn !min-h-[40px] !min-w-[40px]"><I size={18} /></button>
        ))}
        {onPickColor && selObj.t !== 'img' && <label title="Colour" className="rbtn !min-h-[40px] !min-w-[40px] cursor-pointer"><span style={{ width: 20, height: 20, borderRadius: 10, background: selObj.color, border: '2px solid rgba(0,0,0,.25)', display: 'block' }} /><input type="color" value={selObj.color && selObj.color.length === 7 ? selObj.color : '#111827'} onChange={(e) => engine.update(selId, { color: e.target.value })} style={{ position: 'absolute', opacity: 0, width: 1, height: 1 }} /></label>}
      </div>
      {selObj.t === 'img' && (
        <div data-inkui="1" className="ink-ui glass glass-menu" style={{ position: 'absolute', left: clamp(px(b.x), 4, W - 330), top: flip ? Math.max(4, px(b.y) - 112) : barTop + 52, display: 'flex', flexWrap: 'wrap', width: 322, gap: 2, padding: 4, borderRadius: 16, pointerEvents: 'auto', zIndex: 5 }}>
          {[25, 50, 75, 100].map((p) => <button key={p} type="button" title={`${p}% of the page width`} onClick={() => sizeInkImage(engine, selObj, W, p)} className="rbtn !min-h-[40px] !min-w-[44px] text-xs font-semibold">{p}%</button>)}
          {[[Undo2, 'Reset size', () => resetInkImage(engine, selObj, W)], [Crop, 'Crop', async () => setCropO(selObj)], [RotateCcw, 'Rotate left', () => rotateInkImage(engine, selObj, -90)], [RotateCw, 'Rotate right', () => rotateInkImage(engine, selObj, 90)],
            [FlipHorizontal2, 'Flip left-right', () => flipInkImage(engine, selObj, false)], [FlipVertical2, 'Flip up-down', () => flipInkImage(engine, selObj, true)], [RefreshCw, 'Replace picture', async () => repl.current?.click()],
            [Download, 'Save picture', async () => saveBlob(`picture.${/png/.test(selObj.src.slice(0, 20)) ? 'png' : 'jpg'}`, dataUrlToBlob(selObj.src))]].map(([I, t, fn]) => (
            <button key={t} type="button" title={t} aria-label={t} onClick={imgGo(fn)} className="rbtn !min-h-[40px] !min-w-[40px]"><I size={18} /></button>
          ))}
          <label className="flex w-full items-center gap-2 px-2 text-xs opacity-80">Opacity<input type="range" min={15} max={100} value={Math.round((selObj.op == null ? 1 : selObj.op) * 100)} onChange={(e) => engine.tweak(selId, { op: Number(e.target.value) / 100 })} onPointerUp={() => engine.endTweak()} onPointerCancel={() => engine.endTweak()} className="h-7 flex-1" /></label>
        </div>
      )}
    </>);
  }

  const mk = (kind, extra, cs = cells, pre = '') => (cs ? cs.list.map(([t, c, r]) => <Tile key={`${pre}${kind}-${cs.grid}-${t}.${c}.${r}`} rkey={`${pre}${kind}-${cs.grid}-${t}.${c}.${r}`} kind={kind} engine={engine} x0={c * cs.cw} y0={t * pitch + r * cs.ch} cw={cs.cw} ch={cs.ch} sc={cs.sc} reg={reg} {...extra} />) : null);
  const box = { position: 'absolute', left: 0, top: 0, width: W, height: totalH, zIndex: 3, pointerEvents: 'none' };
  return (<>
    {/* highlighter layer: on light pages it sits UNDER the text (the page's pictures and shaded boxes multiply over it), so words stay crisp like a real marker; dark pages use screen on top */}
    <div className="ink-layer-hl" style={hlBlend === 'multiply' ? { ...box, zIndex: -1 } : { ...box, mixBlendMode: hlBlend }}>
      {prev && mk('hl', { eager: true }, prev, 'o')}
      {mk('hl', { eager: tool === 'highlighter' || tool === 'select' })}
      <canvas ref={liveHl} width={1} height={1} className="ink-ui" style={{ position: 'absolute', left: 0, top: 0, width: W, pointerEvents: 'none' }} />
    </div>
    <div ref={layer} className="ink-layer" data-ink-layer="1" style={{ ...box, pointerEvents: tool ? 'auto' : 'none', touchAction: tool ? 'none' : 'auto', cursor: tool ? 'crosshair' : 'auto' }}>
      {prev && mk('base', {}, prev, 'o')}
      {mk('base')}
      <canvas ref={live} width={1} height={1} className="ink-ui" style={{ position: 'absolute', left: 0, top: 0, width: W, pointerEvents: 'none' }} />
      <canvas ref={liveTail} width={1} height={1} className="ink-ui" style={{ position: 'absolute', left: 0, top: 0, width: W, pointerEvents: 'none' }} />
      {selUi}
      <input ref={repl} type="file" accept="image/*" hidden onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f && selObj) replaceInkImage(engine, selObj, f).catch(() => {}); }} />
      {cropO && createPortal(<CropDialog src={cropO.src} onClose={() => setCropO(null)} onApply={(src, bx) => { cropInkImage(engine, cropO, src, bx); setCropO(null); }} />, document.body)}
    </div>
    {tool === 'laser' && createPortal(<canvas ref={laserCv} className="ink-ui" style={{ position: 'fixed', left: 0, top: 0, width: '100vw', height: '100vh', pointerEvents: 'none', zIndex: 60 }} />, document.body)}
  </>);
}
