/*
 * PenTracker - from the raw samples of ONE pointer (the one that touched first: the "focus" pointer) to the points of a stroke.
 * Pure code, no DOM. All lengths are screen pixels, all times milliseconds, so it behaves the same at any zoom.
 *
 * What it does, and why (settings were chosen by measuring against simulated stylus input with noise, uneven timing and
 * handwriting-like speed changes: slower on bends and at sharp corners, fast on straight parts):
 *  1. Light "One Euro" filter: removes touch-panel jitter, with almost no delay while the pen moves fast.
 *  2. Speed-aware "leash": the ink point only moves when the pen is more than R pixels away from it, and then only as far as needed.
 *     This keeps the ink within about R pixels of the pen at any speed (a fixed delay filter lags and cuts bends when you write fast),
 *     removes the last jitter, and R shrinks to 0 when the pen slows down, so the ink reaches the exact tip of a sharp corner.
 *  3. A jump guard: a sample that teleports (a finger swap, a glitch) never becomes a straight line across the page.
 *  4. A careful short prediction for the line being drawn: only while the pen moves smoothly, it follows the curve, it is short, and it is
 *     never stored in the stroke.
 */

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const lpAlpha = (rate, cut) => 1 / (1 + (1 / (2 * Math.PI * cut)) * rate);

export const PEN = {
  EURO_MIN: 6, EURO_BETA: 0.3, EURO_DCUT: 25,   // light filter (Hz, Hz per px/s, Hz)
  LEASH: 1.1, LEASH_V0: 40, LEASH_V1: 300,       // leash length (px) and the speeds (px/s) between which it grows from 0 to full
  GATE: 0.75,                                    // a new stroke point is stored after the ink has moved this far (px)
  JUMP_PX: 150, JUMP_SPEED: 12000, JUMP_CONFIRM: 3, // a sample this far away and this fast is a glitch, unless the next samples stay there
  PREDICT_MS: 32, PREDICT_CAP: 8, PREDICT_TURN: 0.5, PREDICT_ACCEL: 0.5,
};

export class PenTracker {
  /** zoom: screen pixels per page pixel (1 = 100 %). Zoomed out, one screen pixel is several page pixels, so the leash is a little longer. */
  constructor(zoom = 1) {
    this.leash = Math.min(1.8, PEN.LEASH / Math.sqrt(clamp(zoom, 0.25, 1)));
    this.f = { init: false, x: 0, y: 0, dx: 0, dy: 0, t: 0 };   // One Euro state
    this.ink = null;                                             // leash state: the ink point [x, y]
    this.v = 0;                                                  // speed estimate (px/s)
    this.raw = null;                                             // last accepted raw sample {x, y, t}
    this.last = null;                                            // last stored point [x, y]
    this.tips = [];                                              // recent ink tips {t, x, y} for the prediction
    this.cand = null;                                            // a possible jump being checked: {x, y, n}
  }

  /** Start at the point where the pointer touched down (that point is already the first point of the stroke). */
  seed(x, y, t) {
    this.raw = { x, y, t }; this.last = [x, y]; this.ink = [x, y];
    this.f = { init: true, x, y, dx: 0, dy: 0, t };
    this.tips = [{ t, x, y }];
  }

  /** One raw sample. Returns { points: [[x, y], ...] to store (0 or 1 point), restart: true if the pointer jumped somewhere else for good, accepted: false for a glitch sample that was ignored }. */
  push(x, y, t) {
    const out = { points: [], restart: false, accepted: false };
    if (!this.raw) { this.seed(x, y, t); return out; }
    const r = this.raw;
    if (x === r.x && y === r.y) return out;                       // same place again: nothing new
    const dt = Math.max(0.5, t - r.t) / 1000;
    const d = Math.hypot(x - r.x, y - r.y);
    // jump guard: far away, and faster than a hand can move
    if (d > PEN.JUMP_PX && d / dt > PEN.JUMP_SPEED) {
      if (this.cand && Math.hypot(x - this.cand.x, y - this.cand.y) < 40) this.cand.n += 1; else this.cand = { x, y, n: 1 };
      if (this.cand.n >= PEN.JUMP_CONFIRM) { out.restart = true; this.cand = null; }   // it really is somewhere else now: the caller ends this stroke
      return out;                                                 // the glitch sample itself is never used
    }
    this.cand = null; out.accepted = true;
    // speed estimate from the raw samples (smoothed at 20 Hz)
    this.v += lpAlpha(1 / dt, 20) * (d / dt - this.v);
    this.raw = { x, y, t: r.t + dt * 1000 };
    // 1. light One Euro filter
    const f = this.f, rate = 1 / dt, ad = lpAlpha(rate, PEN.EURO_DCUT);
    f.dx += ad * ((x - f.x) / dt - f.dx); f.dy += ad * ((y - f.y) / dt - f.dy);
    const a = lpAlpha(rate, PEN.EURO_MIN + PEN.EURO_BETA * Math.hypot(f.dx, f.dy));
    f.x += a * (x - f.x); f.y += a * (y - f.y); f.t = t;
    // 2. speed-aware leash
    const k = clamp((this.v - PEN.LEASH_V0) / (PEN.LEASH_V1 - PEN.LEASH_V0), 0, 1), R = this.leash * k * k * (3 - 2 * k);
    const ink = this.ink; const lx = f.x - ink[0], ly = f.y - ink[1], ld = Math.hypot(lx, ly);
    if (ld > R) { ink[0] = f.x - (lx / ld) * R; ink[1] = f.y - (ly / ld) * R; }
    this.tips.push({ t, x: ink[0], y: ink[1] }); if (this.tips.length > 12) this.tips.shift();
    // store a point once the ink has moved far enough
    if (Math.hypot(ink[0] - this.last[0], ink[1] - this.last[1]) >= PEN.GATE) { this.last = [ink[0], ink[1]]; out.points.push([ink[0], ink[1]]); }
    return out;
  }

  /**
   * A short guess of where the ink tip will be a moment from now (screen px), or null. Used only to draw a lighter tip on a temporary layer.
   * It follows the turning of the stroke (an arc), so it stays on a curve instead of pointing out of it, and it gives up
   * (returns null) when the pen turns fast or speeds up / slows down fast, which is when a guess would be wrong.
   */
  predict() {
    const T = this.tips, n = T.length; if (n < 7) return null;
    const t0 = T[n - 7], t1 = T[n - 4], t2 = T[n - 1];
    const a1 = Math.atan2(t1.y - t0.y, t1.x - t0.x), a2 = Math.atan2(t2.y - t1.y, t2.x - t1.x);
    let da = a2 - a1; while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI;
    const s1 = Math.hypot(t1.x - t0.x, t1.y - t0.y), s2 = Math.hypot(t2.x - t1.x, t2.y - t1.y);
    const dt1 = (t1.t - t0.t) / 1000, dt2 = (t2.t - t1.t) / 1000; if (dt1 <= 0 || dt2 <= 0 || s1 < 0.5 || s2 < 0.5) return null;
    const v1 = s1 / dt1, v2 = s2 / dt2; if (v2 < 40) return null;
    if (Math.abs(da) > PEN.PREDICT_TURN) return null;
    if (Math.abs(v2 - v1) > PEN.PREDICT_ACCEL * Math.max(v1, v2)) return null;
    const L = Math.min(v2 * PEN.PREDICT_MS / 1000, PEN.PREDICT_CAP), rate = da / ((s1 + s2) / 2), steps = 6, ds = L / steps;
    let x = t2.x, y = t2.y, ang = a2 + rate * (s2 / 2);
    for (let i = 0; i < steps; i++) { ang += rate * ds; x += Math.cos(ang) * ds; y += Math.sin(ang) * ds; }
    return [x, y];
  }
}

/**
 * Final clean-up of a finished stroke (called once, when the pen is lifted): a gentle smoothing along the stroke with a Gaussian of width `sigma`
 * (in the units of the points). It uses points on both sides, so it adds no delay and no shift; the two ends stay where they are, and a sharp turn
 * (more than about 50 degrees within two sigma) is left exactly as written, so corners stay sharp while the small wobbles of the touch panel go.
 * Measured on simulated strokes it removes about 40-60 % of the remaining roughness and does not change how close the line is to the pen path.
 */
export function polishStroke(pts, sigma, cornerDeg = 50) {
  const n = pts.length; if (n < 5 || !(sigma > 0)) return pts;
  const s = [0]; for (let i = 1; i < n; i++) s.push(s[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  const total = s[n - 1]; if (total < 4 * sigma) return pts;
  const ds = pts.map((_, i) => ((i < n - 1 ? s[i + 1] : s[i]) - (i > 0 ? s[i - 1] : s[i])) / 2 || 1e-9);
  const away = (i, dir) => { let j = i; while (j + dir >= 0 && j + dir < n && Math.abs(s[j] - s[i]) < 2 * sigma) j += dir; return j; };
  const cosLim = Math.cos((cornerDeg * Math.PI) / 180), out = pts.map((p) => p.slice());
  for (let i = 1; i < n - 1; i++) {
    const edge = Math.min(s[i], total - s[i]), f = Math.min(1, edge / (3 * sigma)); if (f <= 0) continue;
    const b = away(i, -1), a = away(i, 1);
    const ix = pts[i][0] - pts[b][0], iy = pts[i][1] - pts[b][1], ox = pts[a][0] - pts[i][0], oy = pts[a][1] - pts[i][1];
    const li = Math.hypot(ix, iy), lo = Math.hypot(ox, oy);
    if (li > 1e-9 && lo > 1e-9 && (ix * ox + iy * oy) / (li * lo) < cosLim) continue;   // sharp corner: keep it as it is
    let sx = 0, sy = 0, sw = 0;
    for (let j = i; j >= 0 && s[i] - s[j] <= 3 * sigma; j--) { const d = s[j] - s[i], w = Math.exp(-(d * d) / (2 * sigma * sigma)) * ds[j]; sx += pts[j][0] * w; sy += pts[j][1] * w; sw += w; }
    for (let j = i + 1; j < n && s[j] - s[i] <= 3 * sigma; j++) { const d = s[j] - s[i], w = Math.exp(-(d * d) / (2 * sigma * sigma)) * ds[j]; sx += pts[j][0] * w; sy += pts[j][1] * w; sw += w; }
    out[i][0] = pts[i][0] + f * (sx / sw - pts[i][0]); out[i][1] = pts[i][1] + f * (sy / sw - pts[i][1]);
  }
  return out;
}
