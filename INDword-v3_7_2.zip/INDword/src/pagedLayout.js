import { Extension } from '@tiptap/core';
import { Plugin, PluginKey } from '@tiptap/pm/state';
import { Decoration, DecorationSet } from '@tiptap/pm/view';

/**
 * Pure page/column flow. blocks: [{ h, span, keepNext, pageBreak, colBreak, cover }]  (h = outer height incl. margins)
 * c: { W, H, mL, mT, cols, colW, fullW, gap, contentH, pageGap }
 * Fills page 1 column 1, then column 2, then page 2 column 1, and so on.
 */
export const WRAP_GAP = 16;      // space between a floating picture and the text beside it
export const WRAP_MIN = 120;     // narrowest text column worth putting beside a picture
export function layoutBlocks(blocks, c) {
  const out = []; let page = 0; let col = 0; let y = 0; let topH = 0; let used = 0;
  const empty = () => col === 0 && y === 0 && topH === 0;
  // fl: a left / right picture whose bottom is at `until` (same coordinate as y). Blocks that start above it are laid out beside it, never under it.
  let fl = null;
  const pageTop = (p) => p * (c.H + c.pageGap);
  const newPage = () => { page += 1; col = 0; y = 0; topH = 0; fl = null; };
  const nextCol = () => { fl = null; if (col + 1 < c.cols) { col += 1; y = 0; } else newPage(); };
  // x and width of the next block at the current y: the whole column, or what is left beside the floating picture
  const lane = () => {
    const x = c.mL + col * (c.colW + c.gap); const w = c.cols > 1 ? c.colW : c.fullW;
    if (fl && y < fl.until - 0.5) {
      // text goes on the side of the picture that has the room: right of a left picture, left of a right picture
      if (fl.side === 'left') { const t = fl.off + fl.w + fl.gap; return { x: x + t, w: w - t }; }
      return { x, w: w - fl.off - fl.w - fl.gap };
    }
    return { x, w };
  };
  blocks.forEach((b, i) => {
    if (b.cover) { if (!empty()) newPage(); out[i] = { x: 0, y: pageTop(page), w: c.W, cover: true }; used = Math.max(used, page); newPage(); return; }
    if (b.pageBreak) { if (!empty()) newPage(); fl = null; out[i] = { hidden: true, nextPage: page }; return; }
    if (b.colBreak) { if (y > 0) nextCol(); out[i] = { hidden: true }; return; }
    if (b.span && c.cols > 1) {
      fl = null;
      if (!(col === 0 && y === 0)) newPage();
      if (topH > 0 && topH + b.h > c.contentH) newPage();
      out[i] = { x: c.mL, y: pageTop(page) + c.mT + topH, w: c.fullW }; topH += b.h; used = Math.max(used, page); return;
    }
    if (b.wrap && b.fw && !b.span) {
      // a picture with text around it: it is as wide as the picture, on the left or right edge of the column
      if (fl && y < fl.until - 0.5) y = fl.until;                       // two floating pictures never share a row
      if (y > 0 && topH + y + b.h > c.contentH + 2) nextCol();
      const colX = c.mL + col * (c.colW + c.gap); const colWd = c.cols > 1 ? c.colW : c.fullW;
      const off = Math.max(0, Math.min(b.off || 0, colWd - b.fw - (b.gap || 0) - WRAP_MIN));   // distance from the picture's own edge of the column
      out[i] = { x: b.wrap === 'right' ? colX + colWd - b.fw - off : colX + off, y: pageTop(page) + c.mT + topH + y, w: b.fw };
      fl = { side: b.wrap, w: b.fw, gap: b.gap || 0, off, until: y + b.h };
      used = Math.max(used, page); return;
    }
    let need = b.h;
    const nx = blocks[i + 1];
    if (b.keepNext && nx && !nx.pageBreak && !nx.colBreak && !nx.cover) need += Math.min(nx.h, 120);
    const fits = () => topH + y + need <= c.contentH + 2;
    if (!fits() && (y > 0 || b.h > c.contentH - topH) && b.split) {
      const L = b.split();
      if (L && L.n >= 4) {
        const pieces = []; let rem = L.n; let line = 0; let guard = 0;
        while (rem > 0 && guard < 200) {
          guard += 1;
          const avail = c.contentH - topH - y - L.extra;
          let take = Math.min(rem, Math.max(1, Math.floor((avail + 2) / L.lh)));
          if (take < rem) {
            if (rem - take < 2) take = rem - 2;
            if (take < 2) { if (y > 0) { nextCol(); continue; } take = Math.min(rem, 2); }
          }
          const ln = lane();
          pieces.push({ x: ln.x, y: pageTop(page) + c.mT + topH + y, w: ln.w, lines: take, line });
          y += take * L.lh + L.extra; line += take; rem -= take; used = Math.max(used, page);
          if (rem > 0) nextCol();
        }
        out[i] = pieces.length === 1 ? pieces[0] : { pieces }; return;
      }
    }
    if (y > 0 && !fits()) nextCol();
    const ln = lane();
    out[i] = { x: ln.x, y: pageTop(page) + c.mT + topH + y, w: ln.w };
    y += b.h; used = Math.max(used, page);
  });
  return { items: out, pages: used + 1 };
}

const key = new PluginKey('pagedLayout');

/** Line starts of a paragraph (document position per visual line) plus line pitch; only measured when a block must split. */
function lineInfo(view, off, node, dom, margins) {
  const start = off + 1; const end = off + node.nodeSize - 1; const lines = []; let last = -1e9;
  for (let p = start; p <= end; p += 1) {
    let r; try { r = view.coordsAtPos(p, 1); } catch (e) { continue; }
    if (r.top - last > 6) { lines.push({ pos: p }); last = r.top; }
  }
  if (!lines.length) return null;
  const cs = getComputedStyle(dom);
  const pad = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0) + (parseFloat(cs.borderTopWidth) || 0) + (parseFloat(cs.borderBottomWidth) || 0);
  return { n: lines.length, lines, lh: (dom.offsetHeight - pad) / lines.length, extra: pad + margins };
}
const px = (v) => Math.round(v * 10) / 10;

export const PagedLayout = Extension.create({
  name: 'pagedLayout',
  addStorage() { return { cfg: null, onLayout: null, onBreaks: null, hold: false }; },   // hold: a picture is being resized, do not move blocks under the finger
  addProseMirrorPlugins() {
    const ext = this;
    return [new Plugin({
      key,
      state: {
        init: () => ({ deco: DecorationSet.empty, sig: '' }),
        apply(tr, val) {
          const m = tr.getMeta(key);
          if (m) return { deco: m.deco(tr.doc), sig: m.sig };
          return { deco: val.deco.map(tr.mapping, tr.doc), sig: val.sig };
        },
      },
      props: { decorations(state) { return ext.storage.cfg ? key.getState(state).deco : DecorationSet.empty; } },
      view(view) {
        let raf = 0; let loops = 0; let lastDoc = null; let lastCfg = null;
        const seen = new WeakSet();
        const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(() => { loops = 0; if (!raf) raf = requestAnimationFrame(run); }) : null;
        const run = () => {
          raf = 0;
          if (ext.storage.hold) return;
          const cfg = ext.storage.cfg;
          const st = key.getState(view.state);
          if (!cfg) { if (st.sig) view.dispatch(view.state.tr.setMeta(key, { deco: () => DecorationSet.empty, sig: '' }).setMeta('addToHistory', false)); return; }
          const blocks = []; const nodes = [];
          view.state.doc.forEach((node, off) => {
            const dom = view.nodeDOM(off);
            const n = node.type.name; const b = {};
            let imgW = 0; let side = null; let fw = 0; let gap = 0; let poff = 0;
            const pw = (v, dflt) => { const w = String(v || ''); return /%$/.test(w) ? (parseFloat(w) / 100) * cfg.colW : (parseFloat(w) || dflt); };
            if (n === 'paragraph' && node.childCount === 1 && node.firstChild.type.name === 'image') {
              const at = node.firstChild.attrs; imgW = pw(at.width, 0);
              if ((at.align === 'left' || at.align === 'right') && imgW) { side = at.align; fw = imgW + WRAP_GAP; gap = 0; poff = Number(at.dx) || 0; }   // the float's own margin is the gap
            } else if (n === 'notePicture') {
              const at = node.attrs; imgW = pw(at.width, 339);
              if (at.align === 'left' || at.align === 'right') { side = at.align; fw = imgW; gap = WRAP_GAP; poff = Number(at.dx) || 0; }
            }
            // text goes beside the picture only when there is room for a readable column; otherwise the picture keeps its own rows
            const wrap = side && imgW < cfg.colW - 4 && cfg.colW - fw - gap >= WRAP_MIN ? side : null;
            if (n === 'pageBreak') b.pageBreak = true;
            else if (n === 'columnBreak') b.colBreak = true;
            else if (imgW >= cfg.W - 4) b.cover = true;
            else {
              b.span = (n === 'heading' && node.attrs.level === 1) || imgW > cfg.colW + 4;
              if (wrap) { b.wrap = wrap; b.fw = fw; b.gap = gap; b.off = poff; }
              b.keepNext = n === 'heading' && node.attrs.level > 1;
              if (dom && dom.nodeType === 1) {
                const cs = getComputedStyle(dom);
                if (ro && !seen.has(dom)) { seen.add(dom); ro.observe(dom); }
                const mt = parseFloat(cs.marginTop) || 0; const mb = parseFloat(cs.marginBottom) || 0;
                b.h = dom.offsetHeight + mt + mb;
                if (n === 'paragraph' && !imgW && node.textContent.length > 20) {
                  let cache;
                  b.split = () => { if (cache === undefined) cache = lineInfo(view, off, node, dom, mt + mb); return cache; };
                }
              } else b.h = 24;
            }
            blocks.push(b); nodes.push({ off, size: node.nodeSize });
          });
          const res = layoutBlocks(blocks, cfg);
          const cuts = [];
          res.items.forEach((it, i) => { if (it && it.pieces) { const L = blocks[i].split(); let acc = 0; it.pieces.forEach((pc, k) => { acc += pc.lines; if (k < it.pieces.length - 1) cuts.push(L.lines[acc].pos); }); } });
          if (cuts.length && loops < 30) {
            loops += 1;
            let tr = view.state.tr; cuts.sort((a, b2) => b2 - a).forEach((pos) => { tr = tr.split(pos); });
            view.dispatch(tr.setMeta(key, { deco: () => DecorationSet.empty, sig: '' }).setMeta('addToHistory', false));
            return;
          }
          const sig = `${cfg.sig}|${res.pages}|${res.items.map((it) => (it.hidden ? 'h' : `${px(it.x)},${px(it.y)},${px(it.w)}`)).join(';')}`;
          if (sig !== st.sig && loops < 30) {
            loops += 1;
            const items = res.items; const list = nodes;
            const mk = (doc) => DecorationSet.create(doc, list.map((nd, i) => {
              const it = items[i];
              const style = it.hidden ? 'display:none' : `position:absolute;left:${px(it.x)}px;top:${px(it.y)}px;width:${px(it.w)}px;box-sizing:border-box;${it.cover ? 'margin:0;' : ''}`;
              return Decoration.node(nd.off, nd.off + nd.size, { style });
            }));
            view.dispatch(view.state.tr.setMeta(key, { deco: mk, sig }).setMeta('addToHistory', false));
          } else {
            if (ext.storage.onBreaks) {
              const brks = [];
              blocks.forEach((b, i) => { if (b.pageBreak) { const nd = view.state.doc.nodeAt(nodes[i].off); if (nd && nd.attrs.id) brks.push({ id: nd.attrs.id, start: res.items[i].nextPage }); } });
              ext.storage.onBreaks(brks, res.pages);
            }
            ext.storage.onLayout?.(res.pages);
          }
        };
        const kick = () => { if (!raf) raf = requestAnimationFrame(run); };
        const onLoad = () => { loops = 0; kick(); };
        view.dom.addEventListener('load', onLoad, true);
        if (document.fonts?.ready) document.fonts.ready.then(onLoad);
        kick();
        return {
          update() { if (lastDoc !== view.state.doc || lastCfg !== ext.storage.cfg) { loops = 0; lastDoc = view.state.doc; lastCfg = ext.storage.cfg; } kick(); },
          destroy() { cancelAnimationFrame(raf); ro?.disconnect(); view.dom.removeEventListener('load', onLoad, true); },
        };
      },
    })];
  },
});

/** The top-level blocks of each page, read from where the layout put them: [{ nodes: [ProseMirror nodes] }] (null when the page layout is off). */
export function pageGroups(editor) {
  const cfg = editor?.storage?.pagedLayout?.cfg; if (!cfg) return null;
  const view = editor.view; const step = cfg.H + cfg.pageGap; const groups = []; let cur = 0;
  view.state.doc.forEach((node, off) => {
    const dom = view.nodeDOM(off); let p = cur;
    if (dom && dom.nodeType === 1 && dom.style.display !== 'none') { const t = parseFloat(dom.style.top); if (Number.isFinite(t)) p = Math.max(0, Math.floor((t + 1) / step)); }
    if (p < cur) p = cur;
    while (groups.length <= p) groups.push({ nodes: [] });
    groups[p].nodes.push(node); cur = p;
  });
  if (!groups.length) groups.push({ nodes: [] });
  return groups;
}
