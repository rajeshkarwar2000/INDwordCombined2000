import { LOGO, BRAND } from '../brand.js';

const dateStr = () => new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
export const todayStr = dateStr;
/** header carries today's date; it is read at the moment the meta is spread into a document */
export const NOTES_META = {
  get header() { return `${BRAND.header}  ·  ${dateStr()}`; },
  paged: true, size: 'A4', orientation: 'portrait', columns: 2, fontSet: 'office',
  margins: { top: 52, right: 44, bottom: 52, left: 44 },
  marginBorder: { style: 'dashed', color: '#000000', width: 2, gap: 12 },
  footer: BRAND.footer, pageNumbers: true,
  watermark: { text: '', image: LOGO, imageWidth: 420, opacity: 0.07 },
};
const COL_W = 339, FULL_W = 706;

/* ---------------- master prompt ---------------- */
export const DEFAULT_OPTS = { pyqPrelims: false, pyqMains: false, mockPrelims: false, mockMains: false, hindi: false, keywords: true, related: true, extra: '', images: true, cover: false, cols: 2 };

/* shared wording used by both the Gemini and the ChatGPT prompt */
const PYQ_FACETS = 'PYQ-DRIVEN COVERAGE (important): for the topic and for every species, place, organisation, scheme, law, report, exercise, platform or concept in it, recall which facets UPSC (Prelims and Mains) and State PSCs have asked about before, and make sure every such facet is covered in the notes even if the article does not mention it. For example: a species: IUCN Red List status, CITES appendix, CMS listing, Wildlife (Protection) Act 1972 schedule, habitat, distribution and migration route, threats, protected areas and conservation projects; a place or region: location, neighbours, rivers, mountains, capital, resources, strategic importance and its position on the map; an organisation or body: headquarters, year of formation, parent ministry, members, mandate, flagship reports; a scheme or law: ministry, launch year, objectives, beneficiaries, nodal agency, funding; a report or index: publisher, India\'s rank, top performers, parameters; a defence or science platform: type or class, builder, ministry, key specifications, project; an exercise or treaty: participants, place, edition, date, theme, provisions; a judgment or Article: bench, year, ratio, related Articles; a declaration, resolution or principle: the underlying charter, treaty or Article it invokes, explained provision by provision (for example, news about "respect for the UN Charter" needs the UN Charter: signed 1945, purposes and principles, Article 2(4), Article 2(7), Article 51, Chapter VII); a forum or grouping: founding year and place, members, structure, legal status, and similar groupings (ASEAN, SAARC, BRICS).';
const STYLE_MODEL = 'STYLE (learn from the Deepak Yadav Education notes and the coaching websites): subject-specific headings in the form "What is X?", "Why is X in news?", "Features", "Applications", "Impact", usually in this order: Why in News; What is the main subject (full form, year and place of founding, nature, objective, legal status); structure or features; key points of the decision or document, each principle explained in a line; why it matters, concerns and arguments; an "Important facts" box (venue, dates, participants, hosts, outcome, next event); the underlying treaty, law or concept in the static part; Revision Pointers; almost everything in short bullets that begin with a **bold lead term:** followed by the fact; the static concept explained right after the dynamic point that needs it; many key phrases and figures in bold; Revision Pointers as one-line bullets; PYQ and mock MCQs with a statement-wise explanation; maps, diagrams and infographics placed next to the text they explain.';
const BULLETS = 'BULLETS: write at least nine tenths of the text as bullet points ("points"), each starting with a **bold lead term:** followed by the fact. Use "body" only for a one-line lead-in.';
const BOLD = 'EMPHASIS: use ONLY **bold**. Do NOT use any highlight, marker, yellow or colour mark and never write ==text==. Important words are often hidden deep inside long lines, so scan EVERY sentence and bullet from start to end and put **bold** on each important word or phrase wherever it sits: names, places, species, organisations, numbers, dates, legal provisions, schemes, technical terms and decisive words (banned, approved, mandatory, first, only). Almost every bullet needs at least one bold phrase and long bullets need several; do not stop after the first phrase. Begin each bullet with a **bold lead term:** where possible. After writing, re-read every line once more and bold any important term you missed. Never bold filler words or whole sentences.';
const IMG_ANALYSE = 'Analyse the article and the static background properly, and add an image only where a student would understand a static or dynamic point noticeably better with it than with bullets: a place, route or distribution (map), a process or mechanism (flowchart), structure or layers (labelled diagram), equipment (cut-away diagram or picture), a classification or comparison (table or chart), a sequence (timeline).';
const FOUNDATION = 'FOUNDATIONAL DOCUMENTS (very important): whenever the article invokes a declaration, principle, treaty, charter, convention, constitution, resolution, doctrine or legal concept (for example "respect for the UN Charter", "sovereignty", "self-defence", "non-interference"), give the underlying document or concept its own section in the static part: what it is, when and where it was signed or adopted, who is bound, its structure, and every provision, Article or Chapter relevant to the news with its meaning in one line each, then how it applies to this news. Do this for every such document the article names or relies on, even if the article only mentions it in passing.';
const NO_FILLER = 'NO FILLER: every line must carry a specific fact, provision, number, name or argument tied to this article. Never write generic sentences such as "this framework reveals multiple dimensions crucial for UPSC preparation", and never create a "dimension" or "perspective" section that has only generic statements: if a dimension has no concrete point for this article, leave it out. Where the article has event or decision details, give an "Important facts" section (venue, dates, participants or members, hosts, key persons, outcome, next edition) as one-line bullets.';
const STATIC_DEPTH = 'STATIC PART = THE MAIN EXPLANATION (expand it): this is where the real explanation of the topic goes, so make the static part the longest and most detailed part of the notes, roughly two to three times the dynamic part. Every organisation, law, article, scheme, committee, judgment, treaty, concept, index, species, place or term that is named in the dynamic part must be explained here. For each one give 8-14 bullets in this order where it applies: meaning and definition; origin and history (chronological, with years); constitutional / legal / treaty basis; structure and composition; objectives and functions; key features and provisions; how it works in practice, with an example or a figure; important amendments, judgments, reports or developments; significance; criticism, limitations and challenges; comparison with other countries or similar bodies; latest status and its link to the article. Add the standard facts an examiner asks (full form, headquarters, year, parent ministry, first / only / largest, related lists). Explain every term in simple words.';
const SUMMARY_RULE = 'SUMMARY (first): write a short summary of what the article is about in 3-5 crisp bullets (about 80 words in all): the issue, who / what / where / when, the main argument or decision, and the outcome or why it matters, so that a reader understands the article in twenty seconds. Do not repeat it later.';
const DYNAMIC_LEAN = 'DYNAMIC PART = LEAN (do not over-explain): report only what the article says, in short, telegraphic bullets, typically 500-900 words (up to about 1,200 for a long editorial). Include every important fact, figure, date, name, provision, argument and suggestion, but do NOT explain background, definitions, institutions or concepts here: just name them and leave their explanation to the static part. No repetition, no storytelling and no filler.';
const CONFUSIONS = 'EXAM CONFUSIONS (clarify them): find the points on which aspirants usually get confused in the exam on this topic and clear each one: similar-sounding terms, bodies, acts, schemes or treaties (X versus Y), look-alike dates, numbers and places, constitutional versus statutory versus executive status, what is included and what is not, the usual wrong options in Prelims, differences between India and other countries, and tricky statements that look right but are wrong. Return 4-8 items in \"confusions\": the confusing point, the clear distinction in one or two lines, and a short memory hint. Be factually exact.';
const ARGS_BULLETS = 'ARGUMENTS (compress and keep straightforward): put every argument of the article in crisp bullets, one argument per bullet, in the form **Who:** claim, because reason or evidence (about 25 words at most). No long paragraphs. Order them chronologically, following the order in which the article develops the issue (background, then what was proposed or decided, then the reactions, then the criticism and defence, then the outcome); within a stage keep for, against and neutral together. Use simple direct sentences. Nothing the article argues may be left out.';
const DYNAMIC_ORDER = 'ORDER OF THE DYNAMIC PART (arrange it for proper understanding): build the story step by step so that each heading prepares the next: 1) Why in news (one or two lines); 2) background and timeline of events in strict chronological order with dates; 3) what exactly happened or was decided, with the key provisions, figures and bodies; 4) the stakeholders and the arguments, as bullets; 5) impact and implications by dimension (political, economic, social, legal, administrative, federal, technological, environmental, security, international, ethical); 6) concerns, challenges and criticism; 7) government strategy, suggestions and solutions; 8) way forward and conclusion pointers. Name each technical term and leave its explanation to the static part. Keep cause, event and effect in adjacent bullets, and keep related points under one heading instead of scattering them.';
const INNOVATIVE = 'INNOVATIVE ARGUMENTS FOR THE EXAM: besides what the article says, give a separate set of fresh, original points that an aspirant can write to stand out and that examiners reward, kept apart under a heading of their own and not repeating the article: an unusual angle or framing (for example cost-benefit, federal balance, ethics, gender, long-term versus short-term, technology, environment, international comparison); a counter-intuitive but defensible argument; a data point, report finding, committee recommendation or court observation that supports a point; a real case study, best practice or comparison with another country or state; a short quotable line or a pair like \"X is necessary but not sufficient\"; and a suggested diagram, flowchart or one-line conclusion. Every such point must be factually correct and short, and marked in the heading as additional value, not as part of the article.';
const RELATED_MORE = 'RELATED FACTS (include other related facts too): besides facts from the article, add the other related facts an aspirant should know about the same topic: connected organisations, schemes, laws, committees, reports, indices and their latest ranks, places and geography, species, personalities, firsts, records, lists, key dates, international groupings and agreements, and the links to earlier news on the same subject. Keep each fact to one line and verify it from PIB and other official sources.';
const UPSC_FOCUS = 'UPSC RELEVANCE ONLY (very important): include only what is useful for UPSC CSE (Prelims and Mains) and State PSC preparation, and leave out trivial detail. Do NOT include: minor local or routine events and administrative or political happenings that have no policy, constitutional, legal, economic, environmental, security, social, science or international angle; private life, gossip, personal remarks, sports scores or film and celebrity details (unless a policy, award, record, institution or other exam-relevant fact is attached); repeated statements, figures that mean nothing without context, and general background that every aspirant already knows. Before writing each point ask: could this be asked in Prelims or Mains (GS1-GS4 or the essay), or does it strengthen an answer or an interview reply? If not, leave it out. Use the material of the UPSC coaching institutes as your guide for what matters and how it is presented: refer to their current-affairs notes, compilations, editorial analyses and PYQ analyses (Vision IAS, Drishti IAS, Insights IAS, ForumIAS, IASbaba, PWOnlyIAS, NEXT IAS, Shankar IAS, Vajiram & Ravi, Deepak Yadav Education), cover the facts, facets and keywords the way they do, and give little or no space to what they skip. A shorter set of sharp, exam-relevant points is better than a long list with trivial ones.';
const extraLine = (o) => (o && o.extra && o.extra.trim() ? `ALSO INCLUDE (requested by the student): ${o.extra.trim()}. Cover these topics or facts fully, with explanation, under suitable headings in the static or related part.` : '');
const MAIN_TOPIC = 'MAIN TOPIC: first identify the main topic (or topics) of discussion in the article, for example the organisation, declaration, scheme, species, platform or issue the news is really about. In the static part give each main topic a complete profile so that the article is covered comprehensively: what it is, background and history, structure and features, legal status or legal basis, important provisions or facts, related bodies, and its link to India. Put the main topic first in the static part, then the supporting documents and concepts.';
const INDIA_VIEW = 'INDIA\'S PERSPECTIVE (important): include how the Government of India looks at this news: its official stand or response (statements of the MEA or the concerned ministry, votes, participation, policies, laws and schemes), its established position and doctrine on the issue (for example strategic autonomy, Neighbourhood First, Act East, multilateralism), India\'s interests, concerns and likely next steps, and any past India link. If India has made no statement on this particular news, say so and give India\'s established policy on the issue instead. Put it under a heading that names the subject (for example "India\'s stand on unilateral military action"), with sources such as MEA and PIB.';
const STATEMENT_EXPL = 'For PYQ and mock MCQs write the explanation statement by statement (Statement 1: Correct / Incorrect, with the reason), as the coaching notes do.';

const SEC = '{"level":1,"title":"","body":["short paragraph if needed"],"points":["short bullet point"]}';
const IMG = '{"title":"","caption":"","relates_to":"dynamic | static | related","place_after":"exact title of the heading after which this image should appear","prompt":"Generate an image: ..."}';
const MODEL = '{"introduction":["2-3 lines"],"body":[{"heading":"dimension or sub-heading","points":["point with fact / example / report"]}],"conclusion":["forward-looking lines"],"value_addition":["keywords, data, committee, case study or quote to add"]}';

const imageRule = (part) => {
  const scope = part === '1' ? 'the article and its dynamic part' : part === '2' ? 'the static background and related topics' : 'the whole topic: the article, the static background or any related topic';
  return `IMAGES: first analyse ${scope} and decide which images would really help an aspirant understand it; only then write prompts for those. ${IMG_ANALYSE} There is no limit on the number (0, 1, 2 or more), and an image may go anywhere: set "place_after" to the exact title of the heading after which it should appear (in the dynamic part, the static part or related facts). There is no separate image section, so choose the most useful place. Never add decorative or duplicate images. Look at the figures the UPSC coaching websites (Vision IAS, Drishti IAS, Insights IAS, ForumIAS, IASbaba, PWOnlyIAS, NEXT IAS) and the Deepak Yadav Education notes use for this topic. Good candidates: maps, timelines, flowcharts, process or cycle diagrams, comparison tables, organisation or structure charts, cut-away technical diagrams, and pictures of ships, aircraft, missiles, satellites and other equipment. Each "prompt" must be complete and ready to paste into Gemini: start with "Generate an image:"; state the image type, the exact short labels and text to show, the layout, a clean white background in a flat infographic style with a consistent colour scheme, and 16:9 (or portrait if the subject is tall). Use only facts you are sure of; for maps use correct geography; keep the text inside the image short and correctly spelled. Do NOT generate the images now.`;
};

export function buildPrompt(o = DEFAULT_OPTS, part = 'all') {
  const p1 = part !== '2', p2 = part !== '1';
  const hi = o.hindi;
  const k = [];
  if (p1) {
    k.push('"title":"short topic title"', '"syllabus":["GS2 · International Relations · Prelims + Mains"]', '"summary":["short bullet: what the article is about"]', `"dynamic":[${SEC}]`);
    if (o.images) k.push(`"images":[${IMG}]`);
    if (o.keywords) k.push('"keywords":[{"term":"","meaning":"one line, exam oriented"}]');
  }
  if (p2) {
    if (part === '2') k.push('"title":"same short topic title"');
    k.push(`"static":[${SEC}]`);
    k.push('"confusions":[{"point":"the confusing pair or point, e.g. X vs Y","clarification":"the clear distinction in one or two lines","tip":"short memory hint"}]');
    if (o.related) k.push(`"related_facts":[${SEC}]`);
    if (o.images) k.push(`"images":[${IMG}]`);
    k.push('"revision":["crisp, fact-packed point"]');
    if (o.pyqPrelims) k.push(`"pyq_prelims":[{"q":"",${hi ? '"q_hi":"","options_hi":["(A) ","(B) ","(C) ","(D) "],' : ''}"options":["(A) ","(B) ","(C) ","(D) "],"answer":"(B)","explanation":"","exam":"UPSC Prelims","year":2019,"syllabus":"GS1 · History · Prelims"}]`);
    if (o.pyqMains) k.push(`"pyq_mains":[{"q":"",${hi ? '"q_hi":"",' : ''}"exam":"UPSC Mains GS2","year":2018,"marks":15,"syllabus":"GS2 · Polity · Mains"}]`);
    if (o.mockPrelims) k.push(`"mock_prelims":[{"q":"",${hi ? '"q_hi":"","options_hi":["(A) ","(B) ","(C) ","(D) "],' : ''}"options":["(A) ","(B) ","(C) ","(D) "],"answer":"(C)","explanation":"","syllabus":"GS2 · Polity · Prelims"}]`);
    if (o.mockMains) k.push(`"mock_mains":[{"q":"",${hi ? '"q_hi":"",' : ''}"marks":15,"words":250,"syllabus":"GS2 · Polity · Mains","model_answer":${MODEL}${hi ? `,"model_answer_hi":${MODEL}` : ''}}]`);
  }
  const r = [];
  r.push(UPSC_FOCUS);
  r.push('STEP 1 - READ: read the whole article image line by line. Note every fact, figure, date, name, provision, organisation and keyword in it.');
  r.push('STEP 2 - RESEARCH: search the internet for this topic on UPSC coaching websites (Vision IAS, Drishti IAS, Insights IAS, ForumIAS, IASbaba, PWOnlyIAS, NEXT IAS, Shankar IAS, Vajiram & Ravi), on the Deepak Yadav Education YouTube channel, and on PIB, PRS, ministry / department websites, court judgments and official reports. Study how they cover the same topic (headings, bullet style, wording, number of words, diagrams, model answers) and follow the same structure, format and similar wording. Their length is your guide: maximum exam-oriented coverage with sufficient words, no padding and no skimping.');
  r.push(PYQ_FACETS);
  r.push(STYLE_MODEL);
  r.push('STEP 4 - BRAINSTORM: think constructively about the article and note ideas, innovative arguments, interpretations, examples, data and case studies that an aspirant can write in the exam, and the other related facts about the topic.');
  r.push('STEP 5 - CHECK before replying: go through the article paragraph by paragraph and confirm that every important fact, argument, suggestion, keyword and figure in it appears in your notes, and that every important term in the dynamic part is explained in the static part. Add anything missing.');
  if (p1) {
    r.push('DYNAMIC (what the article says): keep it lean and to the point (see DYNAMIC PART = LEAN). Include every important detail, fact, figure, date, name, provision, argument, strategy, suggestion and solution from the article, plus only the most important related information from PIB and other government sources. Leave out what is unimportant and do not explain what belongs in the static part. INTERPRET the article briefly, reading between the lines: what is really being said, why now, who gains and who loses, short-term and long-term effects, risks and unintended consequences. Address EVERY dimension the topic touches, each with several specific points: political, economic, social, legal / constitutional, administrative / governance, federal, technological, environmental, security, international / geopolitical, ethical, and gender / inclusion. Also cover: the background; the government\'s strategy and intent (why the change is being made and what the government is trying to achieve, with the scheme, law or policy behind it); well-built arguments for, against and analytical; ideas and examples that can be written in the exam; the problems, issues or demands involved; suggestions and solutions to address them (from the article, experts, committees and best practices); way forward. Arrange events in chronological order. Use bullet points ("points") wherever possible, with short sentences: fewest words, maximum coverage without over-explanation. Use simple words, but never change keywords, technical terms or proper names. Always name the ministry / department / regulator / organisation concerned.');
    r.push('HEADINGS: use proper headings (level 1), sub-headings (level 2) and sub-sub-headings (level 3); every point sits under a suitable heading. Every heading must name the actual subject of this article, for example "Why the Supreme Court upheld the ban", "Concerns of small merchants", "How the scheme will be funded". Never use generic labels such as "Constructive analysis", "Exam perspectives", "Brainstorming", "Government strategy" or "Interpretation" as a heading. Do not add a heading that says why the topic is important for UPSC; put that information under the relevant headings instead.');
    r.push(SUMMARY_RULE);
    r.push(DYNAMIC_LEAN);
    r.push(NO_FILLER);
    r.push(DYNAMIC_ORDER);
    r.push(ARGS_BULLETS);
    r.push(INNOVATIVE);
    r.push(INDIA_VIEW);
    r.push('DEFENCE / SCIENCE / TECHNOLOGY articles (ships, submarines, missiles, aircraft, satellites, reactors, vaccines, exercises, etc.): explain comprehensively everything an aspirant must know: type and class, developer / builder, ministry, project or programme, important dates, key specifications, weapons and sensors, indigenous content, significance, related platforms and partners, and use images.');
    r.push('SYLLABUS: tag the topic to the exact UPSC syllabus (paper, subject, stage), for example "GS1 · History · Prelims", "GS3 · Science & Technology · Prelims + Mains".');
    if (o.keywords) r.push('KEYWORDS: go through the article line by line and list EVERY important keyword in it, then add the important keywords from its context. Give a one-line meaning for each. There is no limit on the number. A short list means you missed terms: a normal article has dozens (for example sovereignty, territorial integrity, non-interference, track-two diplomacy, UN Charter).');
  }
  if (p2) {
    r.push('STATIC (background syllabus knowledge): it must fully support THIS article. For every important organisation, law or provision, scheme, concept, committee, judgment, index, place and historical development that the article mentions or depends on, give a proper explanation (what it is, when and why it was created, who runs it, key features, how it works, latest status), plus the international comparisons and related background an examiner could ask. This part carries the detailed explanation, so be generous here. Check your dynamic part and make sure nothing important in it is left unexplained here. Maximum coverage with sufficient words, in short bullets under proper subject-specific headings, arranged logically or chronologically (definitions, articles, acts, institutions, schemes, committees, judgments, reports and indices, geography, history). Name the ministry / department for each organisation. Do not add a heading about why the topic is important for UPSC.');
    r.push(MAIN_TOPIC);
    r.push(STATIC_DEPTH);
    r.push(CONFUSIONS);
    r.push(FOUNDATION);
    if (o.related) r.push(RELATED_MORE);
    if (extraLine(o)) r.push(extraLine(o));
    r.push('REVISION: crisp, fact-packed bullet points covering everything important.');
    if (o.pyqPrelims || o.pyqMains) r.push('PYQ: include ONLY questions that were genuinely asked in UPSC Prelims / UPSC Mains (or a named State PSC) and are related to this topic. Give the exact exam and year. If you are not certain a question was really asked, leave it out. Never invent, never modify. Return [] if none. Every PYQ needs a syllabus tag.');
    if (o.mockPrelims) r.push('MOCK PRELIMS: statement-based UPSC-style MCQs from the article and its static context, with answer and explanation.');
    if (o.mockMains) r.push('MOCK MAINS: 2 questions (one 150 words, one 250 words). Each needs a model answer in the format the major coaching institutes (Vision IAS, Drishti, Insights) use: an introduction of 2-3 lines (a definition, data or the latest development); a body with dimension-wise sub-headings and bullet points, each backed by a fact, example, committee or report; a forward-looking conclusion linked to constitutional values, SDGs or national vision; and "value_addition" (keywords, data, committees, case studies, quotes). Respect the word limit.');
    if (hi && (o.pyqPrelims || o.pyqMains || o.mockPrelims || o.mockMains)) r.push('HINDI: give a proper, natural Hindi translation of EVERY question ("q_hi"), using standard UPSC / official Hindi terminology; for MCQs also translate the options ("options_hi"); for mock Mains also give the full model answer in Hindi ("model_answer_hi", same structure).');
  }
  if (o.images) r.push(imageRule(part));
  r.push(BULLETS);
  if (p2 && (o.pyqPrelims || o.mockPrelims)) r.push(STATEMENT_EXPL);
  r.push(BOLD);
  return `MASTER PROMPT - indIAS Daily UPSC Current Affairs, PIB and Other

You are a senior UPSC CSE and State PSC mentor and current-affairs analyst working like the content team of a major coaching institute. The attached image is a newspaper article. Prepare aspirant-friendly, exam-oriented notes.

Reply with ONLY one JSON object inside ONE code block. No text before or after.${part === 'all' ? '' : `\nThis is PART ${part} of 2; I will send the other part separately.`}

JSON shape (use only these keys):
{${k.join(',\n')}}

Rules:
- "level" is 1 (heading), 2 (sub-heading) or 3 (sub-sub-heading).
- Plain text inside strings, except the ** bold marks. No other markdown, no line breaks inside a string, no trailing commas. Never put citation or search markup inside strings (nothing like [span_0], (start_span), [cite: 1] or source tags).
${r.map((x) => `- ${x}`).join('\n')}`;
}

/* ---------------- ChatGPT prompt (separate from the Gemini prompt above, which is unchanged) ---------------- */
export function buildChatGptPrompt(o = DEFAULT_OPTS, part = 'all') {
  const p1 = part !== '2', p2 = part !== '1';
  const hi = o.hindi;
  const k = [];
  if (p1) {
    k.push('"title":"short topic title"', '"syllabus":["GS2 · International Relations · Prelims + Mains"]', '"summary":["short bullet: what the article is about"]', `"dynamic":[${SEC}]`);
    if (o.images) k.push(`"images":[${IMG}]`);
    if (o.keywords) k.push('"keywords":[{"term":"","meaning":"short, exam oriented"}]');
  }
  if (p2) {
    if (part === '2') k.push('"title":"same short topic title"');
    k.push(`"static":[${SEC}]`);
    k.push('"confusions":[{"point":"the confusing pair or point, e.g. X vs Y","clarification":"the clear distinction in one or two lines","tip":"short memory hint"}]');
    if (o.related) k.push(`"related_facts":[${SEC}]`);
    if (o.images && part === '2') k.push(`"images":[${IMG}]`);
    k.push('"revision":["crisp, fact-packed point"]');
    if (o.pyqPrelims) k.push(`"pyq_prelims":[{"q":"",${hi ? '"q_hi":"","options_hi":["(A) ","(B) ","(C) ","(D) "],' : ''}"options":["(A) ","(B) ","(C) ","(D) "],"answer":"(B)","explanation":"one line","exam":"UPSC Prelims","year":2019,"syllabus":"GS1 · History · Prelims"}]`);
    if (o.pyqMains) k.push(`"pyq_mains":[{"q":"",${hi ? '"q_hi":"",' : ''}"exam":"UPSC Mains GS2","year":2018,"marks":15,"syllabus":"GS2 · Polity · Mains"}]`);
    if (o.mockPrelims) k.push(`"mock_prelims":[{"q":"",${hi ? '"q_hi":"","options_hi":["(A) ","(B) ","(C) ","(D) "],' : ''}"options":["(A) ","(B) ","(C) ","(D) "],"answer":"(C)","explanation":"one line","syllabus":"GS2 · Polity · Prelims"}]`);
    if (o.mockMains) k.push(`"mock_mains":[{"q":"",${hi ? '"q_hi":"",' : ''}"marks":15,"words":250,"syllabus":"GS2 · Polity · Mains","model_answer":${MODEL}${hi ? `,"model_answer_hi":${MODEL}` : ''}}]`);
  }
  const L = [];
  L.push('SOURCES (important): search the internet for this topic on UPSC coaching websites (Vision IAS, Drishti IAS, Insights IAS, ForumIAS, IASbaba, PWOnlyIAS, NEXT IAS, Shankar IAS, Vajiram & Ravi) and on the Deepak Yadav Education YouTube channel, and check the facts on PIB, PRS, ministry / department websites, court judgments and official reports. See what those sources include for this topic and how they arrange it (headings, bullet style, wording, diagrams) and follow the same structure, format and similar wording. Use them to judge what is relevant: include what they treat as important, and do not paste links or citations.');
  L.push(PYQ_FACETS);
  L.push(STYLE_MODEL);
  L.push('RELEVANCE (the most important rule): give only information that is relevant to UPSC / State PSC. Test every point with one question: could this be asked in Prelims or Mains (including the facets examiners have asked about before), or be needed to write an answer? If not, leave it out. Cover everything relevant fully, and nothing else: no padding and no repetition.');
  L.push('Write short, telegraphic bullets: one idea per point, no filler, no storytelling. Every fact appears ONCE in the whole reply: never repeat it in another section, in the keywords or in the revision.');
  if (p1) L.push('Dynamic part: lean, only what this article says that is relevant for the exam. Use "points"; use "body" only for a short lead-in.');
  if (p2) L.push('Static part: the background this article needs, explained in depth. Related facts: all the relevant ones. Revision: only the facts most likely to be asked.');
  L.push('Skip: narration of the article, background an aspirant already knows, examples with no exam value, generic statements, opinions, and anything not useful for UPSC / State PSC.');
  L.push('Do not write any introduction, conclusion text, apology or comment outside the JSON.');
  L.push('INCLUDE (compactly): every important fact, figure, date, name, provision, organisation (with its ministry / department), scheme or law; the government\'s strategy and intent; every important argument in the article (one line each: claim, reason, who argues it; grouped under for / against / neutral headings); the problems and demands; suggestions and solutions; the way forward. Arrange events in chronological order. Use simple words, but never change keywords, technical terms or proper names.');
  if (p1) L.push('Add only the most important related information from PIB and other government sources, in one or two lines each. For defence, science and technology articles give the key technical details (type or class, builder, ministry, dates, main specifications, weapons or sensors, indigenous content) in short bullets.');
  L.push('HEADINGS: "level" 1 = heading, 2 = sub-heading, 3 = sub-sub-heading. Every heading must name the actual subject of the article (for example "Concerns of small merchants"); never use generic headings such as "Analysis", "Interpretation", "Exam perspective" or "Why important for UPSC".');
  if (p1) L.push(SUMMARY_RULE);
  if (p1) L.push(DYNAMIC_LEAN);
  L.push(NO_FILLER);
  if (p1) L.push(DYNAMIC_ORDER);
  if (p1) L.push(ARGS_BULLETS);
  if (p1) L.push(INNOVATIVE);
  if (p1) L.push(INDIA_VIEW);
  if (p1) L.push('SYLLABUS: tag the topic to the exact UPSC syllabus (paper, subject, stage), for example "GS3 · Economy · Prelims + Mains".');
  if (p1 && o.keywords) L.push('KEYWORDS: every important keyword from the article and its context, each with a short meaning. No filler terms, but a short list means you missed terms: a normal article has dozens (for example sovereignty, territorial integrity, non-interference, track-two diplomacy, UN Charter).');
  if (p2) L.push(STATIC_DEPTH);
  if (p2) L.push(CONFUSIONS);
  if (p2) L.push(MAIN_TOPIC);
  if (p2) L.push(FOUNDATION);
  if (p2 && o.related) L.push(RELATED_MORE);
  if (extraLine(o)) L.push(extraLine(o));
  if (p2 && (o.pyqPrelims || o.pyqMains)) L.push('PYQ: only questions that were genuinely asked in UPSC (or a named State PSC) on this topic, with exact exam and year. If you are not certain, leave it out. Never invent. Return [] if none.');
  if (p2 && o.mockPrelims) L.push('MOCK PRELIMS: 5 statement-based UPSC-style MCQs with the answer and a one-line explanation.');
  if (p2 && o.mockMains) L.push('MOCK MAINS: 2 questions (150 and 250 words) with a compact model answer in coaching-institute format: introduction of at most 2 lines; body with 3-4 dimension-wise headings of 2-3 short points each; conclusion of at most 2 lines; 3-4 value-addition points.');
  if (hi && p2 && (o.pyqPrelims || o.pyqMains || o.mockPrelims || o.mockMains)) L.push('HINDI: give a proper, natural Hindi translation of every question ("q_hi", plus "options_hi" for MCQs, and "model_answer_hi" for mock Mains) in standard UPSC Hindi terminology.');
  if (o.images) L.push('IMAGES: only if an image is really needed to understand the topic (a map, flowchart, timeline, comparison table, technical diagram, or a picture of equipment). Look at which figures the coaching websites above use for this topic and decide from that. Only the ones that are needed; never decorative. Set "place_after" to the exact title of the heading after which it should appear. Each "prompt" starts with "Generate an image:" and states the image type, the exact short labels, a clean white background and a flat infographic style, 16:9. Do NOT generate the images now. ' + IMG_ANALYSE);
  L.push(BULLETS);
  if (p2 && (o.pyqPrelims || o.mockPrelims)) L.push(STATEMENT_EXPL);
  L.push(BOLD);
  L.push('FORMAT: plain text inside strings apart from the ** bold marks; no other markdown, no line breaks inside a string, no trailing commas, no citation or source markers of any kind.');
  return `You are a UPSC CSE and State PSC current-affairs note-maker. The attached image is a newspaper article. Make exam-focused notes from it.

Reply with ONLY one JSON object inside ONE code block.${part === 'all' ? '' : `\nThis is PART ${part} of 2; I will ask for the other part separately.`}

JSON shape (use only these keys):
{${k.join(',\n')}}

Rules:
${L.map((x) => `- ${x}`).join('\n')}`;
}

/* ---------------- reply parsing (accepts several JSON objects, e.g. Part 1 + Part 2) ---------------- */
function objectsIn(text) {
  const out = []; let depth = 0; let start = -1; let inStr = false; let esc = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (inStr) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') inStr = false; continue; }
    if (ch === '"') inStr = true;
    else if (ch === '{') { if (depth === 0) start = i; depth += 1; }
    else if (ch === '}' && depth > 0) { depth -= 1; if (depth === 0) out.push(text.slice(start, i + 1)); }
  }
  return out;
}
export function parseReply(text) {
  const t = stripMarkup(text).replace(/[\u201C\u201D]/g, '"');
  const parts = objectsIn(t); if (!parts.length) throw new Error('No JSON found. Copy the whole reply from Gemini, including the { and } symbols.');
  const merged = {};
  parts.forEach((s) => {
    let o; try { o = JSON.parse(s); } catch { throw new Error('A reply is cut off or not valid JSON. Ask Gemini: "Continue and give the complete JSON again."'); }
    Object.keys(o).forEach((key) => {
      if (Array.isArray(o[key])) merged[key] = (merged[key] || []).concat(o[key]);
      else if (!merged[key]) merged[key] = o[key];
    });
  });
  return merged;
}

/* ---------------- block builders ---------------- */
/** Gemini search markup such as [span_0](start_span)...[span_0](end_span), [cite_start], [cite: 1] */
export const stripMarkup = (t) => String(t ?? '')
  .replace(/\[span_\d+\]\((?:start|end)_span\)/g, '')
  .replace(/\[cite_(?:start|end)\]/g, '')
  .replace(/\[cite:[^\]]*\]/g, '')
  .replace(/\uE200[^\uE201]*\uE201/g, '')
  .replace(/[\uE200-\uE2FF]/g, '')
  .replace(/【[^】]*】/g, '')
  .replace(/[ \t]{2,}/g, ' ');
const esc = (s) => stripMarkup(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const plain = (s) => esc(String(s ?? '').replace(/\*\*|==/g, ''));
/** **bold** and ==highlight== marks from Gemini */
const fm = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/==(.+?)==/g, '<mark data-color="#FFF200" style="background-color:#FFF200">$1</mark>');
const bar = (tag, bg, text, extra = '') => `<${tag} style="background-color:${bg};${extra}"><span style="color:#ffffff">${plain(text)}</span></${tag}>`;
const TONES = { peach: '#FBE4D5', mint: '#C6EFCE', amber: '#FFC000', sky: '#D3EEFA' };
export const BLOCKS = {
  banner: (t) => bar('h1', '#C00000', t, 'text-align:center'),
  section: (t) => bar('h2', '#104818', t),
  sub: (t, tone = 'peach') => `<h3 style="background-color:${TONES[tone] || tone}">${plain(t)}</h3>`,
  subsub: (t) => `<h4><u>${plain(t)}</u></h4>`,
  red: (t) => bar('h2', '#C00000', t),
  point: (t) => `<p><span style="color:#0F6FC6">◆</span> ${fm(t)}</p>`,
  sub2: (t) => `<p style="margin-left:18px"><span style="color:#0F6FC6">●</span> ${fm(t)}</p>`,
  note: (t) => `<div data-callout="tip"><p>${esc(t)}</p></div>`,
  info: (t) => `<div data-callout="info"><p>${esc(t)}</p></div>`,
  why: (t = 'Write the news summary here.') => bar('h2', '#104818', '📰 Why in News?') + `<p>${esc(t)}</p>`,
  img: (url, w, border = false) => `<p${border ? ' data-borders="border:1.5px solid #000000;line-height:0"' : ''}><img src="${url}" style="width:${w}px"></p>`,
  imgidea: (title, caption, prompt) => `<div data-callout="imgidea"><p><strong>${plain(title)}</strong></p><p>${plain(caption)}</p><p><em>${plain(prompt)}</em></p></div>`,
  // each line carries the box styling (airy spacing, outline), so a long PYQ flows from column to column and page to page
  pyq: (inner) => {
    const ps = [`<p><strong><span style="color:#B45309">🎯 PREVIOUS YEAR QUESTION</span></strong></p>`, ...(inner.match(/<p>[\s\S]*?<\/p>/g) || [inner])];
    const st = (i, n) => {
      const first = i === 0; const last = i === n - 1;
      return `margin:${last ? '0 0 10px' : '0'};padding:${first ? '8px' : '5px'} 10px ${last ? '8px' : '5px'};line-height:1.6;background-color:#FFF4CC;border-left:4px solid #E6A700;border-right:1px solid #E6A700;${first ? 'border-top:1px solid #E6A700;border-radius:10px 10px 0 0;' : ''}${last ? 'border-bottom:1px solid #E6A700;border-radius:0 0 10px 10px;' : ''}`;
    };
    return ps.map((x, i) => x.replace(/^<p>/, `<p data-borders="${st(i, ps.length)}">`)).join('');
  },

};
export const TONE_NAMES = Object.keys(TONES);

const sec = (s) => {
  const l = Math.min(3, Math.max(1, s.level || 1));
  return (l === 1 ? BLOCKS.section : l === 2 ? BLOCKS.sub : BLOCKS.subsub)(s.title)
    + (s.body || []).map((t) => `<p>${fm(t)}</p>`).join('') + (s.points || []).map(BLOCKS.point).join('');
};
const label = (parts, hl) => { const t = esc(parts.filter(Boolean).join(' · ')); return hl ? `<mark data-color="#FFD966" style="background-color:#FFD966"><strong>[${t}]</strong></mark>` : `<strong>[${t}]</strong>`; };
const mcqInner = (x, tag, hl, hindi) => `${hl ? `<p>${label(tag, hl)}</p>` : `<p>${label(tag, hl)} `}${hl ? '<p>' : ''}<strong>Q. ${fm(x.q)}</strong></p>${(x.options || []).map((o) => `<p>${fm(o)}</p>`).join('')}${hindi && x.q_hi ? `<p><strong>प्र. ${fm(x.q_hi)}</strong></p>${(x.options_hi || []).map((o) => `<p>${fm(o)}</p>`).join('')}` : ''}<p>✅ <strong>Correct Answer: ${esc(x.answer)}</strong>${x.explanation ? ` — ${fm(x.explanation)}` : ''}</p>`;
const mcq = (x, tag, hindi) => mcqInner(x, tag, false, hindi);
const struct = (a) => (a || []).map(BLOCKS.point).join('');
export const imagePrompts = (d) => (d.images || []).filter((m) => m.prompt).map((m, i) => `Image ${i + 1}: ${m.title || ''}\n${m.prompt}`).join('\n\n');

/** model answer in the coaching-institute format; accepts the new object or an older flat list */
function modelAnswer(m, hi) {
  if (!m) return '';
  if (Array.isArray(m)) return `<h4>${hi ? 'आदर्श उत्तर' : 'Model Answer'}</h4>${struct(m)}`;
  let h = `<h4>${hi ? 'आदर्श उत्तर' : 'Model Answer'}</h4>`;
  if ((m.introduction || []).length) h += `<p><strong>${hi ? 'भूमिका' : 'Introduction'}</strong></p>${m.introduction.map((t) => `<p>${fm(t)}</p>`).join('')}`;
  (m.body || []).forEach((b) => { h += `<p><strong><u>${plain(b.heading)}</u></strong></p>${(b.points || []).map(BLOCKS.point).join('')}`; });
  if ((m.conclusion || []).length) h += `<p><strong>${hi ? 'निष्कर्ष' : 'Conclusion'}</strong></p>${m.conclusion.map((t) => `<p>${fm(t)}</p>`).join('')}`;
  if ((m.value_addition || []).length) h += `<p><strong>${hi ? 'मूल्य संवर्धन' : 'Value addition'}</strong></p>${m.value_addition.map(BLOCKS.point).join('')}`;
  return h;
}
const norm = (t) => String(t || '').toLowerCase().replace(/\*\*|==/g, '').replace(/[^a-z0-9\u0900-\u097f]+/g, ' ').trim();

/** d = merged Gemini JSON, img = {url,w,h} (the article), opts = include flags, extras = [{url,caption}] images the user already has */
export function buildNotesHtml(d, img, opts = DEFAULT_OPTS, extras = []) {
  const one = opts.cols === 1; const colW = one ? FULL_W : COL_W;
  const tall = img.h / img.w > 1.25;
  const h = [BLOCKS.banner(d.title || 'Article Notes'), tall && !one ? '' : BLOCKS.img(img.url, one ? Math.min(FULL_W, tall ? 460 : FULL_W) : FULL_W, true), tall && !one ? BLOCKS.img(img.url, COL_W, true) : ''];
  if ((d.syllabus || []).length) h.push(BLOCKS.info(`📌 Syllabus: ${d.syllabus.join('  |  ')}`));

  const sumList = Array.isArray(d.summary) ? d.summary : (d.summary ? [d.summary] : []);
  if (sumList.length) h.push(BLOCKS.red('📝 Summary: What the article is about'), ...sumList.map(BLOCKS.point));

  // images go wherever Gemini placed them (after a named heading); the rest after the dynamic or static part
  const ideas = opts.images ? (d.images || []).map((x, i) => ({ ...x, extra: extras[i], used: false })) : [];
  extras.slice(ideas.length).forEach((e) => ideas.push({ title: '', caption: e.caption, extra: e, used: false, relates_to: 'dynamic' }));
  const imgHtml = (x) => (x.extra ? `${BLOCKS.img(x.extra.url, colW, true)}<p><em>${plain(x.extra.caption || x.caption || x.title || '')}</em></p>` : BLOCKS.imgidea(x.title, x.caption, x.prompt));
  const sections = (list, tail) => {
    const out = [];
    (list || []).forEach((sc) => {
      out.push(sec(sc));
      const t = norm(sc.title);
      ideas.forEach((x) => { const a = norm(x.place_after); if (!x.used && a && t && (a === t || a.includes(t) || t.includes(a))) { x.used = true; out.push(imgHtml(x)); } });
    });
    ideas.forEach((x) => { if (!x.used && (tail === 'static' ? x.relates_to === 'static' || x.relates_to === 'related' : x.relates_to !== 'static' && x.relates_to !== 'related')) { x.used = true; out.push(imgHtml(x)); } });
    return out;
  };
  h.push(BLOCKS.red('📰 Dynamic: What the article says'), ...sections(d.dynamic, 'dynamic'));
  if (opts.keywords && (d.keywords || []).length) h.push(BLOCKS.section('🔑 Keywords'), ...d.keywords.map((x) => `<p><span style="color:#0F6FC6">◆</span> <strong>${plain(x.term)}</strong>: ${fm(x.meaning)}</p>`));
  h.push(BLOCKS.red('📚 Static: Background to know'), ...sections(d.static, 'static'));
  if ((d.confusions || []).length) h.push(BLOCKS.red('⚠ Possible confusions in the exam'), ...d.confusions.map((x) => (typeof x === 'string' ? BLOCKS.point(x) : BLOCKS.point(`**${plain(x.point || x.title || '')}:** ${x.clarification || x.answer || ''}${x.tip ? ` 💡 ${x.tip}` : ''}`))));
  if (opts.related && (d.related_facts || []).length) h.push(BLOCKS.red('🔎 Related facts likely in exams'), ...d.related_facts.map(sec));
  ideas.filter((x) => !x.used).forEach((x) => { x.used = true; h.push(imgHtml(x)); });
  if ((d.revision || []).length) h.push(BLOCKS.section('⚡ Revision Pointers'), ...d.revision.map(BLOCKS.point));
  if (opts.pyqPrelims && (d.pyq_prelims || []).length) h.push(BLOCKS.red('🎯 Previous Year Questions – Prelims'), ...d.pyq_prelims.map((x) => BLOCKS.pyq(mcqInner(x, ['PYQ', x.exam, x.year, x.syllabus], true, opts.hindi))));
  if (opts.pyqMains && (d.pyq_mains || []).length) h.push(BLOCKS.red('🎯 Previous Year Questions – Mains'), ...d.pyq_mains.map((x) => BLOCKS.pyq(`<p>${label(['PYQ', x.exam, x.year, x.marks ? `${x.marks} marks` : '', x.syllabus], true)}</p><p><strong>${fm(x.q)}</strong></p>${opts.hindi && x.q_hi ? `<p><strong>${fm(x.q_hi)}</strong></p>` : ''}`)));
  if (opts.mockPrelims && (d.mock_prelims || []).length) h.push(BLOCKS.red('Prelims Practice Questions'), ...d.mock_prelims.map((x) => mcq(x, ['Mock', x.syllabus], opts.hindi)));
  if (opts.mockMains && (d.mock_mains || []).length) {
    h.push(BLOCKS.red('Mains Practice Questions'));
    d.mock_mains.forEach((x) => {
      h.push(`<p>${label(['Mock', x.marks ? `${x.marks} marks` : '', x.words ? `${x.words} words` : '', x.syllabus])} <strong>${fm(x.q)}</strong></p>`);
      if (opts.hindi && x.q_hi) h.push(`<p><strong>${fm(x.q_hi)}</strong></p>`);
      h.push(modelAnswer(x.model_answer || (x.answer ? x.answer : null), false));
      if (!x.model_answer && (x.structure || []).length) h.push('<h4>Answer Structure</h4>', struct(x.structure));
      if (opts.hindi && (x.model_answer_hi || x.answer_hi)) h.push(modelAnswer(x.model_answer_hi || x.answer_hi, true));
    });
  }
  return h.join('');
}
export const PAGE_BREAK = '<div data-page-break></div>';

/* ---------------- cover page (full-bleed image) ---------------- */
const loadImg = (src) => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
export const DEFAULT_COVER = {
  date: '', coverage: 'GS I, II, III, IV & Essay', platform: 'YouTube / Telegram PDF',
  vision: 'To democratize civil services preparation by breaking financial and geographical barriers, ensuring every aspirant—regardless of rural roots or economic background—has equal access to top-tier mentorship.',
  mission: 'To deliver high-quality, affordable digital coaching on YouTube. We replace rote learning with conceptual clarity and strategic guidance so rural aspirants can compete on equal footing with the privileged.',
  commitments: 'Democratize Access: Deliver free/affordable YouTube coaching removing financial barriers.\nConceptual Clarity: Move beyond facts to deep analytical understanding of issues.\nLevel the Playing Field: Provide top-tier exam strategies for rural & poor aspirants.\nStructured Guidance: Honest, focused direction to navigate UPSC & State PSC syllabi.',
  topics: 'THE HINDU & IE POINTERS|PIB & GOVT. SCHEMES|MAINS ANSWER STRUCTURE|PRELIMS FACTS',
  footerL: 'Free & Affordable Education Initiative', footerR: 'Connect with us: www.indias.com',
};
export async function makeCover(o) {
  const c = document.createElement('canvas'); c.width = 1588; c.height = 2246;
  const x = c.getContext('2d'); x.scale(2, 2);
  const GOLD = '#C9A634'; const RED = '#B3262E'; const F = 'Arial, Helvetica, sans-serif';
  const rr = (a, b, w, h, r) => { x.beginPath(); x.moveTo(a + r, b); x.arcTo(a + w, b, a + w, b + h, r); x.arcTo(a + w, b + h, a, b + h, r); x.arcTo(a, b + h, a, b, r); x.arcTo(a, b, a + w, b, r); x.closePath(); };
  const txt = (t, px, y, size, color, weight = 'bold', align = 'center', ls = 0) => { x.font = `${weight} ${size}px ${F}`; x.fillStyle = color; x.textAlign = align; if ('letterSpacing' in x) x.letterSpacing = `${ls}px`; x.fillText(t, px, y); if ('letterSpacing' in x) x.letterSpacing = '0px'; };
  const wrap = (t, a, y, w, size, color, lh, weight = 'normal') => { x.font = `${weight} ${size}px ${F}`; x.fillStyle = color; x.textAlign = 'left'; let line = ''; t.split(' ').forEach((wd) => { const n = line ? `${line} ${wd}` : wd; if (x.measureText(n).width > w && line) { x.fillText(line, a, y); y += lh; line = wd; } else line = n; }); x.fillText(line, a, y); return y; };
  // background: slate blue with a faint grid
  const g = x.createLinearGradient(0, 0, 0, 1123); g.addColorStop(0, '#2B4268'); g.addColorStop(0.55, '#1E3050'); g.addColorStop(1, '#16233B');
  x.fillStyle = g; x.fillRect(0, 0, 794, 1123);
  x.strokeStyle = 'rgba(255,255,255,.05)'; x.lineWidth = 1;
  for (let i = 0; i <= 8; i += 1) { x.beginPath(); x.moveTo(i * 100 - 20, 0); x.lineTo(i * 100 - 60, 1123); x.stroke(); }
  for (let i = 1; i < 11; i += 1) { x.beginPath(); x.moveTo(0, i * 105); x.lineTo(794, i * 105 - 12); x.stroke(); }
  // gold double frame
  x.strokeStyle = GOLD; x.lineWidth = 2; x.strokeRect(19, 19, 756, 1085); x.lineWidth = 0.8; x.strokeRect(26, 26, 742, 1071);
  // logo tile
  const logo = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = LOGO; });
  x.save(); x.shadowColor = 'rgba(0,0,0,.45)'; x.shadowBlur = 14; x.fillStyle = '#fff'; x.fillRect(303, 53, 189, 189); x.restore(); x.drawImage(logo, 303, 53, 189, 189);
  // slogan pill
  x.fillStyle = 'rgba(120,20,30,.92)'; rr(173, 256, 448, 29, 14.5); x.fill(); x.strokeStyle = '#D9363E'; x.lineWidth = 1.5; rr(173, 256, 448, 29, 14.5); x.stroke();
  txt(BRAND.slogan.toUpperCase(), 397, 275.5, 11.5, '#fff', 'bold', 'center', 1.4);
  // title block
  x.fillStyle = 'rgba(14,24,46,.78)'; x.fillRect(68, 297, 658, 135); x.fillStyle = 'rgba(255,255,255,.25)'; x.fillRect(68, 297, 658, 1);
  txt('DAILY CURRENT AFFAIRS', 397, 343, 33, '#fff', 'bold', 'center', 0.5);
  txt('NOTES & COMPREHENSIVE ANALYSIS', 397, 385, 28, GOLD, 'bold', 'center', 0.5);
  txt('ESSENTIAL FOR UPSC CSE & STATE PSC PREPARATION', 397, 413, 13, '#fff', 'bold', 'center', 1.2);
  // info bar (one line)
  x.fillStyle = 'rgba(14,24,46,.7)'; rr(68, 452, 658, 36, 6); x.fill(); x.strokeStyle = GOLD; x.lineWidth = 1; rr(68, 452, 658, 36, 6); x.stroke();
  const info = [['DATE:', o.date || ''], ['COVERAGE:', o.coverage || ''], ['PLATFORM:', o.platform || '']];
  x.font = `bold 12px ${F}`; const widths = info.map(([k, v]) => x.measureText(`${k} `).width + x.measureText(v).width); const gap = 22;
  let cx = 397 - (widths.reduce((a, b) => a + b, 0) + gap * 2) / 2;
  info.forEach(([k, v], i) => { txt(`${k} `, cx, 475, 12, GOLD, 'bold', 'left'); txt(v, cx + x.measureText(`${k} `).width, 475, 12, '#fff', 'bold', 'left'); cx += widths[i] + gap; });
  // vision / mission cards
  [['OUR VISION', o.vision, 68, GOLD], ['OUR MISSION', o.mission, 405, RED]].forEach(([t, v, a, col]) => {
    x.fillStyle = 'rgba(14,24,46,.82)'; x.fillRect(a, 507, 321, 143); x.fillStyle = col; x.fillRect(a, 507, 4, 143);
    txt(t, a + 20, 536, 14, GOLD, 'bold', 'left', 1.2); wrap(v || '', a + 20, 562, 285, 11.5, '#fff', 17.5);
  });
  // commitments
  x.fillStyle = 'rgba(14,24,46,.82)'; rr(68, 670, 658, 147, 6); x.fill();
  txt('OUR INSTITUTIONAL COMMITMENTS', 87, 697, 14, GOLD, 'bold', 'left', 1); x.fillStyle = GOLD; x.fillRect(87, 708, 620, 1);
  (o.commitments || '').split('\n').filter(Boolean).slice(0, 4).forEach((ln, i) => {
    const k = ln.indexOf(':'); const t = k > 0 ? ln.slice(0, k + 1) : ''; const d = k > 0 ? ln.slice(k + 1).trim() : ln;
    const ax = i % 2 ? 420 : 98; const ay = 733 + Math.floor(i / 2) * 45;
    x.fillStyle = '#D9363E'; x.beginPath(); x.moveTo(ax - 1, ay - 4); x.lineTo(ax + 4, ay - 9); x.lineTo(ax + 9, ay - 4); x.lineTo(ax + 4, ay + 1); x.closePath(); x.fill();
    x.font = `bold 11px ${F}`; const tw = x.measureText(`${t} `).width; txt(t, ax + 16, ay, 11, '#fff', 'bold', 'left');
    x.font = `11px ${F}`; x.fillStyle = '#fff'; x.textAlign = 'left'; let line = ''; let y = ay; let first = true; const words = d.split(' ');
    words.forEach((wd) => { const n = line ? `${line} ${wd}` : wd; const lim = first ? 290 - tw : 290; if (x.measureText(n).width > lim && line) { x.fillText(line, first ? ax + 16 + tw : ax + 16, y); y += 15; line = wd; first = false; } else line = n; });
    x.fillText(line, first ? ax + 16 + tw : ax + 16, y);
  });
  // topics strip
  x.fillStyle = 'rgba(110,20,28,.75)'; rr(68, 836, 658, 32, 6); x.fill(); x.strokeStyle = '#C0343C'; x.lineWidth = 1; rr(68, 836, 658, 32, 6); x.stroke();
  const tps = (o.topics || '').split('|').filter(Boolean).map((t) => `•  ${t.trim()}`); x.font = `bold 10px ${F}`;
  const tw2 = tps.map((t) => x.measureText(t).width); const g2 = 14; let tx = 397 - (tw2.reduce((a, b) => a + b, 0) + g2 * (tps.length - 1)) / 2;
  tps.forEach((t, i) => { txt(t, tx, 856.5, 10, '#fff', 'bold', 'left'); tx += tw2[i] + g2; });
  // footer
  x.fillStyle = GOLD; x.globalAlpha = 0.6; x.fillRect(68, 1041, 658, 1); x.globalAlpha = 1;
  txt(o.footerL || '', 68, 1070, 12, '#E6E9F0', 'normal', 'left'); txt(o.footerR || '', 726, 1070, 12, '#E6E9F0', 'normal', 'right');
  return c.toDataURL('image/jpeg', 0.92);
}
export const coverHtml = (url) => BLOCKS.img(url, 794);

/* ---------------- image helper ---------------- */
export const fileToJpeg = (file, max = 1400) => new Promise((res, rej) => {
  const r = new FileReader(); r.onerror = () => rej(new Error('Could not read image'));
  r.onload = () => {
    const i = new Image(); i.onerror = () => rej(new Error('Not a valid image'));
    i.onload = () => { const s = Math.min(1, max / Math.max(i.width, i.height)); const c = document.createElement('canvas'); c.width = Math.round(i.width * s); c.height = Math.round(i.height * s); c.getContext('2d').drawImage(i, 0, 0, c.width, c.height); res({ url: c.toDataURL('image/jpeg', 0.85), w: c.width, h: c.height }); };
    i.src = r.result;
  };
  r.readAsDataURL(file);
});

/** file name for exported notes: date followed by the institute title */
export const exportBase = (name, meta) => {
  if (!meta || !meta.paged) return name;
  const d = new Date(); const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getDate())}-${p(d.getMonth() + 1)}-${d.getFullYear()} indIAS Daily UPSC Current Affairs, PIB and Other`;
};
