import { Extension, Node, mergeAttributes } from '@tiptap/core';
import { Plugin, PluginKey } from '@tiptap/pm/state';
import Image from '@tiptap/extension-image';
import { SHAPE_DEFAULTS, shapeCss } from './shapeBox.js';
import { createImageNodeView } from './components/ImageView.jsx';

const px = (v) => (v || v === 0 ? `${v}px` : null);

/* Font size on the textStyle mark, e.g. "14pt" */
export const FontSize = Extension.create({
  name: 'fontSize',
  addGlobalAttributes() {
    return [{ types: ['textStyle'], attributes: { fontSize: {
      default: null,
      parseHTML: (el) => el.style.fontSize || null,
      renderHTML: (a) => (a.fontSize ? { style: `font-size:${a.fontSize}` } : {}),
    } } }];
  },
  addCommands() {
    return {
      setFontSize: (size) => ({ chain }) => chain().setMark('textStyle', { fontSize: size }).run(),
    };
  },
});

/* Underline styles, double strikethrough and text effects */
export const TextExtras = Extension.create({
  name: 'textExtras',
  addGlobalAttributes() {
    return [{ types: ['textStyle'], attributes: {
      deco: { default: null, parseHTML: (el) => el.style.textDecoration || null, renderHTML: (a) => (a.deco ? { style: `text-decoration:${a.deco}` } : {}) },
      effect: { default: null, parseHTML: (el) => el.getAttribute('data-effect'), renderHTML: (a) => (a.effect ? { 'data-effect': a.effect } : {}) },
    } }];
  },
});

/* Paragraph / heading layout: spacing, indents, shading, borders, named style */
export const BlockLayout = Extension.create({
  name: 'blockLayout',
  addGlobalAttributes() {
    const style = (key, css) => ({
      default: null,
      parseHTML: (el) => el.style[key] || null,
      renderHTML: (a) => (a[key] ? { style: `${css}:${a[key]}` } : {}),
    });
    return [{ types: ['paragraph', 'heading'], attributes: {
      lineHeight: style('lineHeight', 'line-height'),
      marginLeft: style('marginLeft', 'margin-left'),
      marginRight: style('marginRight', 'margin-right'),
      marginTop: style('marginTop', 'margin-top'),
      marginBottom: style('marginBottom', 'margin-bottom'),
      textIndent: style('textIndent', 'text-indent'),
      backgroundColor: style('backgroundColor', 'background-color'),
      borders: {
        default: null,
        parseHTML: (el) => el.getAttribute('data-borders'),
        renderHTML: (a) => (a.borders ? { 'data-borders': a.borders, style: a.borders } : {}),
      },
      pstyle: {
        default: null,
        parseHTML: (el) => (/ps-(\w+)/.exec(el.className || '') || [])[1] || null,
        renderHTML: (a) => (a.pstyle ? { class: `ps-${a.pstyle}` } : {}),
      },
    } }];
  },
});

const newBreakId = () => Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-3);
export const PageBreak = Node.create({
  name: 'pageBreak', group: 'block', atom: true, selectable: true,
  addAttributes() {
    return { id: { default: null, parseHTML: (el) => el.getAttribute('data-id') || null, renderHTML: (a) => (a.id ? { 'data-id': a.id } : {}) } };
  },
  parseHTML() { return [{ tag: 'div[data-page-break]' }]; },
  renderHTML({ HTMLAttributes }) { return ['div', { 'data-page-break': '', class: 'page-break', ...HTMLAttributes }]; },
  /* every page break gets its own id, so a drawing can follow its page when pages are added or removed before it */
  addProseMirrorPlugins() {
    return [new Plugin({
      key: new PluginKey('pageBreakIds'),
      appendTransaction(trs, _old, state) {
        if (!trs.some((t) => t.docChanged)) return null;
        const seen = new Set(); const fix = [];
        state.doc.descendants((node, pos) => {
          if (node.type.name !== 'pageBreak') return;
          const id = node.attrs.id;
          if (!id || seen.has(id)) fix.push(pos); else seen.add(id);
        });
        if (!fix.length) return null;
        const tr = state.tr;
        fix.forEach((pos) => { tr.setNodeMarkup(pos, undefined, { id: newBreakId() }); });
        return tr;
      },
    })];
  },
});
export const ColumnBreak = Node.create({
  name: 'columnBreak', group: 'block', atom: true, selectable: true,
  parseHTML() { return [{ tag: 'div[data-column-break]' }]; },
  renderHTML() { return ['div', { 'data-column-break': '', class: 'column-break' }]; },
});

/* Editable text shape: banner, rectangle, pill, arrow, speech bubble... */
const kebab = (k) => k.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`);
const readAttr = (k, def, el) => {
  const raw = el.getAttribute(`data-${kebab(k)}`);
  if (raw === null) return def;
  if (typeof def === 'boolean') return raw === '1';
  if (typeof def === 'number' || k === 'radius') return raw === '' ? def : Number(raw);
  return raw;
};
export const ShapeBox = Node.create({
  name: 'shapeBox', group: 'block', content: 'block+', defining: true,
  addAttributes() {
    return Object.fromEntries(Object.entries(SHAPE_DEFAULTS).map(([k, def]) => [k, { default: def, parseHTML: (el) => readAttr(k, def, el), renderHTML: () => ({}) }]));
  },
  parseHTML() { return [{ tag: 'div[data-shape-box]' }]; },
  renderHTML({ node }) {
    const a = node.attrs;
    const data = {};
    Object.keys(SHAPE_DEFAULTS).forEach((k) => { const v = a[k]; data[`data-${kebab(k)}`] = typeof v === 'boolean' ? (v ? '1' : '0') : (v ?? ''); });
    return ['div', { 'data-shape-box': '', class: 'shape-box', ...data, style: shapeCss(a) }, 0];
  },
});

/* A run of content laid out in columns (imported from Word sections with 2 or more columns) */
export const SectionColumns = Node.create({
  name: 'sectionColumns', group: 'block', content: 'block+', defining: true,
  addAttributes() {
    return {
      columns: { default: 2, parseHTML: (el) => Number(el.getAttribute('data-columns')) || 2, renderHTML: () => ({}) },
      gap: { default: 32, parseHTML: (el) => Number(el.getAttribute('data-gap')) || 32, renderHTML: () => ({}) },
      sep: { default: false, parseHTML: (el) => el.getAttribute('data-sep') === '1', renderHTML: () => ({}) },
    };
  },
  parseHTML() { return [{ tag: 'div[data-columns]' }]; },
  renderHTML({ node }) {
    const { columns, gap, sep } = node.attrs;
    return ['div', { 'data-columns': columns, 'data-gap': gap, ...(sep ? { 'data-sep': '1' } : {}), style: `column-count:${columns};column-gap:${gap}px;${sep ? 'column-rule:1px solid #94a3b8;' : ''}` }, 0];
  },
});

export const Toc = Node.create({
  name: 'toc', group: 'block', content: 'block+', defining: true,
  parseHTML() { return [{ tag: 'div[data-toc]' }]; },
  renderHTML() { return ['div', { 'data-toc': '', class: 'toc' }, 0]; },
});

export const Callout = Node.create({
  name: 'callout', group: 'block', content: 'block+', defining: true,
  addAttributes() {
    return { type: { default: 'info', parseHTML: (el) => el.getAttribute('data-callout') || 'info', renderHTML: (a) => ({ 'data-callout': a.type }) } };
  },
  parseHTML() { return [{ tag: 'div[data-callout]' }]; },
  renderHTML({ HTMLAttributes }) { return ['div', mergeAttributes(HTMLAttributes, { class: 'callout' }), 0]; },
  addCommands() { return { setCallout: (type) => ({ commands }) => commands.wrapIn(this.name, { type }) }; },
});

/* NotePicture: a picture for the AI notes (the article photo and the pictures made with Gemini). It is a block of its own, drawn by plain DOM code
   (a <figure> holding an <img>) so it does not depend on the image node view. If a picture cannot be shown, a red note says so instead of an empty frame. */
export const NotePicture = Node.create({
  name: 'notePicture', group: 'block', atom: true, selectable: true, draggable: false,
  addAttributes() {
    return { src: { default: null }, width: { default: 339 }, border: { default: true } };
  },
  parseHTML() {
    return [{
      tag: 'figure[data-note-picture]',
      getAttrs: (el) => ({
        src: (el.querySelector('img') && el.querySelector('img').getAttribute('src')) || el.getAttribute('data-src') || null,
        width: parseFloat(el.getAttribute('data-width')) || 339,
        border: el.getAttribute('data-border') !== '0',
      }),
    }];
  },
  renderHTML({ node }) {
    const a = node.attrs;
    return ['figure', { 'data-note-picture': '', 'data-width': String(a.width), 'data-border': a.border ? '1' : '0', style: 'margin:0;padding:0;line-height:0' },
      ['img', { src: a.src || '', alt: '', style: `display:block;width:${a.width}px;max-width:100%;height:auto;${a.border ? 'border:1.5px solid #000000;box-sizing:border-box;' : ''}` }]];
  },
  addNodeView() {
    return ({ node, getPos, editor }) => {
      const dom = document.createElement('figure');
      dom.setAttribute('data-note-picture', ''); dom.style.cssText = 'margin:0;padding:0;line-height:0;max-width:100%';
      const img = document.createElement('img'); img.alt = ''; img.draggable = false;
      const paint = (n) => {
        dom.setAttribute('data-width', String(n.attrs.width)); dom.setAttribute('data-border', n.attrs.border ? '1' : '0');
        img.style.cssText = `display:block;width:${n.attrs.width}px;max-width:100%;height:auto;${n.attrs.border ? 'border:1.5px solid #000000;box-sizing:border-box;' : ''}`;
        if (img.getAttribute('src') !== (n.attrs.src || '')) img.setAttribute('src', n.attrs.src || '');
      };
      img.onerror = () => {
        if (dom.querySelector('.np-err')) return;
        const m = document.createElement('div'); m.className = 'np-err';
        m.style.cssText = 'line-height:1.3;font-size:12px;font-style:italic;color:#b91c1c;border:1px dashed #b91c1c;padding:6px';
        m.textContent = 'This picture could not be shown. Add it again.'; dom.appendChild(m);
      };
      img.onload = () => { const m = dom.querySelector('.np-err'); if (m) m.remove(); };
      paint(node); dom.appendChild(img);
      let cur = node;
      // double tap: next size (a column, wider, the full width of the page)
      dom.addEventListener('dblclick', (ev) => {
        ev.preventDefault();
        try {
          const sizes = [339, 460, 706], w = Number(cur.attrs.width) || 339, next = sizes.find((x) => x > w + 1) || sizes[0];
          editor.view.dispatch(editor.view.state.tr.setNodeMarkup(getPos(), undefined, { ...cur.attrs, width: next }));
        } catch { /* ignore */ }
      });
      return { dom, update: (n) => { if (n.type.name !== 'notePicture') return false; cur = n; paint(n); return true; }, ignoreMutation: () => true };
    };
  },
});

/* Image: inline or floating, resizable, with its own node view (handles + toolbar) */
export const WordImage = Image.extend({
  inline: true,
  group: 'inline',
  draggable: false,
  addAttributes() {
    return {
      ...this.parent?.(),
      dx: { default: 0, parseHTML: (el) => Number(el.getAttribute('data-dx')) || 0, renderHTML: () => ({}) },
      dy: { default: 0, parseHTML: (el) => Number(el.getAttribute('data-dy')) || 0, renderHTML: () => ({}) },
      width: { default: null, parseHTML: (el) => el.style.width || (el.getAttribute('width') ? `${el.getAttribute('width')}px` : null), renderHTML: () => ({}) },
      align: { default: 'inline', parseHTML: (el) => el.getAttribute('data-align') || 'inline', renderHTML: () => ({}) },
      height: { default: null, parseHTML: (el) => (el.getAttribute('data-free') ? el.style.height || null : null), renderHTML: () => ({}) },
      lock: { default: true, parseHTML: (el) => el.getAttribute('data-free') !== '1', renderHTML: () => ({}) },
    };
  },
  renderHTML({ HTMLAttributes, node }) {
    const { width, align, height, lock, dx, dy } = node.attrs;
    const moved = dx || dy ? `position:relative;left:${dx}px;top:${dy}px;` : '';
    const float = align === 'left' ? 'float:left;margin:4px 16px 8px 0;' : align === 'right' ? 'float:right;margin:4px 0 8px 16px;' : align === 'center' ? 'display:block;margin:8px auto;' : '';
    const free = height && !lock;
    return ['img', mergeAttributes(HTMLAttributes, { 'data-align': align, ...(free ? { 'data-free': '1' } : {}), ...(moved ? { 'data-dx': dx, 'data-dy': dy } : {}), style: `${moved}${width ? `width:${width};` : ''}max-width:100%;height:${free ? height : 'auto'};${free ? 'object-fit:fill;' : ''}${float}` })];
  },
  addNodeView() { return (props) => createImageNodeView(props); },
}).configure({ allowBase64: true, inline: true });
void px;
